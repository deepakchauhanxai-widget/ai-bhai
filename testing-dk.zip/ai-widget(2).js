// AI BHAI PERFECT CENTER WIDGET - ULTIMATE DESIGN
(function() {
    console.log('🤖 AI Bhai Perfect Center Widget Loading...');

    // Configuration
    const config = {
        scrollTrigger: 80,
        autoCloseTime: 120
    };

    // Global Variables
    let userName = localStorage.getItem('aiWidgetUserName');
    let widget = null;
    let currentLanguage = localStorage.getItem('preferredLanguage') || 'en';
    let nameAsked = false;

    // Initialize
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        console.log('🎯 AI Bhai Perfect Center Initializing...');
        createPerfectWidget();
        setupScrollTrigger();
    }

    function createPerfectWidget() {
        // ULTIMATE CENTER DESIGN STYLES
        const style = document.createElement('style');
        style.innerHTML = `
            #aiBhaiPerfect {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: linear-gradient(145deg, #1a1a2e, #16213e, #0f3460);
                color: white;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                padding: 35px 30px;
                border-radius: 25px;
                width: 85%;
                max-width: 380px;
                min-height: 480px;
                z-index: 10000;
                box-shadow: 
                    0 0 60px rgba(0, 255, 204, 0.4),
                    0 25px 50px rgba(0, 0, 0, 0.6),
                    inset 0 1px 0 rgba(255, 255, 255, 0.1);
                border: 2px solid rgba(0, 255, 204, 0.6);
                animation: perfectEntrance 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                backdrop-filter: blur(20px);
                display: flex;
                flex-direction: column;
            }

            @keyframes perfectEntrance {
                0% { 
                    transform: translate(-50%, -50%) scale(0.7) rotate(-5deg);
                    opacity: 0;
                }
                60% { 
                    transform: translate(-50%, -50%) scale(1.02) rotate(1deg);
                    opacity: 1;
                }
                100% { 
                    transform: translate(-50%, -50%) scale(1) rotate(0);
                    opacity: 1;
                }
            }

            /* Mobile Responsive */
            @media (max-width: 480px) {
                #aiBhaiPerfect {
                    width: 90%;
                    padding: 25px 20px;
                    margin: 0 10px;
                    min-height: 450px;
                }
            }

            @media (max-width: 360px) {
                #aiBhaiPerfect {
                    width: 92%;
                    padding: 20px 15px;
                }
            }

            #aiHeaderPerfect {
                display: flex;
                align-items: center;
                margin-bottom: 25px;
                padding-bottom: 20px;
                border-bottom: 2px solid rgba(0, 255, 204, 0.4);
                position: relative;
            }

            #aiHeaderPerfect::after {
                content: '';
                position: absolute;
                bottom: -2px;
                left: 0;
                width: 120px;
                height: 3px;
                background: linear-gradient(90deg, #00ffcc, #0099ff, transparent);
                border-radius: 3px;
            }

            #aiAvatarPerfect {
                width: 70px;
                height: 70px;
                border-radius: 50%;
                object-fit: cover;
                margin-right: 20px;
                border: 3px solid #00ffcc;
                box-shadow: 
                    0 0 25px rgba(0, 255, 204, 0.6),
                    inset 0 0 15px rgba(0, 255, 204, 0.2);
                animation: avatarPulse 3s ease-in-out infinite;
            }

            @keyframes avatarPulse {
                0%, 100% { 
                    box-shadow: 
                        0 0 25px rgba(0, 255, 204, 0.6),
                        inset 0 0 15px rgba(0, 255, 204, 0.2);
                }
                50% { 
                    box-shadow: 
                        0 0 35px rgba(0, 255, 204, 0.8),
                        inset 0 0 20px rgba(0, 255, 204, 0.3);
                }
            }

            #aiNamePerfect {
                font-weight: 800;
                font-size: 28px;
                background: linear-gradient(135deg, #00ffcc, #0099ff, #cc00ff);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                text-shadow: 0 0 30px rgba(0, 255, 204, 0.4);
                letter-spacing: 0.5px;
            }

            #aiSubtitlePerfect {
                font-size: 15px;
                color: #ff8fab;
                margin-top: 6px;
                font-weight: 600;
                letter-spacing: 0.5px;
            }

            #aiMessagesPerfect {
                flex: 1;
                height: 220px;
                overflow-y: auto;
                margin-bottom: 25px;
                padding: 20px;
                background: rgba(0, 0, 0, 0.25);
                border-radius: 18px;
                border: 1px solid rgba(255, 255, 255, 0.15);
                box-shadow: 
                    inset 0 2px 10px rgba(0, 0, 0, 0.3),
                    0 1px 0 rgba(255, 255, 255, 0.1);
            }

            /* Custom Scrollbar */
            #aiMessagesPerfect::-webkit-scrollbar {
                width: 6px;
            }

            #aiMessagesPerfect::-webkit-scrollbar-track {
                background: rgba(255, 255, 255, 0.05);
                border-radius: 10px;
            }

            #aiMessagesPerfect::-webkit-scrollbar-thumb {
                background: linear-gradient(180deg, #00ffcc, #0099ff);
                border-radius: 10px;
            }

            .ai-message-perfect {
                background: linear-gradient(135deg, 
                    rgba(0, 255, 204, 0.12), 
                    rgba(0, 153, 255, 0.08)
                );
                padding: 16px 18px;
                border-radius: 14px;
                margin-bottom: 14px;
                border-left: 4px solid #00ffcc;
                animation: messageSlidePerfect 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                backdrop-filter: blur(10px);
                position: relative;
                overflow: hidden;
            }

            .ai-message-perfect::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, 
                    transparent, 
                    rgba(255, 255, 255, 0.1), 
                    transparent
                );
                animation: messageShine 3s infinite;
            }

            @keyframes messageShine {
                0% { left: -100%; }
                20% { left: 100%; }
                100% { left: 100%; }
            }

            @keyframes messageSlidePerfect {
                0% { 
                    transform: translateX(-25px) scale(0.95);
                    opacity: 0;
                }
                100% { 
                    transform: translateX(0) scale(1);
                    opacity: 1;
                }
            }

            .typing-perfect {
                display: flex;
                align-items: center;
                gap: 15px;
                padding: 16px 18px;
                background: linear-gradient(135deg, 
                    rgba(0, 255, 204, 0.18), 
                    rgba(255, 0, 204, 0.12)
                );
                border-radius: 14px;
                margin-bottom: 14px;
                border-left: 4px solid #ff00cc;
                animation: typingGlow 2s infinite alternate;
            }

            @keyframes typingGlow {
                0% { border-left-color: #ff00cc; }
                100% { border-left-color: #00ffcc; }
            }

            .typing-dots-perfect {
                display: flex;
                gap: 5px;
            }

            .typing-dot-perfect {
                width: 11px;
                height: 11px;
                border-radius: 50%;
                background: linear-gradient(135deg, #00ffcc, #ff00cc);
                animation: typingBouncePerfect 1.4s infinite ease-in-out;
            }

            .typing-dot-perfect:nth-child(1) { animation-delay: -0.32s; }
            .typing-dot-perfect:nth-child(2) { animation-delay: -0.16s; }

            @keyframes typingBouncePerfect {
                0%, 80%, 100% { 
                    transform: scale(0.85);
                    opacity: 0.6;
                }
                40% { 
                    transform: scale(1.15);
                    opacity: 1;
                }
            }

            .typing-text-perfect {
                color: #00ffcc;
                font-size: 14px;
                font-weight: 600;
            }

            #closePerfect {
                background: linear-gradient(135deg, #ff0066, #ff00cc, #cc00ff);
                color: white;
                border: none;
                padding: 16px;
                border-radius: 14px;
                cursor: pointer;
                width: 100%;
                font-weight: 700;
                font-size: 17px;
                letter-spacing: 0.5px;
                transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                position: relative;
                overflow: hidden;
                text-transform: uppercase;
            }

            #closePerfect::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, 
                    transparent, 
                    rgba(255, 255, 255, 0.2), 
                    transparent
                );
                transition: left 0.6s;
            }

            #closePerfect:hover {
                transform: translateY(-3px) scale(1.02);
                box-shadow: 
                    0 8px 25px rgba(255, 0, 102, 0.5),
                    0 0 20px rgba(255, 0, 102, 0.3);
            }

            #closePerfect:hover::before {
                left: 100%;
            }

            /* Language Badge */
            .language-badge-perfect {
                position: absolute;
                top: 15px;
                right: 15px;
                background: linear-gradient(135deg, #00ffcc, #0099ff);
                color: #1a1a2e;
                padding: 5px 12px;
                border-radius: 20px;
                font-size: 11px;
                font-weight: 800;
                text-transform: uppercase;
                letter-spacing: 1px;
                box-shadow: 0 0 15px rgba(0, 255, 204, 0.5);
                animation: badgePulse 2s infinite;
            }

            @keyframes badgePulse {
                0%, 100% { 
                    box-shadow: 0 0 15px rgba(0, 255, 204, 0.5);
                    transform: scale(1);
                }
                50% { 
                    box-shadow: 0 0 25px rgba(0, 255, 204, 0.8);
                    transform: scale(1.05);
                }
            }

            /* Floating Particles */
            .floating-particles {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                pointer-events: none;
                z-index: -1;
                border-radius: 25px;
                overflow: hidden;
            }

            .particle-item {
                position: absolute;
                width: 3px;
                height: 3px;
                background: #00ffcc;
                border-radius: 50%;
                animation: floatAround 8s infinite linear;
                opacity: 0.7;
            }

            @keyframes floatAround {
                0% { 
                    transform: translate(0, 0) rotate(0deg);
                    opacity: 0;
                }
                10% { opacity: 0.7; }
                90% { opacity: 0.7; }
                100% { 
                    transform: translate(100px, -100px) rotate(180deg);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);

        // Create Perfect Widget
        widget = document.createElement('div');
        widget.id = 'aiBhaiPerfect';
        widget.style.display = 'none';
        
        widget.innerHTML = `
            <div class="floating-particles" id="particlesContainerPerfect"></div>
            <div class="language-badge-perfect" id="languageBadgePerfect">${currentLanguage.toUpperCase()}</div>
            <div id="aiHeaderPerfect">
                <img id="aiAvatarPerfect" src="https://deepakchauhanxai.xyz/images/AI-bhai.png" alt="AI Bhai">
                <div>
                    <div id="aiNamePerfect">AI Brother</div>
                    <div id="aiSubtitlePerfect">Quantum Conversations ⚡</div>
                </div>
            </div>
            <div id="aiMessagesPerfect"></div>
            <button id="closePerfect">EXPERIENCE COMPLETE 🎯</button>
        `;
        
        document.body.appendChild(widget);

        // Create floating particles
        createFloatingParticles();

        // Close button with smooth exit
        document.getElementById('closePerfect').addEventListener('click', function() {
            widget.style.animation = 'perfectEntrance 0.7s cubic-bezier(0.25, 0.46, 0.45, 0.94) reverse';
            setTimeout(() => {
                if (widget.parentNode) {
                    widget.parentNode.removeChild(widget);
                }
            }, 700);
        });

        // Load widget text
        loadWidgetTextPerfect();
    }

    function createFloatingParticles() {
        const container = document.getElementById('particlesContainerPerfect');
        for (let i = 0; i < 12; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle-item';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 8 + 's';
            particle.style.animationDuration = (6 + Math.random() * 4) + 's';
            container.appendChild(particle);
        }
    }

    function setupScrollTrigger() {
        window.addEventListener('scroll', function() {
            if (window.scrollY > config.scrollTrigger && !nameAsked && !userName) {
                console.log('📜 Scroll triggered - showing name modal');
                showNameModalPerfect();
                nameAsked = true;
            }
            
            // Existing user - scroll pe widget show
            if (window.scrollY > config.scrollTrigger && userName && widget && !widget.style.display) {
                console.log('📜 Scroll triggered - showing widget for existing user');
                showWidgetPerfect();
            }
        });
    }

    async function loadWidgetTextPerfect() {
        try {
            const response = await fetch('https://deepakchauhanxai.xyz/testing-dk/languages/widget-text.json');
            const data = await response.json();
            const langData = data[currentLanguage] || data['en'];
            
            document.getElementById('aiNamePerfect').textContent = langData.widget.title;
            document.getElementById('aiSubtitlePerfect').textContent = langData.widget.subtitle;
            document.getElementById('closePerfect').textContent = langData.widget.close_btn;
            
        } catch (error) {
            console.log('Using default perfect text');
        }
    }

    function showNameModalPerfect() {
        if (userName) return;
        
        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(145deg, #1a1a2e, #16213e);
            padding: 35px 30px;
            border-radius: 25px;
            width: 85%;
            max-width: 350px;
            box-shadow: 
                0 0 50px rgba(0, 255, 204, 0.4),
                0 25px 50px rgba(0, 0, 0, 0.6);
            z-index: 10001;
            text-align: center;
            color: white;
            font-family: 'Segoe UI', sans-serif;
            border: 2px solid rgba(0, 255, 204, 0.6);
            animation: perfectEntrance 0.7s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            backdrop-filter: blur(20px);
        `;
        
        modal.innerHTML = `
            <h3 style="color: #00ffcc; margin-bottom: 15px; font-size: 24px; font-weight: 700;">IDENTITY VERIFICATION 🔐</h3>
            <p style="margin-bottom: 25px; font-size: 15px; line-height: 1.4; opacity: 0.9;">To unlock your personalized AI Bhai experience, please enter your legendary name:</p>
            <input type="text" class="name-input-fixed" placeholder="Enter your command name..." style="width: 100%; padding: 15px; margin: 20px 0; border: 2px solid #00ffcc; border-radius: 12px; background: rgba(255,255,255,0.1); color: white; font-size: 16px; text-align: center; outline: none; font-weight: 600;">
            <button class="submit-name-fixed" style="background: linear-gradient(135deg, #00ffcc, #0099ff); color: #1a1a2e; border: none; padding: 15px 30px; border-radius: 12px; cursor: pointer; font-weight: 700; font-size: 16px; width: 100%; transition: all 0.3s;">ACTIVATE AI BHAI 🚀</button>
        `;
        
        document.body.appendChild(modal);

        const input = modal.querySelector('.name-input-fixed');
        const submitBtn = modal.querySelector('.submit-name-fixed');

        submitBtn.addEventListener('click', function() {
            if (input.value.trim()) {
                userName = input.value.trim();
                localStorage.setItem('aiWidgetUserName', userName);
                document.body.removeChild(modal);
                showWidgetPerfect();
            } else {
                input.style.borderColor = '#ff0066';
                input.placeholder = "⚠️ Identity required!";
            }
        });

        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') submitBtn.click();
        });

        setTimeout(() => input.focus(), 100);
    }

    function showWidgetPerfect() {
        console.log('🎪 Showing Perfect Widget for:', userName);
        widget.style.display = 'block';
        startConversationPerfect();
        
        setTimeout(() => {
            if (widget && document.body.contains(widget)) {
                widget.remove();
            }
        }, config.autoCloseTime * 1000);
    }

    async function startConversationPerfect() {
        const messagesContainer = document.getElementById('aiMessagesPerfect');
        messagesContainer.innerHTML = '';

        try {
            // Update language badge
            document.getElementById('languageBadgePerfect').textContent = currentLanguage.toUpperCase();
            
            // Load content
            const response = await fetch(`https://deepakchauhanxai.xyz/testing-dk/assets/widgets/${currentLanguage}.json`);
            const data = await response.json();
            
            const shayariList = data.shayari || data.messages || [];
            const randomIndex = Math.floor(Math.random() * shayariList.length);
            const content = shayariList[randomIndex];
            
            // Epic conversation
            await showTypingPerfect(`SYSTEM ONLINE ✅`);
            await showTypingPerfect(`USER: ${userName.toUpperCase()} 👤`);
            await showTypingPerfect(content.welcome ? content.welcome.replace('${username}', userName) : `WELCOME ${userName.toUpperCase()}! 🌟`);
            await showTypingPerfect(content.intro || "QUANTUM MESSAGE INCOMING ⚡");
            await showTypingPerfect(content.shayari || "YOU ARE DESIGNED FOR GREATNESS! 💎");
            await showTypingPerfect("MAKE TODAY LEGENDARY! 🚀");
            
        } catch (error) {
            console.error('Content load error:', error);
            await showTypingPerfect(`WELCOME ${userName}! 🌟`);
            await showTypingPerfect("AI BHAI SYSTEMS ACTIVE 🤖");
            await showTypingPerfect("YOUR POTENTIAL IS INFINITE! 💫");
            await showTypingPerfect("CREATE YOUR LEGACY! 👑");
        }
    }

    function showTypingPerfect(text) {
        return new Promise((resolve) => {
            const typingDiv = document.createElement('div');
            typingDiv.className = 'typing-perfect';
            typingDiv.innerHTML = `
                <div class="typing-dots-perfect">
                    <div class="typing-dot-perfect"></div>
                    <div class="typing-dot-perfect"></div>
                    <div class="typing-dot-perfect"></div>
                </div>
                <div class="typing-text-perfect">AI Bhai Quantum Processing...</div>
            `;
            document.getElementById('aiMessagesPerfect').appendChild(typingDiv);
            scrollToBottomPerfect();
            
            setTimeout(() => {
                typingDiv.remove();
                const msgDiv = document.createElement('div');
                msgDiv.className = 'ai-message-perfect';
                msgDiv.textContent = text;
                document.getElementById('aiMessagesPerfect').appendChild(msgDiv);
                scrollToBottomPerfect();
                resolve();
            }, 2200);
        });
    }

    function scrollToBottomPerfect() {
        const messages = document.getElementById('aiMessagesPerfect');
        messages.scrollTop = messages.scrollHeight;
    }

    // Language change listener
    document.addEventListener('languageChanged', function(event) {
        console.log('🌐 Language changed to:', event.detail.language);
        currentLanguage = event.detail.language;
        
        // Update bot name and badge
        loadWidgetTextPerfect();
        document.getElementById('languageBadgePerfect').textContent = currentLanguage.toUpperCase();
        
        if (widget && widget.style.display !== 'none') {
            document.getElementById('aiMessagesPerfect').innerHTML = '';
            startConversationPerfect();
        }
    });

    console.log('✅ AI BHAI PERFECT CENTER WIDGET READY!');

})();