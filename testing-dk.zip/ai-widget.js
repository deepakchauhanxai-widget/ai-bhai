// AI BHAI PERFECT WIDGET - 15 MINUTES + TRANSPARENT
(function() {
    console.log('🤖 AI Bhai Perfect Widget Loading...');

    // Configuration
    const config = {
        autoShowDelay: 2000,
        autoCloseTime: 120,
        enableParticles: true,
        showAfterMinutes: 15 // 15 minutes baad dubara show hoga
    };

    // Global State Management
    let userName = localStorage.getItem('aiWidgetUserName');
    let widget = null;
    let currentLanguage = localStorage.getItem('preferredLanguage') || 'en';
    let widgetShown = false;
    let conversationData = {};
    
    // Smart Show Logic - 15 minutes baad hi show hoga
    function shouldShowWidget() {
        const lastShowTime = localStorage.getItem('aiBhaiLastShow');
        
        if (!lastShowTime) {
            // Pehli baar visit pe always show karo
            return true;
        }
        
        const lastShow = parseInt(lastShowTime);
        const currentTime = new Date().getTime();
        const minutesSinceLastShow = (currentTime - lastShow) / (1000 * 60);
        
        console.log(`⏰ Last show: ${minutesSinceLastShow.toFixed(2)} minutes ago`);
        
        // 15 minutes se zyada ho gaye toh show karo
        return minutesSinceLastShow >= config.showAfterMinutes;
    }

    // Mark widget as shown for 15 minutes
    function markWidgetAsShown() {
        localStorage.setItem('aiBhaiLastShow', new Date().getTime().toString());
        console.log('✅ Widget shown time saved for 15 minutes');
    }

    // Initialize Everything
    function init() {
        console.log('🎯 AI Bhai Perfect Initializing...');
        
        if (widgetShown) return;

        // Check if should show widget
        if (!shouldShowWidget()) {
            console.log('⏳ Widget already shown recently, waiting 15 minutes...');
            return;
        }

        loadConversationData().then(() => {
            createPerfectWidget();
            
            setTimeout(() => {
                if (!widgetShown) {
                    showWidgetBasedOnUser();
                }
            }, 1000);
        }).catch(error => {
            createPerfectWidget();
            setTimeout(showWidgetBasedOnUser, 1000);
        });
    }

    async function loadConversationData() {
        try {
            const response = await fetch('https://deepakchauhanxai.xyz/testing-dk/languages/widget-text.json');
            const data = await response.json();
            conversationData = data;
        } catch (error) {
            conversationData = {
                'en': {
                    'widget': {
                        'title': 'AI Brother',
                        'subtitle': 'Quantum Conversations ⚡',
                        'close_btn': 'EXPERIENCE COMPLETE 🎯'
                    }
                }
            };
        }
    }

    function createPerfectWidget() {
        if (document.getElementById('aiBhaiPerfect')) {
            widget = document.getElementById('aiBhaiPerfect');
            return;
        }

        // PERFECT STYLES WITH TRANSPARENCY
        const style = document.createElement('style');
        style.innerHTML = `
            #aiBhaiPerfect {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) scale(1);
                background: linear-gradient(145deg, 
                    rgba(26, 26, 46, 0.85), 
                    rgba(22, 33, 62, 0.83), 
                    rgba(15, 52, 96, 0.8)
                );
                color: white;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                padding: 35px 30px;
                border-radius: 25px;
                width: 85%;
                max-width: 380px;
                min-height: 480px;
                z-index: 10000;
                box-shadow: 
                    0 0 80px rgba(0, 255, 204, 0.5),
                    0 30px 60px rgba(0, 0, 0, 0.7),
                    inset 0 1px 0 rgba(255, 255, 255, 0.15);
                border: 2px solid rgba(0, 255, 204, 0.7);
                animation: perfectEntrance 0.9s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                backdrop-filter: blur(25px);
                display: flex;
                flex-direction: column;
                overflow: hidden;
            }

            @keyframes perfectEntrance {
                0% { 
                    transform: translate(-50%, -50%) scale(0.6) rotate(-8deg);
                    opacity: 0;
                }
                60% { 
                    transform: translate(-50%, -50%) scale(1.05) rotate(2deg);
                    opacity: 1;
                }
                100% { 
                    transform: translate(-50%, -50%) scale(1) rotate(0);
                    opacity: 1;
                }
            }

            @media (max-width: 480px) {
                #aiBhaiPerfect {
                    width: 90%;
                    padding: 30px 25px;
                    min-height: 460px;
                }
            }

            #aiHeaderPerfect {
                display: flex;
                align-items: center;
                margin-bottom: 25px;
                padding-bottom: 20px;
                border-bottom: 2px solid rgba(0, 255, 204, 0.5);
                position: relative;
            }

            #aiHeaderPerfect::after {
                content: '';
                position: absolute;
                bottom: -2px;
                left: 0;
                width: 140px;
                height: 4px;
                background: linear-gradient(90deg, #00ffcc, #0099ff, #cc00ff, transparent);
                border-radius: 4px;
                animation: headerGlow 3s infinite alternate;
            }

            @keyframes headerGlow {
                0% { background-position: 0% 50%; }
                100% { background-position: 100% 50%; }
            }

            #aiAvatarPerfect {
                width: 75px;
                height: 75px;
                border-radius: 50%;
                object-fit: cover;
                margin-right: 20px;
                border: 3px solid #00ffcc;
                box-shadow: 
                    0 0 30px rgba(0, 255, 204, 0.7),
                    inset 0 0 20px rgba(0, 255, 204, 0.3);
                animation: avatarPulsePerfect 4s ease-in-out infinite;
            }

            @keyframes avatarPulsePerfect {
                0%, 100% { 
                    transform: scale(1) rotate(0deg);
                }
                50% { 
                    transform: scale(1.05) rotate(-1deg);
                }
            }

            #aiNamePerfect {
                font-weight: 900;
                font-size: 32px;
                background: linear-gradient(135deg, #00ffcc, #0099ff, #cc00ff);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-size: 300% 300%;
                animation: gradientShift 4s ease infinite;
                text-shadow: 0 0 40px rgba(0, 255, 204, 0.5);
                letter-spacing: 0.8px;
            }

            @keyframes gradientShift {
                0%, 100% { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
            }

            #aiSubtitlePerfect {
                font-size: 16px;
                color: #ff8fab;
                margin-top: 8px;
                font-weight: 700;
                letter-spacing: 0.8px;
            }

            #aiMessagesPerfect {
                flex: 1;
                height: 230px;
                overflow-y: auto;
                margin-bottom: 25px;
                padding: 20px;
                background: rgba(0, 0, 0, 0.25);
                border-radius: 18px;
                border: 1px solid rgba(255, 255, 255, 0.2);
                box-shadow: 
                    inset 0 4px 20px rgba(0, 0, 0, 0.4),
                    0 2px 0 rgba(255, 255, 255, 0.1);
                backdrop-filter: blur(15px);
            }

            #aiMessagesPerfect::-webkit-scrollbar {
                width: 6px;
            }

            #aiMessagesPerfect::-webkit-scrollbar-track {
                background: rgba(255, 255, 255, 0.05);
                border-radius: 10px;
            }

            #aiMessagesPerfect::-webkit-scrollbar-thumb {
                background: linear-gradient(180deg, #00ffcc, #0099ff);
                border-radius: 10px;
            }

            /* DIFFERENT COLOR MESSAGE BOXES - TRANSPARENT */
            .ai-message-perfect {
                padding: 16px 18px;
                border-radius: 14px;
                margin-bottom: 14px;
                border-left: 4px solid;
                animation: messageSlidePerfect 0.5s ease-out;
                backdrop-filter: blur(10px);
                font-weight: 600;
            }

            .message-color-1 {
                background: linear-gradient(135deg, rgba(0, 255, 204, 0.12), rgba(0, 153, 255, 0.08));
                border-left-color: #00ffcc;
                box-shadow: 0 4px 15px rgba(0, 255, 204, 0.15);
            }

            .message-color-2 {
                background: linear-gradient(135deg, rgba(255, 0, 204, 0.12), rgba(204, 0, 255, 0.08));
                border-left-color: #ff00cc;
                box-shadow: 0 4px 15px rgba(255, 0, 204, 0.15);
            }

            .message-color-3 {
                background: linear-gradient(135deg, rgba(0, 153, 255, 0.12), rgba(0, 255, 204, 0.08));
                border-left-color: #0099ff;
                box-shadow: 0 4px 15px rgba(0, 153, 255, 0.15);
            }

            .message-color-4 {
                background: linear-gradient(135deg, rgba(255, 143, 171, 0.12), rgba(255, 0, 102, 0.08));
                border-left-color: #ff8fab;
                box-shadow: 0 4px 15px rgba(255, 143, 171, 0.15);
            }

            .message-color-5 {
                background: linear-gradient(135deg, rgba(102, 0, 255, 0.12), rgba(204, 0, 255, 0.08));
                border-left-color: #6600ff;
                box-shadow: 0 4px 15px rgba(102, 0, 255, 0.15);
            }

            @keyframes messageSlidePerfect {
                0% { 
                    transform: translateX(-20px);
                    opacity: 0;
                }
                100% { 
                    transform: translateX(0);
                    opacity: 1;
                }
            }

            /* DIFFERENT COLOR TYPING BOXES - TRANSPARENT */
            .typing-perfect {
                display: flex;
                align-items: center;
                gap: 15px;
                padding: 16px 18px;
                border-radius: 14px;
                margin-bottom: 14px;
                border-left: 4px solid;
                animation: typingPulse 2s infinite alternate;
                font-weight: 600;
            }

            .typing-color-1 {
                background: linear-gradient(135deg, rgba(0, 255, 204, 0.15), rgba(0, 153, 255, 0.1));
                border-left-color: #00ffcc;
                box-shadow: 0 4px 20px rgba(0, 255, 204, 0.2);
            }

            .typing-color-2 {
                background: linear-gradient(135deg, rgba(255, 0, 204, 0.15), rgba(204, 0, 255, 0.1));
                border-left-color: #ff00cc;
                box-shadow: 0 4px 20px rgba(255, 0, 204, 0.2);
            }

            .typing-color-3 {
                background: linear-gradient(135deg, rgba(0, 153, 255, 0.15), rgba(0, 255, 204, 0.1));
                border-left-color: #0099ff;
                box-shadow: 0 4px 20px rgba(0, 153, 255, 0.2);
            }

            .typing-color-4 {
                background: linear-gradient(135deg, rgba(255, 143, 171, 0.15), rgba(255, 0, 102, 0.1));
                border-left-color: #ff8fab;
                box-shadow: 0 4px 20px rgba(255, 143, 171, 0.2);
            }

            .typing-color-5 {
                background: linear-gradient(135deg, rgba(102, 0, 255, 0.15), rgba(204, 0, 255, 0.1));
                border-left-color: #6600ff;
                box-shadow: 0 4px 20px rgba(102, 0, 255, 0.2);
            }

            @keyframes typingPulse {
                0% { 
                    transform: scale(1);
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
                }
                100% { 
                    transform: scale(1.02);
                    box-shadow: 0 6px 25px rgba(0, 0, 0, 0.3);
                }
            }

            .typing-dots-perfect {
                display: flex;
                gap: 5px;
            }

            .typing-dot-perfect {
                width: 10px;
                height: 10px;
                border-radius: 50%;
                animation: typingBouncePerfect 1.4s infinite ease-in-out;
            }

            /* DIFFERENT COLOR DOTS */
            .dots-color-1 .typing-dot-perfect { background: #00ffcc; }
            .dots-color-2 .typing-dot-perfect { background: #ff00cc; }
            .dots-color-3 .typing-dot-perfect { background: #0099ff; }
            .dots-color-4 .typing-dot-perfect { background: #ff8fab; }
            .dots-color-5 .typing-dot-perfect { background: #6600ff; }

            .typing-dot-perfect:nth-child(1) { animation-delay: -0.32s; }
            .typing-dot-perfect:nth-child(2) { animation-delay: -0.16s; }

            @keyframes typingBouncePerfect {
                0%, 80%, 100% { 
                    transform: scale(0.8);
                    opacity: 0.6;
                }
                40% { 
                    transform: scale(1.2);
                    opacity: 1;
                }
            }

            .typing-text-perfect {
                font-size: 14px;
                font-weight: 600;
            }

            /* DIFFERENT COLOR TYPING TEXT */
            .text-color-1 { color: #00ffcc; text-shadow: 0 0 10px rgba(0, 255, 204, 0.5); }
            .text-color-2 { color: #ff00cc; text-shadow: 0 0 10px rgba(255, 0, 204, 0.5); }
            .text-color-3 { color: #0099ff; text-shadow: 0 0 10px rgba(0, 153, 255, 0.5); }
            .text-color-4 { color: #ff8fab; text-shadow: 0 0 10px rgba(255, 143, 171, 0.5); }
            .text-color-5 { color: #6600ff; text-shadow: 0 0 10px rgba(102, 0, 255, 0.5); }

            #closePerfect {
                background: linear-gradient(135deg, #ff0066, #ff00cc);
                color: white;
                border: none;
                padding: 16px;
                border-radius: 14px;
                cursor: pointer;
                width: 100%;
                font-weight: 700;
                font-size: 17px;
                letter-spacing: 0.5px;
                transition: all 0.3s ease;
            }

            #closePerfect:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 25px rgba(255, 0, 102, 0.4);
            }

            .language-badge-perfect {
                position: absolute;
                top: 15px;
                right: 15px;
                background: linear-gradient(135deg, #00ffcc, #0099ff);
                color: #1a1a2e;
                padding: 5px 12px;
                border-radius: 20px;
                font-size: 11px;
                font-weight: 800;
                text-transform: uppercase;
                letter-spacing: 1px;
                box-shadow: 0 0 20px rgba(0, 255, 204, 0.5);
            }

            .perfect-particles {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                pointer-events: none;
                z-index: -1;
                border-radius: 25px;
                overflow: hidden;
            }

            .perfect-particle {
                position: absolute;
                width: 3px;
                height: 3px;
                background: #00ffcc;
                border-radius: 50%;
                animation: perfectFloat 8s infinite linear;
                opacity: 0.7;
            }

            @keyframes perfectFloat {
                0% { 
                    transform: translate(0, 0) rotate(0deg);
                    opacity: 0;
                }
                10% { opacity: 0.7; }
                90% { opacity: 0.7; }
                100% { 
                    transform: translate(100px, -100px) rotate(180deg);
                    opacity: 0;
                }
            }

            .progress-bar-perfect {
                position: absolute;
                bottom: 0;
                left: 0;
                width: 100%;
                height: 3px;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 0 0 25px 25px;
                overflow: hidden;
            }

            .progress-fill-perfect {
                height: 100%;
                background: linear-gradient(90deg, #00ffcc, #0099ff);
                animation: progressShrinkPerfect linear forwards;
                border-radius: 0 0 25px 25px;
            }

            @keyframes progressShrinkPerfect {
                from { width: 100%; }
                to { width: 0%; }
            }
        `;
        
        if (!document.getElementById('aiBhaiPerfectStyles')) {
            style.id = 'aiBhaiPerfectStyles';
            document.head.appendChild(style);
        }

        // Create Perfect Widget
        widget = document.createElement('div');
        widget.id = 'aiBhaiPerfect';
        widget.style.display = 'none';
        
        widget.innerHTML = `
            <div class="perfect-particles" id="perfectParticles"></div>
            <div class="language-badge-perfect">${currentLanguage.toUpperCase()}</div>
            <div class="progress-bar-perfect"><div class="progress-fill-perfect" style="animation-duration: ${config.autoCloseTime}s"></div></div>
            
            <div id="aiHeaderPerfect">
                <img id="aiAvatarPerfect" src="https://deepakchauhanxai.xyz/images/AI-bhai.png" alt="AI Bhai">
                <div>
                    <div id="aiNamePerfect">AI Brother</div>
                    <div id="aiSubtitlePerfect">Quantum Conversations ⚡</div>
                </div>
            </div>
            
            <div id="aiMessagesPerfect"></div>
            <button id="closePerfect">EXPERIENCE COMPLETE 🎯</button>
        `;
        
        document.body.appendChild(widget);

        // Create particles
        createPerfectParticles();

        // Close button - MARK TIME AS SHOWN
        document.getElementById('closePerfect').addEventListener('click', function() {
            markWidgetAsShown();
            hidePerfectWidget();
        });

        // Load widget text
        updatePerfectWidgetText();
        
        console.log('✅ Perfect Widget Created');
    }

    function createPerfectParticles() {
        if (!config.enableParticles) return;
        
        const container = document.getElementById('perfectParticles');
        for (let i = 0; i < 10; i++) {
            const particle = document.createElement('div');
            particle.className = 'perfect-particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 8 + 's';
            particle.style.animationDuration = (6 + Math.random() * 6) + 's';
            container.appendChild(particle);
        }
    }

    function updatePerfectWidgetText() {
        const langData = conversationData[currentLanguage] || conversationData['en'];
        if (langData && langData.widget) {
            document.getElementById('aiNamePerfect').textContent = langData.widget.title;
            document.getElementById('aiSubtitlePerfect').textContent = langData.widget.subtitle;
            document.getElementById('closePerfect').textContent = langData.widget.close_btn;
        }
    }

    function showWidgetBasedOnUser() {
        if (widgetShown) return;

        if (!userName) {
            showNameModalPerfect();
        } else {
            showWidgetPerfect();
        }
        
        widgetShown = true;
    }

    function showNameModalPerfect() {
        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(145deg, 
                rgba(26, 26, 46, 0.9), 
                rgba(22, 33, 62, 0.88)
            );
            padding: 30px 25px;
            border-radius: 20px;
            width: 85%;
            max-width: 320px;
            box-shadow: 0 0 50px rgba(0, 255, 204, 0.4);
            z-index: 10001;
            text-align: center;
            color: white;
            font-family: 'Segoe UI', sans-serif;
            border: 2px solid rgba(0, 255, 204, 0.6);
            backdrop-filter: blur(20px);
        `;
        
        modal.innerHTML = `
            <h3 style="color: #00ffcc; margin-bottom: 15px; font-size: 24px;">WELCOME TO AI BHAI</h3>
            <p style="margin-bottom: 20px; font-size: 14px;">Enter your name to continue:</p>
            <input type="text" id="userNameInputPerfect" placeholder="Your name..." style="width: 100%; padding: 14px; margin: 15px 0; border: 2px solid #00ffcc; border-radius: 12px; background: rgba(255,255,255,0.1); color: white; font-size: 16px; text-align: center; outline: none;">
            <button id="submitNameBtnPerfect" style="background: #00ffcc; color: #1a1a2e; border: none; padding: 14px; border-radius: 12px; cursor: pointer; font-weight: 700; font-size: 16px; width: 100%;">START JOURNEY</button>
        `;
        
        document.body.appendChild(modal);

        const input = document.getElementById('userNameInputPerfect');
        const submitBtn = document.getElementById('submitNameBtnPerfect');

        submitBtn.addEventListener('click', function() {
            if (input.value.trim()) {
                userName = input.value.trim();
                localStorage.setItem('aiWidgetUserName', userName);
                document.body.removeChild(modal);
                showWidgetPerfect();
            } else {
                input.style.borderColor = '#ff0066';
                input.placeholder = "Please enter name!";
            }
        });

        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') submitBtn.click();
        });

        setTimeout(() => input.focus(), 100);
    }

    function showWidgetPerfect() {
        console.log('🎪 Showing Perfect Widget for:', userName);
        
        if (!widget) {
            createPerfectWidget();
        }
        
        widget.style.display = 'block';
        startPerfectConversation();
        
        // Auto close - MARK TIME AS SHOWN
        setTimeout(() => {
            if (widget && document.body.contains(widget)) {
                markWidgetAsShown();
                hidePerfectWidget();
            }
        }, config.autoCloseTime * 1000);
    }

    function hidePerfectWidget() {
        if (widget && document.body.contains(widget)) {
            widget.style.animation = 'perfectEntrance 0.5s ease-in reverse';
            setTimeout(() => {
                widget.style.display = 'none';
            }, 500);
        }
        widgetShown = true;
    }

    async function startPerfectConversation() {
        const messagesContainer = document.getElementById('aiMessagesPerfect');
        if (!messagesContainer) return;

        messagesContainer.innerHTML = '';

        try {
            const response = await fetch(`https://deepakchauhanxai.xyz/testing-dk/assets/widgets/${currentLanguage}.json`);
            const data = await response.json();
            
            const messages = data.shayari || data.messages || [];
            const randomIndex = Math.floor(Math.random() * messages.length);
            const content = messages[randomIndex];
            
            // DIFFERENT COLOR FOR EACH MESSAGE
            await showTypingPerfect(`SYSTEM ONLINE ✅`, 1);
            await showTypingPerfect(`HELLO ${userName.toUpperCase()}! 👋`, 2);
            
            if (content.welcome) {
                await showTypingPerfect(content.welcome.replace('${username}', userName), 3);
            }
            if (content.intro && content.intro !== content.welcome) {
                await showTypingPerfect(content.intro, 4);
            }
            if (content.shayari && content.shayari !== content.intro && content.shayari !== content.welcome) {
                await showTypingPerfect(content.shayari, 5);
            }
            
            await showTypingPerfect("MAKE TODAY AMAZING! 🌟", 1);
            
        } catch (error) {
            // FALLBACK WITH DIFFERENT COLORS
            await showTypingPerfect("WELCOME TO AI BHAI! 🌟", 1);
            await showTypingPerfect(`HELLO ${userName.toUpperCase()}! 👋`, 2);
            await showTypingPerfect("GREAT TO SEE YOU TODAY! 😊", 3);
            await showTypingPerfect("MAKE IT A WONDERFUL DAY! 💫", 4);
        }
    }

    function showTypingPerfect(text, colorIndex) {
        return new Promise((resolve) => {
            const messagesContainer = document.getElementById('aiMessagesPerfect');
            if (!messagesContainer) {
                resolve();
                return;
            }

            const colorNum = (colorIndex % 5) + 1; // 1-5 range
            
            const typingDiv = document.createElement('div');
            typingDiv.className = `typing-perfect typing-color-${colorNum}`;
            typingDiv.innerHTML = `
                <div class="typing-dots-perfect dots-color-${colorNum}">
                    <div class="typing-dot-perfect"></div>
                    <div class="typing-dot-perfect"></div>
                    <div class="typing-dot-perfect"></div>
                </div>
                <div class="typing-text-perfect text-color-${colorNum}">AI Bhai is typing...</div>
            `;
            messagesContainer.appendChild(typingDiv);
            scrollToBottomPerfect();
            
            setTimeout(() => {
                typingDiv.remove();
                const msgDiv = document.createElement('div');
                msgDiv.className = `ai-message-perfect message-color-${colorNum}`;
                msgDiv.textContent = text;
                messagesContainer.appendChild(msgDiv);
                scrollToBottomPerfect();
                resolve();
            }, 2000);
        });
    }

    function scrollToBottomPerfect() {
        const messages = document.getElementById('aiMessagesPerfect');
        if (messages) {
            messages.scrollTop = messages.scrollHeight;
        }
    }

    // Initialize ONLY if 15 minutes passed
    if (shouldShowWidget()) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
        } else {
            setTimeout(init, 800);
        }
    }

    // Language change event listener
    document.addEventListener('languageChanged', function(event) {
        console.log('🌐 Language changed to:', event.detail.language);
        currentLanguage = event.detail.language;
        
        const badge = document.querySelector('.language-badge-perfect');
        if (badge) {
            badge.textContent = currentLanguage.toUpperCase();
        }
        
        updatePerfectWidgetText();
        
        if (widget && widget.style.display !== 'none') {
            document.getElementById('aiMessagesPerfect').innerHTML = '';
            startPerfectConversation();
        }
    });

    console.log('✅ AI BHAI PERFECT WIDGET READY!');

})();