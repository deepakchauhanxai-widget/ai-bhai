class DailyProgressTracker {
    constructor() {
        this.storageKey = 'dkCommunityProgress';
        this.currentDate = new Date().toDateString();
        this.currentLanguage = 'en';
        this.init();
    }

    init() {
        this.loadProgress();
        this.updateDisplay();
        this.checkStreak();
        this.bindEvents();
        this.loadLanguage();
    }

    bindEvents() {
        // Language change event
        document.addEventListener('languageChanged', (e) => {
            this.currentLanguage = e.detail.language;
            this.updateDisplay();
        });
    }

    loadLanguage() {
        const langBtn = document.getElementById('langToggle');
        if (langBtn) {
            const currentLang = langBtn.querySelector('.current-lang').textContent;
            this.currentLanguage = this.getLanguageFromEmoji(currentLang);
        }
    }

    getLanguageFromEmoji(emoji) {
        const langMap = {
            '🇮🇳': 'hi',
            '🇺🇸': 'en', 
            '🇵🇰': 'ur',
            'mr': 'mr'
        };
        return langMap[emoji] || 'en';
    }

    loadProgress() {
        const data = localStorage.getItem(this.storageKey);
        if (data) {
            this.progress = JSON.parse(data);
        } else {
            this.progress = {
                streak: 0,
                lastDate: null,
                totalDays: 0,
                totalGoalsCompleted: 0,
                goals: {
                    motivation: false,
                    story: false,
                    share: false,
                    learn: false
                },
                achievements: []
            };
            this.saveProgress();
        }
    }

    saveProgress() {
        localStorage.setItem(this.storageKey, JSON.stringify(this.progress));
    }

    checkStreak() {
        const today = this.currentDate;
        const lastDate = this.progress.lastDate;

        if (lastDate) {
            const last = new Date(lastDate);
            const todayObj = new Date();
            const diffTime = todayObj - last;
            const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

            if (diffDays === 1) {
                // Consecutive day
                this.progress.streak++;
            } else if (diffDays > 1) {
                // Broken streak
                this.progress.streak = 1;
            }
            // If same day, do nothing
        } else {
            // First time
            this.progress.streak = 1;
        }

        // Update last date to today if it's a new day
        if (lastDate !== today) {
            this.progress.lastDate = today;
            this.progress.totalDays++;
            
            // Reset daily goals for new day
            this.resetDailyGoals();
        }

        this.saveProgress();
        this.checkAchievements();
    }

    resetDailyGoals() {
        this.progress.goals = {
            motivation: false,
            story: false,
            share: false,
            learn: false
        };
    }

    updateGoal(goalType) {
        const checkbox = document.getElementById(`goal${goalType.charAt(0).toUpperCase() + goalType.slice(1)}`);
        const wasCompleted = this.progress.goals[goalType];
        this.progress.goals[goalType] = checkbox.checked;

        // Update total goals completed
        if (checkbox.checked && !wasCompleted) {
            this.progress.totalGoalsCompleted++;
        } else if (!checkbox.checked && wasCompleted) {
            this.progress.totalGoalsCompleted = Math.max(0, this.progress.totalGoalsCompleted - 1);
        }

        this.saveProgress();
        this.updateDisplay();
        this.checkAchievements();
    }

    checkAchievements() {
        const achievements = [];
        
        // Streak achievements
        if (this.progress.streak >= 7) achievements.push('week_streak');
        if (this.progress.streak >= 30) achievements.push('month_streak');
        if (this.progress.streak >= 100) achievements.push('century_streak');
        
        // Goal achievements
        const completedToday = Object.values(this.progress.goals).filter(Boolean).length;
        if (completedToday === 4) achievements.push('daily_champion');
        
        if (this.progress.totalGoalsCompleted >= 10) achievements.push('goal_master');
        if (this.progress.totalGoalsCompleted >= 50) achievements.push('goal_legend');

        // Add new achievements
        achievements.forEach(achievement => {
            if (!this.progress.achievements.includes(achievement)) {
                this.progress.achievements.push(achievement);
                this.showAchievementNotification(achievement);
            }
        });

        this.saveProgress();
    }

    showAchievementNotification(achievementKey) {
        const achievements = {
            'week_streak': { 
                en: '7-Day Streak! 🔥', 
                hi: '7-दिन की लगातार सफलता! 🔥',
                ur: '7-دن کا تسلسل! 🔥',
                mr: '7-दिवसीय स्ट्रीक! 🔥'
            },
            'month_streak': { 
                en: '30-Day Master! 🏆', 
                hi: '30-दिन का मास्टर! 🏆',
                ur: '30-دن کا ماسٹر! 🏆',
                mr: '30-दिवसीय मास्टर! 🏆'
            },
            'century_streak': { 
                en: '100 Days Legend! 💫', 
                hi: '100 दिनों की लीजेंड! 💫',
                ur: '100 دنوں کی لیجنڈ! 💫',
                mr: '100-दिवसीय लीजेंड! 💫'
            },
            'daily_champion': { 
                en: 'Daily Champion! ⭐', 
                hi: 'दैनिक चैंपियन! ⭐',
                ur: 'روزانہ چیمپئن! ⭐',
                mr: 'दैनिक विजेता! ⭐'
            },
            'goal_master': { 
                en: 'Goal Master! 🎯', 
                hi: 'गोल मास्टर! 🎯',
                ur: 'ہدف ماسٹر! 🎯',
                mr: 'गोल मास्टर! 🎯'
            },
            'goal_legend': { 
                en: 'Goal Legend! 🌟', 
                hi: 'गोल लीजेंड! 🌟',
                ur: 'ہدف لیجنڈ! 🌟',
                mr: 'गोल लीजेंड! 🌟'
            }
        };

        const achievement = achievements[achievementKey];
        if (achievement) {
            const message = achievement[this.currentLanguage] || achievement.en;
            
            // Create notification
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, #4CAF50, #45a049);
                color: white;
                padding: 15px 20px;
                border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.3);
                z-index: 10000;
                animation: slideInRight 0.5s ease-out;
            `;
            notification.innerHTML = `
                <strong>🎉 Achievement Unlocked!</strong><br>
                ${message}
            `;
            document.body.appendChild(notification);

            setTimeout(() => {
                notification.remove();
            }, 3000);
        }
    }

    updateDisplay() {
        // Update streak
        document.getElementById('streakCount').textContent = this.progress.streak;
        
        // Update goals
        for (const goal in this.progress.goals) {
            const checkbox = document.getElementById(`goal${goal.charAt(0).toUpperCase() + goal.slice(1)}`);
            if (checkbox) {
                checkbox.checked = this.progress.goals[goal];
            }
        }
        
        // Update stats
        const completedToday = Object.values(this.progress.goals).filter(Boolean).length;
        const completionRate = this.progress.totalDays > 0 
            ? Math.round((this.progress.totalGoalsCompleted / (this.progress.totalDays * 4)) * 100)
            : 0;
            
        document.getElementById('totalGoals').textContent = this.progress.totalGoalsCompleted;
        document.getElementById('completionRate').textContent = completionRate + '%';
        document.getElementById('totalDays').textContent = this.progress.totalDays;
        
        // Update achievements
        this.updateAchievementsDisplay();
        
        // Update translations
        this.updateTranslations();
    }

    updateAchievementsDisplay() {
        const badgesGrid = document.getElementById('badgesGrid');
        const achievements = {
            'week_streak': { 
                icon: '🔥', 
                name: { en: '7-Day Streak', hi: '7-दिन स्ट्रीक', ur: '7-دن کا تسلسل', mr: '7-दिवस स्ट्रीक' },
                desc: { en: 'Maintain 7-day streak', hi: '7-दिन का स्ट्रीक बनाए रखें', ur: '7 دن کا تسلسل برقرار رکھیں', mr: '7-दिवस स्ट्रीक राखा' }
            },
            'month_streak': { 
                icon: '🏆', 
                name: { en: '30-Day Master', hi: '30-दिन मास्टर', ur: '30-دن کا ماسٹر', mr: '30-दिवस मास्टर' },
                desc: { en: 'Maintain 30-day streak', hi: '30-दिन का स्ट्रीक बनाए रखें', ur: '30 دن کا تسلسل برقرار رکھیں', mr: '30-दिवस स्ट्रीक राखा' }
            },
            'daily_champion': { 
                icon: '⭐', 
                name: { en: 'Daily Champion', hi: 'दैनिक चैंपियन', ur: 'روزانہ چیمپئن', mr: 'दैनिक विजेता' },
                desc: { en: 'Complete all daily goals', hi: 'सभी दैनिक लक्ष्य पूरे करें', ur: 'تمام روزانہ اہداف مکمل کریں', mr: 'सर्व दैनिक लक्ष्ये पूर्ण करा' }
            },
            'goal_master': { 
                icon: '🎯', 
                name: { en: 'Goal Master', hi: 'गोल मास्टर', ur: 'ہدف ماسٹر', mr: 'गोल मास्टर' },
                desc: { en: 'Complete 10 goals', hi: '10 लक्ष्य पूरे करें', ur: '10 اہداف مکمل کریں', mr: '10 लक्ष्ये पूर्ण करा' }
            }
        };

        badgesGrid.innerHTML = '';
        
        this.progress.achievements.forEach(achievementKey => {
            const achievement = achievements[achievementKey];
            if (achievement) {
                const badgeDiv = document.createElement('div');
                badgeDiv.className = 'badge-item';
                badgeDiv.innerHTML = `
                    <div class="badge-icon">${achievement.icon}</div>
                    <div class="badge-content">
                        <div class="badge-name">${achievement.name[this.currentLanguage] || achievement.name.en}</div>
                        <div class="badge-desc">${achievement.desc[this.currentLanguage] || achievement.desc.en}</div>
                    </div>
                `;
                badgesGrid.appendChild(badgeDiv);
            }
        });

        // Show placeholder if no achievements
        if (this.progress.achievements.length === 0) {
            badgesGrid.innerHTML = `
                <div class="badge-item" style="grid-column: 1 / -1; text-align: center; opacity: 0.7;">
                    <div class="badge-icon">🎯</div>
                    <div class="badge-content">
                        <div class="badge-name">${this.getTranslation('no_achievements')}</div>
                        <div class="badge-desc">${this.getTranslation('complete_goals')}</div>
                    </div>
                </div>
            `;
        }
    }

    updateTranslations() {
        const elements = document.querySelectorAll('[data-translate]');
        elements.forEach(element => {
            const key = element.getAttribute('data-translate');
            const translation = this.getTranslation(key);
            if (translation) {
                element.textContent = translation;
            }
        });
    }

    getTranslation(key) {
        const translations = {
            'progress_title': {
                'en': 'Daily Progress Tracker',
                'hi': 'दैनिक प्रगति ट्रैकर',
                'ur': 'روزانہ پیش رفت ٹریکر',
                'mr': 'दैनिक प्रगती ट्रॅकर'
            },
            'progress_subtitle': {
                'en': 'Track your growth journey with AI Bhai',
                'hi': 'AI भाई के साथ अपनी growth journey ट्रैक करें',
                'ur': 'AI بھائی کے ساتھ اپنی growth journey ٹریک کریں',
                'mr': 'AI भाऊसोबत तुमची वाढ जर्नी ट्रॅक करा'
            },
            'day_streak': {
                'en': 'Day Streak',
                'hi': 'दिन स्ट्रीक',
                'ur': 'دنوں کا تسلسل',
                'mr': 'दिवस स्ट्रीक'
            },
            'streak_motivation': {
                'en': 'Every day you show up, you\'re one step closer to your dreams!',
                'hi': 'हर दिन जब आप show up करते हैं, आप अपने सपनों के एक कदम और करीब होते हैं!',
                'ur': 'ہر دن جب آپ show up کرتے ہیں، آپ اپنے خوابوں کے ایک قدم اور قریب ہوتے ہیں!',
                'mr': 'प्रत्येक दिवस तुम्ही show up करता, तुम तुमच्या स्वप्नांपासून एक पाऊल जवळ येता!'
            },
            'todays_goals': {
                'en': 'Today\'s Goals',
                'hi': 'आज के लक्ष्य',
                'ur': 'آج کے اہداف',
                'mr': 'आजची लक्ष्ये'
            },
            'read_motivation': {
                'en': 'Read Motivation',
                'hi': 'मोटिवेशन पढ़ें',
                'ur': 'حوصلہ افزائی پڑھیں',
                'mr': 'प्रेरणा वाचा'
            },
            'read_story': {
                'en': 'Read Story',
                'hi': 'कहानी पढ़ें',
                'ur': 'کہانی پڑھیں',
                'mr': 'कथा वाचा'
            },
            'share_content': {
                'en': 'Share Content',
                'hi': 'कंटेंट शेयर करें',
                'ur': 'مواد شیئر کریں',
                'mr': 'सामग्री शेअर करा'
            },
            'learn_skill': {
                'en': 'Learn Skill',
                'hi': 'स्किल सीखें',
                'ur': 'ہنر سیکھیں',
                'mr': 'कौशल्य शिका'
            },
            'goals_completed': {
                'en': 'Goals Completed',
                'hi': 'लक्ष्य पूरे',
                'ur': 'مکمل اہداف',
                'mr': 'पूर्ण लक्ष्ये'
            },
            'completion_rate': {
                'en': 'Completion Rate',
                'hi': 'पूरा होने की दर',
                'ur': 'تکمیلی شرح',
                'mr': 'पूर्णता दर'
            },
            'total_days': {
                'en': 'Total Days',
                'hi': 'कुल दिन',
                'ur': 'کل دن',
                'mr': 'एकूण दिवस'
            },
            'achievements': {
                'en': 'Achievements',
                'hi': 'उपलब्धियां',
                'ur': 'کامیابیاں',
                'mr': 'यश'
            },
            'share_progress': {
                'en': 'Share Progress',
                'hi': 'प्रोग्रेस शेयर करें',
                'ur': 'پیش رفت شیئر کریں',
                'mr': 'प्रगती शेअर करा'
            },
            'reset_progress': {
                'en': 'Reset Progress',
                'hi': 'प्रोग्रेस रीसेट करें',
                'ur': 'پیش رفت ری سیٹ کریں',
                'mr': 'प्रगती रीसेट करा'
            },
            'no_achievements': {
                'en': 'No Achievements Yet',
                'hi': 'अभी तक कोई उपलब्धि नहीं',
                'ur': 'ابھی تک کوئی کامیابی نہیں',
                'mr': 'अद्याप काही यश नाही'
            },
            'complete_goals': {
                'en': 'Complete goals to unlock achievements',
                'hi': 'उपलब्धियां अनलॉक करने के लिए लक्ष्य पूरे करें',
                'ur': 'کامیابیاں انلاک کرنے کے لیے اہداف مکمل کریں',
                'mr': 'यश अनलॉक करण्यासाठी लक्ष्ये पूर्ण करा'
            }
        };

        return translations[key]?.[this.currentLanguage] || translations[key]?.['en'];
    }

    shareProgress() {
        const shareText = {
            'en': `I've maintained a ${this.progress.streak}-day streak on DK Community! 🚀\nJoin me in this growth journey with Deepak Chauhan × AI Bhai!`,
            'hi': `मैंने DK Community पर ${this.progress.streak}-दिन का streak बनाए रखा है! 🚀\nDeepak Chauhan × AI Bhai के साथ इस growth journey में मेरे साथ जुड़ें!`,
            'ur': `میں نے DK Community پر ${this.progress.streak}-دنوں کا streak برقرار رکھا ہے! 🚀\nDeepak Chauhan × AI Bhai کے ساتھ اس growth journey میں میرے ساتھ جڑیں!`,
            'mr': `मी DK Community वर ${this.progress.streak}-दिवसांचा streak राखला आहे! 🚀\nDeepak Chauhan × AI Bhai सोबत या growth journey मध्ये मला सामील व्हा!`
        };

        const text = shareText[this.currentLanguage] || shareText.en;

        if (navigator.share) {
            navigator.share({
                title: 'My Progress - DK Community',
                text: text,
                url: window.location.href
            });
        } else {
            navigator.clipboard.writeText(text);
            alert(this.getTranslation('progress_copied') || 'Progress copied to clipboard!');
        }
    }

    resetProgress() {
        if (confirm(this.getTranslation('confirm_reset') || 'Are you sure you want to reset all progress? This cannot be undone.')) {
            localStorage.removeItem(this.storageKey);
            this.progress = {
                streak: 0,
                lastDate: null,
                totalDays: 0,
                totalGoalsCompleted: 0,
                goals: {
                    motivation: false,
                    story: false,
                    share: false,
                    learn: false
                },
                achievements: []
            };
            this.saveProgress();
            this.updateDisplay();
        }
    }
}

// Initialize the progress tracker
const progressTracker = new DailyProgressTracker();

// Make functions global for HTML onclick
function updateGoal(goalType) {
    progressTracker.updateGoal(goalType);
}

function shareProgress() {
    progressTracker.shareProgress();
}

function resetProgress() {
    progressTracker.resetProgress();
}