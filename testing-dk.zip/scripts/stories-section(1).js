// AI Bhai Stories Section Functionality
class StoriesSection {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.animateOnScroll();
    }

    setupEventListeners() {
        console.log('Stories section loaded successfully!');
    }

    animateOnScroll() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.animation = 'fadeInUp 0.6s ease forwards';
                }
            });
        });

        const storiesBox = document.querySelector('.stories-box');
        if (storiesBox) {
            observer.observe(storiesBox);
        }
    }
}

// Global function for story button
function openTodayStory() {
    // Show loading
    showLoadingScreen();
    
    setTimeout(() => {
        hideLoadingScreen();
        
        // Get current language for modal
        const currentLang = window.storiesLanguage?.currentLanguage || 'en';
        const modalTexts = {
            'en': {
                'title': "📘 Today's Special Story",
                'share': "📤 Share This Story",
                'features': "✨ What makes our stories special:"
            },
            'hi': {
                'title': "📘 आज की विशेष कहानी",
                'share': "📤 इस कहानी को शेयर करें",
                'features': "✨ क्या खास है हमारी कहानियों में:"
            },
            'ur': {
                'title': "📘 آج کی خاص کہانی",
                'share': "📤 اس کہانی کو شیر کریں",
                'features': "✨ ہماری کہانیوں میں کیا خاص ہے:"
            },
            'mr': {
                'title': "📘 आजची विशेष कथा",
                'share': "📤 ही कथा शेअर करा",
                'features': "✨ आमच्या कथांमध्ये काय विशेष आहे:"
            }
        };
        
        const texts = modalTexts[currentLang] || modalTexts['en'];
        
        // Create modal for the story
        const modalHTML = `
            <div class="story-modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>${texts.title}</h3>
                        <button class="close-modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="modal-story">
                            <p class="modal-story-text" id="modalStoryText"></p>
                            <div class="modal-signature" id="modalSignature"></div>
                        </div>
                        <div class="modal-features">
                            <h4>${texts.features}</h4>
                            <ul>
                                <li>💖 Written from the heart</li>
                                <li>🚀 Daily motivation</li>
                                <li>🤝 Real experiences</li>
                                <li>🎯 Life lessons</li>
                            </ul>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="modal-btn primary" onclick="shareStory()">${texts.share}</button>
                        <button class="modal-btn secondary close-modal">Close</button>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);

        // Update modal content with current language
        const langData = window.storiesLanguage?.languageData[currentLang] || window.storiesLanguage?.languageData['en'];
        document.getElementById('modalStoryText').textContent = langData.storyText;
        document.getElementById('modalSignature').textContent = langData.storySignature;

        // Add modal styles
        const modalStyles = document.createElement('style');
        modalStyles.textContent = `
            .story-modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                backdrop-filter: blur(10px);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 10000;
                animation: fadeIn 0.3s ease;
            }
            .modal-content {
                background: rgba(26, 26, 26, 0.95);
                border-radius: 20px;
                padding: 30px;
                max-width: 500px;
                width: 90%;
                border: 1px solid rgba(255, 255, 255, 0.1);
                box-shadow: 0 20px 60px rgba(0, 255, 128, 0.3);
                animation: slideInUp 0.3s ease;
            }
            .modal-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
                padding-bottom: 15px;
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            }
            .modal-header h3 {
                background: linear-gradient(135deg, #00ff88, #009944);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
                margin: 0;
            }
            .close-modal {
                background: none;
                border: none;
                color: #a0a0a0;
                font-size: 1.5rem;
                cursor: pointer;
                padding: 5px;
            }
            .close-modal:hover {
                color: white;
            }
            .modal-story-text {
                font-size: 1.1rem;
                line-height: 1.6;
                color: #e8e8e8;
                font-style: italic;
                text-align: center;
                margin-bottom: 15px;
            }
            .modal-signature {
                text-align: center;
                font-weight: 600;
                color: #00ff88;
                margin-bottom: 20px;
            }
            .modal-features {
                background: rgba(255, 255, 255, 0.05);
                padding: 20px;
                border-radius: 15px;
                margin-bottom: 20px;
            }
            .modal-features h4 {
                color: #00cc66;
                margin-bottom: 10px;
            }
            .modal-features ul {
                list-style: none;
                padding: 0;
            }
            .modal-features li {
                padding: 5px 0;
                color: #d0d0d0;
            }
            .modal-footer {
                display: flex;
                gap: 10px;
            }
            .modal-btn {
                flex: 1;
                padding: 12px 20px;
                border: none;
                border-radius: 10px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            .modal-btn.primary {
                background: linear-gradient(135deg, #00ff88, #009944);
                color: white;
            }
            .modal-btn.secondary {
                background: rgba(255, 255, 255, 0.1);
                color: white;
                border: 1px solid rgba(255, 255, 255, 0.2);
            }
            .modal-btn:hover {
                transform: translateY(-2px);
            }
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            @keyframes slideInUp {
                from { 
                    opacity: 0;
                    transform: translateY(30px);
                }
                to { 
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        `;
        document.head.appendChild(modalStyles);

        // Close modal functionality
        const modal = document.querySelector('.story-modal');
        const closeButtons = document.querySelectorAll('.close-modal');

        closeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                modal.remove();
                modalStyles.remove();
            });
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
                modalStyles.remove();
            }
        });
    }, 1000);
}

function shareStory() {
    const currentLang = window.storiesLanguage?.currentLanguage || 'en';
    const langData = window.storiesLanguage?.languageData[currentLang] || window.storiesLanguage?.languageData['en'];
    
    const storyText = `${langData.storyText}\n\n${langData.storySignature}\n\nFrom DK Community Stories`;

    if (navigator.share) {
        navigator.share({
            title: "Today's AI Bhai Story",
            text: storyText
        });
    } else {
        navigator.clipboard.writeText(storyText).then(() => {
            showNotification('Story copied to clipboard! 📋');
        });
    }
}

function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #00ff88, #009944);
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        z-index: 10000;
        animation: slideInRight 0.3s ease;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        font-family: 'Poppins', sans-serif;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 2000);
}

// Loading screen functions
function showLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.style.display = 'flex';
        loadingScreen.classList.remove('fade-out');
    }
}

function hideLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.classList.add('fade-out');
        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 500);
    }
}

// Add notification styles
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(notificationStyles);

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new StoriesSection();
});