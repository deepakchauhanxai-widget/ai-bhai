// Global variables
let popupData = null;
const animations = ['slide-from-left', 'slide-from-right', 'slide-from-top', 'slide-from-bottom'];
let currentLanguage = 'en';

// DOM Elements
const aiBhaiBtn = document.getElementById('aiBhaiBtn');
const aiBhaiOverlay = document.getElementById('aiBhaiOverlay');
const aiBhaiPopup = document.getElementById('aiBhaiPopup');

// Fetch JSON data
async function fetchPopupData() {
    try {
        const response = await fetch('assets/success-tip.json');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching JSON data:', error);
        // Fallback data agar fetch fail ho
        return {
            "avatar": "https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=150&h=150&fit=crop&crop=face",
            "tips": {
                "en": {
                    "title": "AI Bhai Success Tips",
                    "success": "Amazing! You're doing great! 🚀",
                    "tip": "Remember: Consistency is key to success. Small daily improvements lead to big results over time.",
                    "share": "Share Success",
                    "tipBtn": "Get More Tips",
                    "close": "Close"
                }
            }
        };
    }
}

// Initialize the app
async function initApp() {
    popupData = await fetchPopupData();
    
    // Add click event listener to button
    aiBhaiBtn.addEventListener('click', showPopup);
    
    console.log('AI Bhai Tips loaded successfully!');
}

// Baaki sab functions same rahenge jaise pehle the...
// Function to get random animation
function getRandomAnimation() {
    return animations[Math.floor(Math.random() * animations.length)];
}

// Function to create popup content
function createPopupContent(lang = 'en') {
    if (!popupData || !popupData.tips[lang]) {
        lang = 'en'; // Fallback to English
    }
    
    const data = popupData.tips[lang];
    
    return `
        <button class="close-btn" id="closePopup">×</button>
        
        <div class="popup-header">
            <div class="avatar-container">
                <img src="${popupData.avatar}" alt="AI Bhai Avatar" class="avatar-image">
            </div>
            <h2 class="popup-title">${data.title}</h2>
        </div>
        
        <div class="popup-content">
            <div class="success-message">
                <span class="success-icon">🎯</span>
                <p class="success-text">${data.success}</p>
            </div>
            
            <div class="tip-content">
                <p>${data.tip}</p>
            </div>
            
            <div class="action-buttons">
                <button class="action-btn share-btn" id="shareBtn">
                    <span>📤</span>
                    ${data.share}
                </button>
                <button class="action-btn tip-btn" id="moreTipsBtn">
                    <span>💡</span>
                    ${data.tipBtn}
                </button>
            </div>
            
            <div class="language-selector">
                <button class="lang-btn ${lang === 'en' ? 'active' : ''}" data-lang="en">English</button>
                <button class="lang-btn ${lang === 'hi' ? 'active' : ''}" data-lang="hi">हिन्दी</button>
                <button class="lang-btn ${lang === 'ur' ? 'active' : ''}" data-lang="ur">اردو</button>
                <button class="lang-btn ${lang === 'mr' ? 'active' : ''}" data-lang="mr">मराठी</button>
            </div>
        </div>
    `;
}

// Function to show popup
function showPopup() {
    if (!popupData) {
        console.error('Popup data not loaded yet');
        return;
    }
    
    const randomAnimation = getRandomAnimation();
    
    // Set popup content
    aiBhaiPopup.innerHTML = createPopupContent(currentLanguage);
    
    // Show overlay
    aiBhaiOverlay.style.display = 'flex';
    
    // Add animation class after a small delay
    setTimeout(() => {
        aiBhaiPopup.classList.add(randomAnimation);
    }, 50);
    
    // Add event listeners for new elements
    addPopupEventListeners();
}

// Function to hide popup
function hidePopup() {
    // Remove all animation classes
    animations.forEach(animation => {
        aiBhaiPopup.classList.remove(animation);
    });
    
    // Hide overlay
    aiBhaiOverlay.style.display = 'none';
}

// Function to change language
function changeLanguage(lang) {
    currentLanguage = lang;
    aiBhaiPopup.innerHTML = createPopupContent(lang);
    addPopupEventListeners();
}

// Function to add event listeners to popup elements
function addPopupEventListeners() {
    // Close button
    const closeBtn = document.getElementById('closePopup');
    if (closeBtn) {
        closeBtn.addEventListener('click', hidePopup);
    }
    
    // Share button
    const shareBtn = document.getElementById('shareBtn');
    if (shareBtn) {
        shareBtn.addEventListener('click', () => {
            alert('Success shared! 🎉');
        });
    }
    
    // More tips button
    const moreTipsBtn = document.getElementById('moreTipsBtn');
    if (moreTipsBtn) {
        moreTipsBtn.addEventListener('click', () => {
            alert('More tips coming soon! 📚');
        });
    }
    
    // Language buttons
    const langButtons = document.querySelectorAll('.lang-btn');
    langButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const lang = e.target.getAttribute('data-lang');
            changeLanguage(lang);
        });
    });
}

// Close popup when clicking outside
aiBhaiOverlay.addEventListener('click', (e) => {
    if (e.target === aiBhaiOverlay) {
        hidePopup();
    }
});

// Close popup with Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && aiBhaiOverlay.style.display === 'flex') {
        hidePopup();
    }
});

// Mobile responsiveness
function handleResize() {
    if (window.innerWidth <= 480) {
        aiBhaiBtn.style.padding = '10px 15px';
        const btnText = aiBhaiBtn.querySelector('.btn-text');
        if (btnText) {
            btnText.style.display = 'none';
        }
    } else {
        aiBhaiBtn.style.padding = '15px 25px';
        const btnText = aiBhaiBtn.querySelector('.btn-text');
        if (btnText) {
            btnText.style.display = 'block';
        }
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initApp();
    handleResize();
    window.addEventListener('resize', handleResize);
});