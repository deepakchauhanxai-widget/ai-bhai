// Progress Tracker - Complete Working JavaScript with Automatic Tracking
let currentUser = null;
let selectedMood = null;
let currentTasks = {
    1: false, 2: false, 3: false, 4: false, 5: false
};

// Automatic Tracking System
let autoTracking = {
    isTracking: false,
    startTime: null,
    totalTime: 0,
    learningTime: 0,
    workTime: 0,
    currentActivity: null,
    activities: [],
    learnings: [],
    intervals: []
};

// Initialize Progress Tracker
function initProgressTracker() {
    console.log('🚀 Progress Tracker Initialized');
    loadUserData();
    loadLeaderboard();
    initAutoTracking(); // Auto tracking initialize
}

// Load User Data
function loadUserData() {
    const savedUser = localStorage.getItem('progressUser');
    if (savedUser) {
        try {
            currentUser = JSON.parse(savedUser);
            showDashboard();
            console.log('✅ User loaded:', currentUser.name);
        } catch (e) {
            console.error('Error loading user:', e);
            showWelcome();
        }
    } else {
        showWelcome();
    }
}

// Show Welcome Section
function showWelcome() {
    document.getElementById('welcomeSection').classList.remove('hidden');
    document.getElementById('dashboardSection').classList.add('hidden');
    currentUser = null;
}

// Show Dashboard
function showDashboard() {
    if (!currentUser) {
        showWelcome();
        return;
    }
    
    document.getElementById('welcomeSection').classList.add('hidden');
    document.getElementById('dashboardSection').classList.remove('hidden');
    
    // Update user info
    document.getElementById('displayUserName').textContent = currentUser.name;
    document.getElementById('displayUserId').textContent = `ID: ${currentUser.user_id}`;
    
    // Reset daily data
    resetDailyData();
    loadUserProgress();
}

// Reset Daily Data
function resetDailyData() {
    // Reset tasks
    currentTasks = {1: false, 2: false, 3: false, 4: false, 5: false};
    const checkboxes = document.querySelectorAll('.task-card input');
    checkboxes.forEach(checkbox => {
        checkbox.checked = false;
    });
    
    // Reset time inputs
    const hoursInput = document.getElementById('hoursInput');
    const minutesInput = document.getElementById('minutesInput');
    if (hoursInput) hoursInput.value = '';
    if (minutesInput) minutesInput.value = '';
    
    // Reset mood
    selectedMood = null;
    const moodOptions = document.querySelectorAll('.mood-option');
    moodOptions.forEach(option => {
        option.classList.remove('active');
    });
    
    // Reset progress
    updateProgress();
}

// Generate Unique User ID
function generateUserID() {
    const nameInput = document.getElementById('userName');
    const name = nameInput.value.trim();
    
    if (!name) {
        showNotification('Please enter your name first!', 'error');
        nameInput.focus();
        return;
    }
    
    if (name.length < 2) {
        showNotification('Name should be at least 2 characters long!', 'error');
        return;
    }
    
    // Generate unique ID
    const timestamp = Date.now().toString(36);
    const randomStr = Math.random().toString(36).substring(2, 6).toUpperCase();
    const userId = `${name.toLowerCase().replace(/\s+/g, '_')}_${timestamp}_${randomStr}`;
    
    // Display user ID
    document.getElementById('userIdValue').textContent = userId;
    document.getElementById('userIdContainer').style.display = 'block';
    
    showNotification('Unique ID generated successfully!', 'success');
    
    return userId;
}

// Copy User ID to Clipboard
function copyUserID() {
    const userId = document.getElementById('userIdValue').textContent;
    if (userId === '-') {
        showNotification('Please generate an ID first!', 'error');
        return;
    }
    
    navigator.clipboard.writeText(userId).then(() => {
        showNotification('User ID copied to clipboard! 📋', 'success');
    }).catch(() => {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = userId;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        showNotification('User ID copied to clipboard! 📋', 'success');
    });
}

// Register User
async function registerUser() {
    const name = document.getElementById('userName').value.trim();
    const userId = document.getElementById('userIdValue').textContent;
    
    if (!name) {
        showNotification('Please enter your name!', 'error');
        return;
    }
    
    if (userId === '-') {
        showNotification('Please generate your ID first!', 'error');
        return;
    }
    
    try {
        showNotification('Creating your account...', 'loading');
        
        const response = await fetch('https://deepakchauhanxai.xyz/dk-api/daily-progress.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'register',
                name: name,
                user_id: userId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Save user data locally
            const userData = {
                name: name,
                user_id: userId,
                registered_at: new Date().toISOString(),
                streak: 0,
                total_points: 0
            };
            
            localStorage.setItem('progressUser', JSON.stringify(userData));
            currentUser = userData;
            
            showNotification('🎉 Account created successfully! Welcome to your success journey!', 'success');
            showDashboard();
            loadLeaderboard();
            
        } else {
            showNotification('Registration failed: ' + data.message, 'error');
        }
        
    } catch (error) {
        console.error('Registration error:', error);
        
        // Fallback to local storage
        const userData = {
            name: name,
            user_id: userId,
            registered_at: new Date().toISOString(),
            streak: 0,
            total_points: 0,
            local_storage: true
        };
        
        localStorage.setItem('progressUser', JSON.stringify(userData));
        currentUser = userData;
        
        showNotification('🎉 Account created (Local Mode)!', 'success');
        showDashboard();
    }
}

// Toggle Task
function toggleTask(taskId) {
    const checkbox = document.getElementById(`task${taskId}`);
    if (checkbox) {
        checkbox.checked = !checkbox.checked;
        currentTasks[taskId] = checkbox.checked;
        updateProgress();
        
        // Add visual feedback
        const taskCard = checkbox.closest('.task-card');
        if (taskCard) {
            taskCard.style.transform = 'scale(0.95)';
            setTimeout(() => {
                taskCard.style.transform = '';
            }, 150);
        }
    }
}

// Update Progress
function updateProgress() {
    const completedTasks = Object.values(currentTasks).filter(Boolean).length;
    const totalTasks = Object.keys(currentTasks).length;
    const tasksPercent = Math.round((completedTasks / totalTasks) * 100);
    
    // Update tasks completed display
    const tasksCompletedEl = document.getElementById('tasksCompleted');
    if (tasksCompletedEl) {
        tasksCompletedEl.textContent = `${completedTasks}/${totalTasks}`;
    }
    
    // Update progress bar
    const goalsProgress = document.getElementById('goalsProgress');
    const goalsPercent = document.getElementById('goalsPercent');
    
    if (goalsProgress && goalsPercent) {
        goalsProgress.style.width = tasksPercent + '%';
        goalsPercent.textContent = tasksPercent + '%';
    }
    
    // Update productivity score
    updateProductivityScore();
}

// Update Time
function updateTime() {
    const hoursInput = document.getElementById('hoursInput');
    const minutesInput = document.getElementById('minutesInput');
    
    const hours = hoursInput ? parseInt(hoursInput.value) || 0 : 0;
    const minutes = minutesInput ? parseInt(minutesInput.value) || 0 : 0;
    
    // Update time display
    const timeSpentEl = document.getElementById('timeSpent');
    if (timeSpentEl) {
        timeSpentEl.textContent = `${hours}h ${minutes}m`;
    }
    
    // Update productivity score
    updateProductivityScore();
}

// Set Mood
function setMood(mood) {
    selectedMood = mood;
    
    // Update UI
    const moodOptions = document.querySelectorAll('.mood-option');
    moodOptions.forEach(option => {
        option.classList.remove('active');
    });
    
    // Add active class to clicked option
    const clickedOption = document.querySelector(`[data-mood="${mood}"]`);
    if (clickedOption) {
        clickedOption.classList.add('active');
    }
    
    // Update productivity score
    updateProductivityScore();
}

// Update Productivity Score
function updateProductivityScore() {
    const completedTasks = Object.values(currentTasks).filter(Boolean).length;
    const totalTasks = Object.keys(currentTasks).length;
    const tasksPercent = Math.round((completedTasks / totalTasks) * 100);
    
    const hoursInput = document.getElementById('hoursInput');
    const minutesInput = document.getElementById('minutesInput');
    
    const hours = hoursInput ? parseInt(hoursInput.value) || 0 : 0;
    const minutes = minutesInput ? parseInt(minutesInput.value) || 0 : 0;
    const totalMinutes = hours * 60 + minutes;
    
    // Auto time se bhi calculate karo
    const autoTotalMinutes = autoTracking.totalTime;
    const effectiveMinutes = Math.max(totalMinutes, autoTotalMinutes);
    
    // Calculate productivity score
    let productivity = tasksPercent * 0.6; // 60% weight to tasks
    
    // Time factor (max 30% weight)
    const timeFactor = Math.min(effectiveMinutes / 480 * 30, 30);
    productivity += timeFactor;
    
    // Mood factor (10% weight)
    if (selectedMood) {
        const moodScores = {
            'awesome': 10,
            'good': 7,
            'okay': 5,
            'tired': 3
        };
        productivity += moodScores[selectedMood] || 0;
    }
    
    // Learning bonus (max 10%)
    const learningBonus = Math.min(autoTracking.learnings.length * 2, 10);
    productivity += learningBonus;
    
    productivity = Math.min(Math.round(productivity), 100);
    
    // Update UI
    const productivityProgress = document.getElementById('productivityProgress');
    const productivityPercent = document.getElementById('productivityPercent');
    const productivityScore = document.getElementById('productivityScore');
    
    if (productivityProgress) productivityProgress.style.width = productivity + '%';
    if (productivityPercent) productivityPercent.textContent = productivity + '%';
    if (productivityScore) productivityScore.textContent = productivity + '%';
}

// Save Daily Progress
async function saveDailyProgress() {
    if (!currentUser) {
        showNotification('Please register first!', 'error');
        return;
    }
    
    const completedTasks = Object.values(currentTasks).filter(Boolean).length;
    const hoursInput = document.getElementById('hoursInput');
    const minutesInput = document.getElementById('minutesInput');
    
    const hours = hoursInput ? parseInt(hoursInput.value) || 0 : 0;
    const minutes = minutesInput ? parseInt(minutesInput.value) || 0 : 0;
    const productivityScoreEl = document.getElementById('productivityScore');
    const productivityScore = productivityScoreEl ? parseInt(productivityScoreEl.textContent) : 0;
    
    if (!selectedMood) {
        showNotification('Please select your mood for today!', 'error');
        return;
    }
    
    if (completedTasks === 0 && hours === 0 && minutes === 0 && autoTracking.totalTime === 0) {
        showNotification('Please complete at least one task or add some time!', 'warning');
        return;
    }
    
    try {
        showNotification('Saving your progress...', 'loading');
        
        // Use automatic time if available, otherwise manual time
        const effectiveTime = autoTracking.totalTime > 0 ? autoTracking.totalTime : (hours * 60 + minutes);
        
        const response = await fetch('https://deepakchauhanxai.xyz/dk-api/daily-progress.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'save_progress',
                user_id: currentUser.user_id,
                name: currentUser.name,
                tasks_completed: completedTasks,
                time_spent: effectiveTime,
                mood: selectedMood,
                productivity_score: productivityScore,
                date: new Date().toISOString().split('T')[0],
                auto_data: {
                    total_time: autoTracking.totalTime,
                    learning_time: autoTracking.learningTime,
                    activities_count: autoTracking.activities.length,
                    learnings_count: autoTracking.learnings.length
                }
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('✅ Amazing! Your progress has been saved successfully!', 'success');
            
            // Update local user data
            if (data.streak && data.total_points) {
                currentUser.streak = data.streak;
                currentUser.total_points = data.total_points;
                localStorage.setItem('progressUser', JSON.stringify(currentUser));
                
                // Update UI
                const streakCountEl = document.getElementById('streakCount');
                if (streakCountEl) {
                    streakCountEl.textContent = data.streak;
                }
            }
            
            loadLeaderboard();
            saveAutoTrackingData();
            
        } else {
            showNotification('Save failed: ' + data.message, 'error');
        }
        
    } catch (error) {
        console.error('Save error:', error);
        showNotification('✅ Progress saved locally!', 'success');
        saveAutoTrackingData();
    }
}

// Load User Progress
async function loadUserProgress() {
    if (!currentUser) return;
    
    try {
        const response = await fetch('https://deepakchauhanxai.xyz/dk-api/daily-progress.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'get_user_stats',
                user_id: currentUser.user_id
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Update streak
            const streakCountEl = document.getElementById('streakCount');
            if (streakCountEl) {
                streakCountEl.textContent = data.streak || 0;
            }
            
            // Update user data locally
            currentUser.streak = data.streak;
            currentUser.total_points = data.total_points;
            localStorage.setItem('progressUser', JSON.stringify(currentUser));
        }
    } catch (error) {
        console.error('Load progress error:', error);
    }
}

// Load Leaderboard
async function loadLeaderboard() {
    try {
        const leaderboardList = document.getElementById('leaderboardList');
        if (!leaderboardList) return;
        
        leaderboardList.innerHTML = `
            <div class="leaderboard-item loading">
                <div class="rank">-</div>
                <div class="user-info">
                    <div class="user-avatar">👤</div>
                    <div class="user-details">
                        <span class="user-name">Loading leaders...</span>
                        <span class="user-stats">🔥 0 days • ⭐ 0 points</span>
                    </div>
                </div>
            </div>
        `;
        
        const response = await fetch('https://deepakchauhanxai.xyz/dk-api/daily-progress.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'get_leaderboard'
            })
        });
        
        const data = await response.json();
        
        if (data.success && data.leaderboard && data.leaderboard.length > 0) {
            leaderboardList.innerHTML = '';
            
            data.leaderboard.forEach((user, index) => {
                const rankColors = ['#FFD700', '#C0C0C0', '#CD7F32'];
                const rankIcon = ['🥇', '🥈', '🥉'][index] || '🎯';
                
                const item = document.createElement('div');
                item.className = 'leaderboard-item';
                item.innerHTML = `
                    <div class="rank" style="background: ${rankColors[index] || '#ff0080'}">${index + 1}</div>
                    <div class="user-info">
                        <div class="user-avatar">${rankIcon}</div>
                        <div class="user-details">
                            <span class="user-name">${user.name}</span>
                            <span class="user-stats">🔥 ${user.streak || 0} days • ⭐ ${user.points || 0} points</span>
                        </div>
                    </div>
                `;
                leaderboardList.appendChild(item);
            });
        } else {
            leaderboardList.innerHTML = `
                <div class="leaderboard-item">
                    <div class="rank">🏆</div>
                    <div class="user-info">
                        <div class="user-avatar">👑</div>
                        <div class="user-details">
                            <span class="user-name">Be the First Leader!</span>
                            <span class="user-stats">Start tracking your progress today</span>
                        </div>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        console.error('Leaderboard load error:', error);
        const leaderboardList = document.getElementById('leaderboardList');
        if (leaderboardList) {
            leaderboardList.innerHTML = `
                <div class="leaderboard-item">
                    <div class="rank">❌</div>
                    <div class="user-info">
                        <div class="user-avatar">⚠️</div>
                        <div class="user-details">
                            <span class="user-name">Failed to load leaderboard</span>
                            <span class="user-stats">Please check your connection</span>
                        </div>
                    </div>
                </div>
            `;
        }
    }
}

// View Statistics
function viewStatistics() {
    showNotification('📊 Detailed analytics and statistics coming soon!', 'info');
}

// ==================== AUTOMATIC TRACKING SYSTEM ====================

// Initialize Automatic Tracking
function initAutoTracking() {
    // Load saved data
    const savedData = localStorage.getItem('autoTrackingData');
    if (savedData) {
        try {
            const parsed = JSON.parse(savedData);
            autoTracking = { ...autoTracking, ...parsed };
        } catch (e) {
            console.error('Error loading auto tracking data:', e);
        }
    }
    
    // Reset daily data if new day
    const lastSave = localStorage.getItem('lastAutoSaveDate');
    const today = new Date().toDateString();
    
    if (lastSave !== today) {
        // New day - reset tracking
        autoTracking.totalTime = 0;
        autoTracking.learningTime = 0;
        autoTracking.workTime = 0;
        autoTracking.activities = [];
        autoTracking.learnings = [];
    }
    
    updateTimeDisplays();
    updateActivitiesList();
    updateLearningList();
    
    // Add welcome activity
    addAutoActivity('Progress tracker started', 'start');
}

// Start Automatic Time Tracking
function startTimeTracking() {
    if (!autoTracking.isTracking) {
        autoTracking.isTracking = true;
        autoTracking.startTime = new Date();
        
        // Start time intervals
        startTimeIntervals();
        
        showNotification('⏱️ Automatic time tracking started!', 'success');
        
        const autoTimeBtn = document.querySelector('.auto-time-btn');
        if (autoTimeBtn) {
            autoTimeBtn.innerHTML = '<span>🛑 Stop Tracking</span>';
        }
        
        // Add starting activity
        addAutoActivity('Automatic time tracking started', 'start');
    } else {
        stopTimeTracking();
    }
}

// Stop Automatic Time Tracking
function stopTimeTracking() {
    if (autoTracking.isTracking) {
        autoTracking.isTracking = false;
        
        // Clear all intervals
        autoTracking.intervals.forEach(interval => {
            clearInterval(interval);
        });
        autoTracking.intervals = [];
        
        // Calculate final time
        const endTime = new Date();
        const sessionTime = Math.round((endTime - autoTracking.startTime) / 1000 / 60);
        
        // Add to total time
        autoTracking.totalTime += sessionTime;
        
        showNotification(`🛑 Tracking stopped. Session: ${sessionTime} minutes`, 'info');
        
        const autoTimeBtn = document.querySelector('.auto-time-btn');
        if (autoTimeBtn) {
            autoTimeBtn.innerHTML = '<span>🎯 Start Automatic Tracking</span>';
        }
        
        // Add stopping activity
        addAutoActivity('Automatic time tracking stopped', 'stop');
        
        updateTimeDisplays();
        saveAutoTrackingData();
    }
}

// Start Time Intervals
function startTimeIntervals() {
    // Update time every minute
    const timeInterval = setInterval(() => {
        if (!autoTracking.isTracking) {
            clearInterval(timeInterval);
            return;
        }
        
        autoTracking.totalTime += 1; // Add 1 minute
        
        // Auto-detect activity type based on time and context
        detectActivityType();
        
        updateTimeDisplays();
        
    }, 60000);
    autoTracking.intervals.push(timeInterval);
    
    // Auto-save every 5 minutes
    const saveInterval = setInterval(() => {
        if (!autoTracking.isTracking) {
            clearInterval(saveInterval);
            return;
        }
        autoSaveProgress();
    }, 300000);
    autoTracking.intervals.push(saveInterval);
}

// Detect Activity Type Automatically
function detectActivityType() {
    const hour = new Date().getHours();
    
    // Simple time-based detection
    if (hour >= 6 && hour <= 10) {
        autoTracking.currentActivity = 'morning_routine';
        autoTracking.workTime += 1;
    } else if (hour >= 9 && hour <= 17) {
        // Check if learning-related keywords in recent activities
        const recentActivities = autoTracking.activities.slice(-3);
        const hasLearning = recentActivities.some(activity => 
            activity.text.toLowerCase().includes('learn') ||
            activity.text.toLowerCase().includes('study') ||
            activity.text.toLowerCase().includes('read') ||
            activity.text.toLowerCase().includes('course')
        );
        
        if (hasLearning) {
            autoTracking.currentActivity = 'learning';
            autoTracking.learningTime += 1;
        } else {
            autoTracking.currentActivity = 'work';
            autoTracking.workTime += 1;
        }
    } else if (hour >= 18 && hour <= 22) {
        autoTracking.currentActivity = 'evening_review';
        autoTracking.workTime += 1;
    } else {
        autoTracking.currentActivity = 'personal_time';
    }
    
    // Add auto activity based on detection
    const activityTexts = {
        'morning_routine': 'Morning routine time',
        'learning': 'Learning session',
        'work': 'Work session', 
        'evening_review': 'Evening review time',
        'personal_time': 'Personal time'
    };
    
    addAutoActivity(activityTexts[autoTracking.currentActivity] || 'Active time', 'auto');
}

// Update Time Displays
function updateTimeDisplays() {
    const totalHours = Math.floor(autoTracking.totalTime / 60);
    const totalMinutes = autoTracking.totalTime % 60;
    
    const learningHours = Math.floor(autoTracking.learningTime / 60);
    const learningMinutes = autoTracking.learningTime % 60;
    
    const workHours = Math.floor(autoTracking.workTime / 60);
    const workMinutes = autoTracking.workTime % 60;
    
    const autoTotalTimeEl = document.getElementById('autoTotalTime');
    const autoLearningTimeEl = document.getElementById('autoLearningTime');
    const autoWorkTimeEl = document.getElementById('autoWorkTime');
    
    if (autoTotalTimeEl) autoTotalTimeEl.textContent = `${totalHours}h ${totalMinutes}m`;
    if (autoLearningTimeEl) autoLearningTimeEl.textContent = `${learningHours}h ${learningMinutes}m`;
    if (autoWorkTimeEl) autoWorkTimeEl.textContent = `${workHours}h ${workMinutes}m`;
    
    // Update manual time inputs automatically
    const hoursInput = document.getElementById('hoursInput');
    const minutesInput = document.getElementById('minutesInput');
    
    if (hoursInput && minutesInput) {
        hoursInput.value = totalHours;
        minutesInput.value = totalMinutes;
    }
    
    // Update progress automatically
    updateProgress();
}

// Add Automatic Activity
function addAutoActivity(text, type = 'auto') {
    const activity = {
        text: text,
        time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        type: type,
        timestamp: new Date()
    };
    
    autoTracking.activities.unshift(activity);
    updateActivitiesList();
    
    // Keep only last 10 activities
    if (autoTracking.activities.length > 10) {
        autoTracking.activities = autoTracking.activities.slice(0, 10);
    }
}

// Add Quick Activity Manually
function addQuickActivity() {
    const input = document.getElementById('quickActivityInput');
    if (!input) return;
    
    const text = input.value.trim();
    
    if (!text) {
        showNotification('Please enter an activity!', 'error');
        return;
    }
    
    addAutoActivity(text, 'manual');
    input.value = '';
    
    // Auto-detect if it's learning related
    if (text.toLowerCase().includes('learn') || 
        text.toLowerCase().includes('study') || 
        text.toLowerCase().includes('read') ||
        text.toLowerCase().includes('course')) {
        
        // Suggest adding to learning
        setTimeout(() => {
            const learningInput = document.getElementById('learningInput');
            if (learningInput && confirm('Would you like to add this to your learning list?')) {
                learningInput.value = text;
                addLearning();
            }
        }, 500);
    }
}

// Update Activities List
function updateActivitiesList() {
    const list = document.getElementById('activitiesList');
    if (!list) return;
    
    list.innerHTML = '';
    
    autoTracking.activities.forEach(activity => {
        const item = document.createElement('div');
        item.className = 'activity-item';
        item.innerHTML = `
            <span class="activity-icon">${getActivityIcon(activity.type)}</span>
            <span class="activity-text">${activity.text}</span>
            <span class="activity-time">${activity.time}</span>
        `;
        list.appendChild(item);
    });
}

// Get Activity Icon
function getActivityIcon(type) {
    const icons = {
        'start': '🎯',
        'stop': '🛑',
        'auto': '🤖',
        'manual': '✍️',
        'morning_routine': '🌅',
        'learning': '📚',
        'work': '💻',
        'evening_review': '📝',
        'personal_time': '😴'
    };
    return icons[type] || '📌';
}

// Add Learning
function addLearning() {
    const input = document.getElementById('learningInput');
    if (!input) return;
    
    const text = input.value.trim();
    
    if (!text) {
        showNotification('Please enter what you learned!', 'error');
        return;
    }
    
    const learning = {
        text: text,
        time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        timestamp: new Date()
    };
    
    autoTracking.learnings.unshift(learning);
    updateLearningList();
    input.value = '';
    
    // Update learning stats
    const topicsLearnedEl = document.getElementById('topicsLearned');
    const skillsGainedEl = document.getElementById('skillsGained');
    
    if (topicsLearnedEl) topicsLearnedEl.textContent = autoTracking.learnings.length;
    if (skillsGainedEl) skillsGainedEl.textContent = Math.min(autoTracking.learnings.length, 10);
    
    showNotification('📚 Learning added successfully!', 'success');
}

// Update Learning List
function updateLearningList() {
    const list = document.getElementById('learningList');
    if (!list) return;
    
    list.innerHTML = '';
    
    autoTracking.learnings.forEach(learning => {
        const item = document.createElement('div');
        item.className = 'learn-item';
        item.innerHTML = `
            <span class="activity-icon">📖</span>
            <span class="learn-item-text">${learning.text}</span>
            <span class="learn-item-time">${learning.time}</span>
        `;
        list.appendChild(item);
    });
}

// Auto-save Progress
function autoSaveProgress() {
    if (autoTracking.isTracking && currentUser) {
        saveAutoTrackingData();
        
        // Auto-save if significant progress
        const completedTasks = Object.values(currentTasks).filter(Boolean).length;
        if (completedTasks > 0 || autoTracking.totalTime > 30) {
            // Optional: Auto-save to server
            // saveDailyProgress();
        }
    }
}

// Save Automatic Tracking Data
function saveAutoTrackingData() {
    localStorage.setItem('autoTrackingData', JSON.stringify(autoTracking));
    localStorage.setItem('lastAutoSaveDate', new Date().toDateString());
}

// Show Notification
function showNotification(message, type = 'info') {
    // Remove existing notification
    const existingNotification = document.querySelector('.progress-notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `progress-notification progress-notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">${getNotificationIcon(type)}</span>
            <span class="notification-message">${message}</span>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        z-index: 10000;
        animation: slideInRight 0.3s ease;
        max-width: 400px;
        border-left: 4px solid ${getNotificationBorderColor(type)};
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Helper function for notification icons
function getNotificationIcon(type) {
    const icons = {
        'success': '✅',
        'error': '❌',
        'warning': '⚠️',
        'info': 'ℹ️',
        'loading': '⏳'
    };
    return icons[type] || '💡';
}

// Helper function for notification colors
function getNotificationColor(type) {
    const colors = {
        'success': 'linear-gradient(45deg, #00b09b, #96c93d)',
        'error': 'linear-gradient(45deg, #ff416c, #ff4b2b)',
        'warning': 'linear-gradient(45deg, #f7971e, #ffd200)',
        'info': 'linear-gradient(45deg, #4facfe, #00f2fe)',
        'loading': 'linear-gradient(45deg, #667eea, #764ba2)'
    };
    return colors[type] || '#667eea';
}

function getNotificationBorderColor(type) {
    const colors = {
        'success': '#00b09b',
        'error': '#ff416c',
        'warning': '#f7971e',
        'info': '#4facfe',
        'loading': '#667eea'
    };
    return colors[type] || '#667eea';
}

// Add notification animations to CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        initProgressTracker();
    }, 1000);
});

// Export functions for global access
window.toggleTask = toggleTask;
window.setMood = setMood;
window.generateUserID = generateUserID;
window.copyUserID = copyUserID;
window.registerUser = registerUser;
window.saveDailyProgress = saveDailyProgress;
window.viewStatistics = viewStatistics;
window.startTimeTracking = startTimeTracking;
window.addQuickActivity = addQuickActivity;
window.addLearning = addLearning;