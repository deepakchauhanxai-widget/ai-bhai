class CommunityWall {
    constructor() {
        this.currentLanguage = 'en';
        this.posts = [];
        this.currentPage = 1;
        this.postsPerPage = 5;
        this.init();
    }

    init() {
        this.loadLanguage();
        this.loadPosts();
        this.bindEvents();
    }

    bindEvents() {
        // Load more posts
        document.getElementById('loadMorePosts').addEventListener('click', () => {
            this.loadMorePosts();
        });

        // Language change event
        document.addEventListener('languageChanged', (e) => {
            this.currentLanguage = e.detail.language;
            this.renderPosts();
        });

        // Close modal when clicking outside
        document.getElementById('createPostModal').addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
                this.closeCreatePost();
            }
        });
    }

    loadLanguage() {
        const langBtn = document.getElementById('langToggle');
        if (langBtn) {
            const currentLang = langBtn.querySelector('.current-lang').textContent;
            this.currentLanguage = this.getLanguageFromEmoji(currentLang);
        }
    }

    getLanguageFromEmoji(emoji) {
        const langMap = {
            '🇮🇳': 'hi',
            '🇺🇸': 'en', 
            '🇵🇰': 'ur',
            'mr': 'mr'
        };
        return langMap[emoji] || 'en';
    }

    async loadPosts() {
        try {
            const response = await fetch('data/community-posts.json');
            const data = await response.json();
            this.posts = data.posts;
            this.renderPosts();
        } catch (error) {
            console.error('Error loading posts:', error);
            this.loadSamplePosts();
        }
    }

    loadSamplePosts() {
        this.posts = [
            {
                id: 1,
                user: {
                    name: "Deepak Chauhan",
                    avatar: "images/AI-bhai.png",
                    role: "Founder"
                },
                content: {
                    en: "Welcome to our community wall! Share your thoughts and connect with others.",
                    hi: "हमारे community wall में आपका स्वागत है! अपने विचार साझा करें और दूसरों से जुड़ें।",
                    ur: "ہماری community wall میں خوش آمدید! اپنے خیالات شیئر کریں اور دوسروں سے جڑیں۔",
                    mr: "आमच्या community wall मध्ये स्वागत आहे! तुमचे विचार शेअर करा आणि इतरांशी जोडा."
                },
                image: "",
                timestamp: new Date().toISOString(),
                likes: 25,
                comments: 3,
                shares: 1,
                isLiked: false
            }
        ];
        this.renderPosts();
    }

    renderPosts() {
        const container = document.getElementById('postsContainer');
        const postsToShow = this.posts.slice(0, this.currentPage * this.postsPerPage);

        container.innerHTML = postsToShow.map(post => this.createPostHTML(post)).join('');

        // Update load more button
        const loadMoreBtn = document.getElementById('loadMorePosts');
        if (this.currentPage * this.postsPerPage >= this.posts.length) {
            loadMoreBtn.style.display = 'none';
        } else {
            loadMoreBtn.style.display = 'inline-flex';
        }

        this.updateTranslations();
    }

    createPostHTML(post) {
        const content = post.content[this.currentLanguage] || post.content.en;
        const timeAgo = this.getTimeAgo(post.timestamp);
        
        return `
            <div class="post-card" data-post-id="${post.id}">
                <div class="post-header">
                    <img src="${post.user.avatar}" alt="${post.user.name}" class="user-avatar" onerror="this.src='images/AI-bhai.png'">
                    <div class="user-info">
                        <h3 class="user-name">${post.user.name}</h3>
                        <p class="user-role">${post.user.role}</p>
                    </div>
                    <div class="post-time">${timeAgo}</div>
                </div>
                <div class="post-content">
                    <p class="post-text">${content}</p>
                    ${post.image ? `<img src="${post.image}" alt="Post image" class="post-image" onerror="this.style.display='none'">` : ''}
                </div>
                <div class="post-actions">
                    <button class="action-button ${post.isLiked ? 'liked' : ''}" onclick="communityWall.likePost(${post.id})">
                        <span class="action-icon">❤️</span>
                        <span class="action-count">${post.likes}</span>
                        <span data-translate="like">Like</span>
                    </button>
                    <button class="action-button" onclick="communityWall.commentOnPost(${post.id})">
                        <span class="action-icon">💬</span>
                        <span class="action-count">${post.comments}</span>
                        <span data-translate="comment">Comment</span>
                    </button>
                    <button class="action-button" onclick="communityWall.sharePost(${post.id})">
                        <span class="action-icon">📤</span>
                        <span class="action-count">${post.shares}</span>
                        <span data-translate="share">Share</span>
                    </button>
                </div>
            </div>
        `;
    }

    getTimeAgo(timestamp) {
        const now = new Date();
        const postTime = new Date(timestamp);
        const diffInSeconds = Math.floor((now - postTime) / 1000);
        
        if (diffInSeconds < 60) return this.getTranslation('just_now');
        if (diffInSeconds < 3600) return Math.floor(diffInSeconds / 60) + this.getTranslation('minutes_ago');
        if (diffInSeconds < 86400) return Math.floor(diffInSeconds / 3600) + this.getTranslation('hours_ago');
        return Math.floor(diffInSeconds / 86400) + this.getTranslation('days_ago');
    }

    loadMorePosts() {
        this.currentPage++;
        this.renderPosts();
    }

    likePost(postId) {
        const post = this.posts.find(p => p.id === postId);
        if (post) {
            post.isLiked = !post.isLiked;
            post.likes += post.isLiked ? 1 : -1;
            this.renderPosts();
        }
    }

    commentOnPost(postId) {
        alert(this.getTranslation('comment_feature') || 'Comment feature coming soon!');
    }

    sharePost(postId) {
        const post = this.posts.find(p => p.id === postId);
        if (post) {
            const content = post.content[this.currentLanguage] || post.content.en;
            
            if (navigator.share) {
                navigator.share({
                    title: 'DK Community Post',
                    text: content,
                    url: window.location.href
                });
            } else {
                navigator.clipboard.writeText(content);
                alert(this.getTranslation('copied_clipboard') || 'Post copied to clipboard!');
            }
            
            post.shares++;
            this.renderPosts();
        }
    }

    openCreatePost() {
        document.getElementById('createPostModal').style.display = 'flex';
    }

    closeCreatePost() {
        document.getElementById('createPostModal').style.display = 'none';
        document.getElementById('postContent').value = '';
    }

    publishPost() {
        const content = document.getElementById('postContent').value.trim();
        if (!content) {
            alert(this.getTranslation('enter_content') || 'Please enter some content for your post.');
            return;
        }

        const newPost = {
            id: Date.now(),
            user: {
                name: this.getTranslation('you') || 'You',
                avatar: 'images/user-avatar.png',
                role: this.getTranslation('community_member') || 'Community Member'
            },
            content: {
                en: content,
                hi: content,
                ur: content,
                mr: content
            },
            image: "",
            timestamp: new Date().toISOString(),
            likes: 0,
            comments: 0,
            shares: 0,
            isLiked: false
        };

        this.posts.unshift(newPost);
        this.renderPosts();
        this.closeCreatePost();
        
        alert(this.getTranslation('post_published') || 'Post published successfully!');
    }

    addImageToPost() {
        alert(this.getTranslation('image_feature') || 'Image upload feature coming soon!');
    }

    addFeeling() {
        alert(this.getTranslation('feeling_feature') || 'Feeling feature coming soon!');
    }

    updateTranslations() {
        const elements = document.querySelectorAll('[data-translate]');
        elements.forEach(element => {
            const key = element.getAttribute('data-translate');
            const translation = this.getTranslation(key);
            if (translation) {
                element.textContent = translation;
            }
        });
    }

    getTranslation(key) {
        const translations = {
            'community_wall': {
                'en': 'Community Wall',
                'hi': 'कम्युनिटी वॉल',
                'ur': 'کمیونٹی وال',
                'mr': 'कम्युनिटी वॉल'
            },
            'community_subtitle': {
                'en': 'Connect, Share and Grow Together',
                'hi': 'जुड़ें, साझा करें और साथ में grow करें',
                'ur': 'جڑیں، شیئر کریں اور مل کر ترقی کریں',
                'mr': 'जोडा, शेअर करा आणि एकत्र वाढा'
            },
            'create_post': {
                'en': 'Create Post',
                'hi': 'पोस्ट बनाएं',
                'ur': 'پوسٹ بنائیں',
                'mr': 'पोस्ट तयार करा'
            },
            'members': {
                'en': 'Members',
                'hi': 'सदस्य',
                'ur': 'اراکین',
                'mr': 'सदस्य'
            },
            'online': {
                'en': 'Online',
                'hi': 'ऑनलाइन',
                'ur': 'آن لائن',
                'mr': 'ऑनलाइन'
            },
            'posts': {
                'en': 'Posts',
                'hi': 'पोस्ट',
                'ur': 'پوسٹس',
                'mr': 'पोस्ट'
            },
            'load_more': {
                'en': 'Load More Posts',
                'hi': 'और पोस्ट लोड करें',
                'ur': 'مزید پوسٹس لوڈ کریں',
                'mr': 'अधिक पोस्ट लोड करा'
            },
            'create_new_post': {
                'en': 'Create New Post',
                'hi': 'नई पोस्ट बनाएं',
                'ur': 'نئی پوسٹ بنائیں',
                'mr': 'नवीन पोस्ट तयार करा'
            },
            'you': {
                'en': 'You',
                'hi': 'आप',
                'ur': 'آپ',
                'mr': 'तू'
            },
            'visible_to_all': {
                'en': 'Visible to all community members',
                'hi': 'सभी community members को visible',
                'ur': 'تمام کمیونٹی اراکین کو نظر آئے گا',
                'mr': 'सर्व कम्युनिटी सदस्यांना दृश्यमान'
            },
            'post_placeholder': {
                'en': 'Share your thoughts with the community...',
                'hi': 'Community के साथ अपने विचार share करें...',
                'ur': 'کمیونٹی کے ساتھ اپنے خیالات شیئر کریں...',
                'mr': 'कम्युनिटी सोबत तुमचे विचार शेअर करा...'
            },
            'add_image': {
                'en': 'Add Image',
                'hi': 'इमेज जोड़ें',
                'ur': 'تصویر شامل کریں',
                'mr': 'प्रतिमा जोडा'
            },
            'feeling': {
                'en': 'Feeling',
                'hi': 'Feeling',
                'ur': 'احساس',
                'mr': 'भावना'
            },
            'cancel': {
                'en': 'Cancel',
                'hi': 'कैंसल',
                'ur': 'کینسل',
                'mr': 'रद्द करा'
            },
            'publish_post': {
                'en': 'Publish Post',
                'hi': 'पोस्ट publish करें',
                'ur': 'پوسٹ شائع کریں',
                'mr': 'पोस्ट प्रकाशित करा'
            },
            'like': {
                'en': 'Like',
                'hi': 'लाइक',
                'ur': 'لائک',
                'mr': 'लाइक'
            },
            'comment': {
                'en': 'Comment',
                'hi': 'कमेंट',
                'ur': 'کمنٹ',
                'mr': 'कमेंट'
            },
            'share': {
                'en': 'Share',
                'hi': 'शेयर',
                'ur': 'شیئر',
                'mr': 'शेयर'
            },
            'just_now': {
                'en': 'Just now',
                'hi': 'अभी',
                'ur': 'ابھی',
                'mr': 'नुकतेच'
            },
            'minutes_ago': {
                'en': 'm ago',
                'hi': 'मिनट पहले',
                'ur': 'منٹ پہلے',
                'mr': 'मिनिटांपूर्वी'
            },
            'hours_ago': {
                'en': 'h ago',
                'hi': 'घंटे पहले',
                'ur': 'گھنٹے پہلے',
                'mr': 'तासांपूर्वी'
            },
            'days_ago': {
                'en': 'd ago',
                'hi': 'दिन पहले',
                'ur': 'دن پہلے',
                'mr': 'दिवसांपूर्वी'
            },
            'comment_feature': {
                'en': 'Comment feature coming soon!',
                'hi': 'Comment feature जल्द आ रही है!',
                'ur': 'کمنٹ فیچر جلد آ رہا ہے!',
                'mr': 'कमेंट फीचर लवकरच येत आहे!'
            },
            'copied_clipboard': {
                'en': 'Post copied to clipboard!',
                'hi': 'पोस्ट clipboard में copy हो गई!',
                'ur': 'پوسٹ کلپ بورڈ میں کاپی ہو گئی!',
                'mr': 'पोस्ट क्लिपबोर्डवर कॉपी झाली!'
            },
            'enter_content': {
                'en': 'Please enter some content for your post.',
                'hi': 'कृपया अपनी पोस्ट के लिए कुछ content enter करें।',
                'ur': 'براہ کرم اپنی پوسٹ کے لیے کچھ مواد درج کریں۔',
                'mr': 'कृपया तुमच्या पोस्टसाठी काही सामग्री प्रविष्ट करा.'
            },
            'post_published': {
                'en': 'Post published successfully!',
                'hi': 'पोस्ट successfully publish हो गई!',
                'ur': 'پوسٹ کامیابی سے شائع ہو گئی!',
                'mr': 'पोस्ट यशस्वीरित्या प्रकाशित झाली!'
            },
            'image_feature': {
                'en': 'Image upload feature coming soon!',
                'hi': 'Image upload feature जल्द आ रही है!',
                'ur': 'تصویر اپ لوڈ فیچر جلد آ رہا ہے!',
                'mr': 'प्रतिमा अपलोड फीचर लवकरच येत आहे!'
            },
            'feeling_feature': {
                'en': 'Feeling feature coming soon!',
                'hi': 'Feeling feature जल्द आ रही है!',
                'ur': 'احساس فیچر جلد آ رہا ہے!',
                'mr': 'भावना फीचर लवकरच येत आहे!'
            },
            'community_member': {
                'en': 'Community Member',
                'hi': 'कम्युनिटी मेंबर',
                'ur': 'کمیونٹی رکن',
                'mr': 'कम्युनिटी सदस्य'
            }
        };

        return translations[key]?.[this.currentLanguage] || translations[key]?.['en'];
    }
}

// Initialize the community wall
const communityWall = new CommunityWall();

// Make functions global for HTML onclick
function openCreatePost() {
    communityWall.openCreatePost();
}

function closeCreatePost() {
    communityWall.closeCreatePost();
}

function publishPost() {
    communityWall.publishPost();
}

function addImageToPost() {
    communityWall.addImageToPost();
}

function addFeeling() {
    communityWall.addFeeling();
}