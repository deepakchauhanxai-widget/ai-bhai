const progressTracker = {
    loadLanguage: function() {
        if (!window.activeLanguage) return;
        const lang = window.activeLanguage;

        const text = {
            en: { title: "Daily Progress Tracker", subtitle: "Track your growth journey with AI Bhai", goals: "Today's Goals", share: "Share Progress", reset: "Reset Progress", streak: "Day Streak", totalGoals: "Goals Completed", completionRate: "Completion Rate", totalDays: "Total Days" },
            hi: { title: "डेली प्रोग्रेस ट्रैकर", subtitle: "AI भाई के साथ अपनी प्रगति ट्रैक करें", goals: "आज के लक्ष्य", share: "प्रगति साझा करें", reset: "रीसेट करें", streak: "दिनों की श्रृंखला", totalGoals: "पूरे किए गए लक्ष्य", completionRate: "पूरा करने की दर", totalDays: "कुल दिन" },
            ur: { title: "ڈیلی پراگریس ٹریکر", subtitle: "AI بھائی کے ساتھ اپنی ترقی کو ٹریک کریں", goals: "آج کے اہداف", share: "پراگریس شیئر کریں", reset: "ری سیٹ کریں", streak: "دنوں کی تسلسل", totalGoals: "مکمل اہداف", completionRate: "تکمیل کی شرح", totalDays: "کل دن" },
            mr: { title: "दैनिक प्रगती ट्रॅकर", subtitle: "AI भाई सोबत तुमची प्रगती ट्रॅक करा", goals: "आजचे उद्दिष्टे", share: "प्रगती शेअर करा", reset: "रीसेट करा", streak: "दिवसांची मालिका", totalGoals: "पूर्ण उद्दिष्टे", completionRate: "पूर्णता दर", totalDays: "एकूण दिवस" }
        };

        const t = text[lang] || text.en;
        const section = document.querySelector(".progress-tracker-section");
        if (!section) return;

        section.querySelector(".progress-header h2").textContent = t.title;
        section.querySelector(".progress-header p").textContent = t.subtitle;
        section.querySelector(".goals-container h3").textContent = t.goals;
        section.querySelector(".streak-label").textContent = t.streak;

        const statLabels = section.querySelectorAll(".stat-label");
        statLabels[0].textContent = t.totalGoals;
        statLabels[1].textContent = t.completionRate;
        statLabels[2].textContent = t.totalDays;

        const buttons = section.querySelectorAll(".progress-actions button");
        buttons[0].innerHTML = `<span class="btn-icon">📤</span> ${t.share}`;
        buttons[1].innerHTML = `<span class="btn-icon">🔄</span> ${t.reset}`;
    }
};

document.addEventListener("DOMContentLoaded", function() {
    document.addEventListener("click", function(e) {
        if (e.target.closest(".lang-dropdown button")) {
            setTimeout(() => {
                if (window.progressTracker) {
                    window.progressTracker.loadLanguage();
                }
            }, 150);
        }
    });
});

window.progressTracker = progressTracker;