// Trending Stories Popup with AI Bhai - 4 Languages Support
class TrendingStoriesPopup {
    constructor() {
        this.popup = document.getElementById('trendingPopup');
        this.openBtn = document.getElementById('trendingStoriesBtn');
        this.closeBtn = document.getElementById('closeTrendingPopup');
        this.loadMoreBtn = document.getElementById('loadMoreStories');
        this.storiesGrid = document.getElementById('storiesGrid');
        this.storiesCount = document.getElementById('storiesCount');
        this.viewsCount = document.getElementById('viewsCount');
        this.likesCount = document.getElementById('likesCount');
        
        this.stories = [];
        this.currentPage = 1;
        this.storiesPerPage = 4;
        this.currentLanguage = this.getStoredLanguage();
        this.totalStories = 0;
        this.totalViews = 0;
        this.totalLikes = 0;
        
        this.init();
    }

    async init() {
        await this.loadStories();
        this.setupEventListeners();
        this.setupLanguageListener();
        this.updateStats();
        console.log('🔥 Trending Stories Popup Initialized');
    }

    async loadStories() {
        try {
            console.log('📁 Loading trending stories from JSON...');
            
            const response = await fetch('./assets/trending-stories.json');
            
            if (response.ok) {
                const data = await response.json();
                this.stories = data.stories;
                console.log('✅ Stories loaded successfully');
            } else {
                throw new Error('JSON not found');
            }
        } catch (error) {
            console.error('❌ Error loading stories:', error);
            console.log('🔄 Using fallback stories data');
            this.loadFallbackStories();
        }
        
        this.renderStories();
    }

    loadFallbackStories() {
        this.stories = [
            {
                id: 1,
                user: {
                    name: "Rahul Sharma",
                    avatar: "images/users/user1.jpg",
                    role: "Motivational Speaker"
                },
                content: {
                    en: "Started my journey with just ₹5000. Today I run a successful business with 50+ employees. Never give up on your dreams!",
                    hi: "मैंने अपनी यात्रा सिर्फ ₹5000 से शुरू की। आज मैं 50+ कर्मचारियों के साथ एक सफल व्यवसाय चलाता हूं। अपने सपनों को कभी मत छोड़ो!",
                    ur: "میں نے اپنا سفر صرف ₹5000 سے شروع کیا۔ آج میں 50+ ملازمین کے ساتھ ایک کامیاب کاروبار چلا رہا ہوں۔ اپنے خوابوں کو کبھی مت چھوڑیں!",
                    mr: "मी फक्त ₹5000 सह माझा प्रवास सुरू केला. आज मी 50+ कर्मचाऱ्यांसह एक यशस्वी व्यवसाय चालवतो. तुमचे स्वप्न कधीही सोडू नका!"
                },
                stats: {
                    views: 12500,
                    likes: 3420,
                    shares: 890,
                    timestamp: "2024-01-15"
                },
                tags: ["success", "business", "motivation"]
            },
            {
                id: 2,
                user: {
                    name: "Priya Patel",
                    avatar: "images/users/user2.jpg",
                    role: "Fitness Coach"
                },
                content: {
                    en: "Lost 25kg in 6 months through consistent effort and healthy lifestyle. Your body can achieve what your mind believes!",
                    hi: "6 महीनों में लगातार प्रयास और स्वस्थ जीवनशैली से 25kg वजन कम किया। आपका शरीर वह हासिल कर सकता है जो आपका मन मानता है!",
                    ur: "6 ماہ میں مسلسل محنت اور صحت مند طرز زندگی سے 25kg وزن کم کیا۔ آپ کا جسم وہ حاصل کر سکتا ہے جو آپ کا دماغ مانتا ہے!",
                    mr: "सातत्य प्रयत्न आणि निरोगी जीवनशैलीद्वारे 6 महिन्यात 25kg वजन कम केले. तुमचे शरीर ते साध्य करू शकते जे तुमचे मन मानते!"
                },
                stats: {
                    views: 18900,
                    likes: 5120,
                    shares: 1200,
                    timestamp: "2024-01-12"
                },
                tags: ["fitness", "health", "transformation"]
            },
            {
                id: 3,
                user: {
                    name: "Amit Kumar",
                    avatar: "images/users/user3.jpg",
                    role: "Software Engineer"
                },
                content: {
                    en: "From failing in college to leading a team at Google. Failure is not the opposite of success, it's part of success!",
                    hi: "कॉलेज में फेल होने से लेकर Google में टीम लीडर बनने तक। असफलता सफलता का विपरीत नहीं है, यह सफलता का हिस्सा है!",
                    ur: "کالج میں ناکامی سے لے کر گوگل میں ٹیم لیڈر بننے تک۔ ناکامی کامیابی کے برعکس نہیں ہے، یہ کامیابی کا حصہ ہے!",
                    mr: "कॉलेजमध्ये नापास होण्यापासून ते Google वर टीम लीडर होण्यापर्यंत. अयशस्वी होणे हे यशाच्या विरुद्ध नाही, ते यशाचा एक भाग आहे!"
                },
                stats: {
                    views: 21500,
                    likes: 6780,
                    shares: 1560,
                    timestamp: "2024-01-10"
                },
                tags: ["career", "technology", "inspiration"]
            },
            {
                id: 4,
                user: {
                    name: "Neha Singh",
                    avatar: "images/users/user4.jpg",
                    role: "Artist & Entrepreneur"
                },
                content: {
                    en: "Sold my first painting for ₹500, now my artworks sell for ₹50,000+. Passion combined with persistence creates magic!",
                    hi: "मैंने अपनी पहली पेंटिंग ₹500 में बेची, अब मेरी कलाकृतियाँ ₹50,000+ में बिकती हैं। जुनून के साथ दृढ़ता जादू बनाती है!",
                    ur: "میں نے اپنی پہلی پینٹنگ ₹500 میں بیچی، اب میری آرٹ ورکس ₹50,000+ میں فروخت ہوتی ہیں۔ جذبہ کے ساتھ استقامت جادو پیدا کرتی ہے!",
                    mr: "मी माझी पहिली चित्रकला ₹500 ला विकली, आता माझी कला कृती ₹50,000+ ला विकली जातात. आवड आणि चिकाटी एकत्रितपणे जादू निर्माण करतात!"
                },
                stats: {
                    views: 16700,
                    likes: 4230,
                    shares: 980,
                    timestamp: "2024-01-08"
                },
                tags: ["art", "entrepreneurship", "success"]
            },
            {
                id: 5,
                user: {
                    name: "Deepak Chauhan",
                    avatar: "images/AI-bhai.png",
                    role: "Community Leader"
                },
                content: {
                    en: "Built this community from 0 to 10,000+ members in 1 year. When we lift others, we rise together!",
                    hi: "1 साल में इस कम्युनिटी को 0 से 10,000+ मेंबर तक बनाया। जब हम दूसरों को उठाते हैं, तो हम साथ में बढ़ते हैं!",
                    ur: "1 سال میں اس کمیونٹی کو 0 سے 10,000+ ممبران تک بنایا۔ جب ہم دوسروں کو اٹھاتے ہیں، تو ہم ایک ساتھ بڑھتے ہیں!",
                    mr: "1 वर्षात या समुदायाला 0 वरून 10,000+ सदस्यांपर्यंत बांधले. जेव्हा आपण इतरांना उचलतो, तेव्हा आपण एकत्र वाढतो!"
                },
                stats: {
                    views: 28900,
                    likes: 8920,
                    shares: 2340,
                    timestamp: "2024-01-05"
                },
                tags: ["community", "growth", "leadership"]
            },
            {
                id: 6,
                user: {
                    name: "Sneha Verma",
                    avatar: "images/users/user5.jpg",
                    role: "Yoga Instructor"
                },
                content: {
                    en: "Healed my chronic back pain through yoga and meditation. Your mind and body have incredible healing power!",
                    hi: "योग और ध्यान के माध्यम से अपने पुराने पीठ दर्द को ठीक किया। आपके मन और शरीर में अविश्वसनीय उपचार शक्ति है!",
                    ur: "یوگا اور مراقبہ کے ذریعے اپنے دائمی کمر کے درد کو ٹھیک کیا۔ آپ کے دماغ اور جسم میں ناقابل یقین شفا یابی کی طاقت ہے!",
                    mr: "योग आणि ध्यानाद्वारे माझे क्रॉनिक पाठदुखी बरे केले. तुमच्या मनाला आणि शरीराला अविश्वसनीय बरे करण्याची शक्ती आहे!"
                },
                stats: {
                    views: 14300,
                    likes: 3870,
                    shares: 760,
                    timestamp: "2024-01-03"
                },
                tags: ["yoga", "health", "meditation"]
            }
        ];
    }

    setupEventListeners() {
        // Open popup
        this.openBtn.addEventListener('click', () => this.openPopup());
        
        // Close popup
        this.closeBtn.addEventListener('click', () => this.closePopup());
        
        // Load more stories
        this.loadMoreBtn.addEventListener('click', () => this.loadMoreStories());
        
        // Close on overlay click
        this.popup.addEventListener('click', (e) => {
            if (e.target === this.popup) {
                this.closePopup();
            }
        });
        
        // Close on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.popup.classList.contains('active')) {
                this.closePopup();
            }
        });
        
        console.log('✅ Event listeners setup');
    }

    setupLanguageListener() {
        // Listen for language changes from existing buttons
        document.addEventListener('languageChanged', (event) => {
            this.currentLanguage = event.detail?.language || this.getStoredLanguage();
            this.renderStories();
        });

        // Also listen to existing language buttons
        const langButtons = document.querySelectorAll('[data-lang]');
        langButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const lang = e.target.getAttribute('data-lang');
                this.currentLanguage = lang;
                localStorage.setItem('preferredLanguage', lang);
                this.renderStories();
            });
        });
    }

    getStoredLanguage() {
        return localStorage.getItem('preferredLanguage') || 'en';
    }

    openPopup() {
        console.log('🔥 Opening trending stories popup');
        this.popup.classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent background scroll
        this.renderStories();
    }

    closePopup() {
        console.log('❌ Closing trending stories popup');
        this.popup.classList.remove('active');
        document.body.style.overflow = ''; // Restore scroll
        this.currentPage = 1; // Reset to first page
    }

    renderStories() {
        if (!this.storiesGrid) return;

        const startIndex = 0;
        const endIndex = this.currentPage * this.storiesPerPage;
        const storiesToShow = this.stories.slice(startIndex, endIndex);

        this.storiesGrid.innerHTML = '';

        storiesToShow.forEach((story, index) => {
            const content = story.content[this.currentLanguage] || story.content.en;
            
            const storyHTML = `
                <div class="story-card" data-id="${story.id}">
                    <div class="story-header">
                        <div class="story-avatar">
                            <img src="${story.user.avatar}" alt="${story.user.name}" 
                                 onerror="this.src='images/AI-bhai.png'">
                        </div>
                        <div class="story-user-info">
                            <h4>${story.user.name}</h4>
                            <p>${story.user.role}</p>
                        </div>
                    </div>
                    
                    <div class="story-content">
                        ${content}
                    </div>
                    
                    <div class="story-tags">
                        ${story.tags.map(tag => `<span class="story-tag">#${tag}</span>`).join('')}
                    </div>
                    
                    <div class="story-stats">
                        <div class="story-stat">
                            <span>👁️</span>
                            <span>${this.formatNumber(story.stats.views)}</span>
                        </div>
                        <div class="story-stat">
                            <span>❤️</span>
                            <span>${this.formatNumber(story.stats.likes)}</span>
                        </div>
                        <div class="story-stat">
                            <span>📤</span>
                            <span>${this.formatNumber(story.stats.shares)}</span>
                        </div>
                        <div class="story-stat">
                            <span>📅</span>
                            <span>${this.formatDate(story.stats.timestamp)}</span>
                        </div>
                    </div>
                </div>
            `;
            
            this.storiesGrid.insertAdjacentHTML('beforeend', storyHTML);
        });

        this.updateStats();
        this.updateLoadMoreButton();
    }

    loadMoreStories() {
        this.currentPage++;
        this.renderStories();
        
        // Show notification
        this.showNotification(`Loaded more trending stories! ✨`);
    }

    updateStats() {
        const totalStories = this.stories.length;
        const totalViews = this.stories.reduce((sum, story) => sum + story.stats.views, 0);
        const totalLikes = this.stories.reduce((sum, story) => sum + story.stats.likes, 0);

        if (this.storiesCount) this.storiesCount.textContent = this.formatNumber(totalStories);
        if (this.viewsCount) this.viewsCount.textContent = this.formatNumber(totalViews);
        if (this.likesCount) this.likesCount.textContent = this.formatNumber(totalLikes);
    }

    updateLoadMoreButton() {
        const totalPages = Math.ceil(this.stories.length / this.storiesPerPage);
        
        if (this.currentPage >= totalPages) {
            this.loadMoreBtn.style.display = 'none';
        } else {
            this.loadMoreBtn.style.display = 'flex';
        }
    }

    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now - date);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) return 'Yesterday';
        if (diffDays < 7) return `${diffDays}d ago`;
        if (diffDays < 30) return `${Math.floor(diffDays / 7)}w ago`;
        return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    }

    showNotification(message) {
        const existingNotification = document.querySelector('.notification');
        if (existingNotification) {
            existingNotification.remove();
        }

        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 2000);
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.trendingPopup = new TrendingStoriesPopup();
});

// Global function to open popup (for onclick attribute)
function openTrendingStories() {
    if (window.trendingPopup) {
        window.trendingPopup.openPopup();
    }
}