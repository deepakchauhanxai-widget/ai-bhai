class CommunityWall {
    constructor() {
        this.currentLanguage = 'en';
        this.username = null;
        this.baseURL = 'https://deepakchauhanxai.xyz/dk-api';
        this.posts = [];
        this.selectedImage = null;
        this.selectedFeeling = null;
        this.init();
    }

    async init() {
        await this.getUsername();
        await this.loadPosts();
        this.bindEvents();
        this.initModal();
    }

    async getUsername() {
        this.username = localStorage.getItem('dkCommunityUsername');
        if (!this.username) {
            this.username = prompt('Enter your name for community posts:') || 'anonymous';
            localStorage.setItem('dkCommunityUsername', this.username);
        }
    }

    initModal() {
        this.setupImageUpload();
        this.setupFeelingSelection();
    }

    setupImageUpload() {
        const imageInput = document.createElement('input');
        imageInput.type = 'file';
        imageInput.accept = 'image/*';
        imageInput.style.display = 'none';
        imageInput.id = 'userImageInput';
        imageInput.name = 'user_image';
        document.body.appendChild(imageInput);

        imageInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                this.handleImageSelect(file);
            }
        });
    }

    handleImageSelect(file) {
        if (file.size > 5 * 1024 * 1024) {
            alert('Image size should be less than 5MB');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            this.selectedImage = file; // Store file object for upload
            this.showImagePreview(e.target.result);
        };
        reader.readAsDataURL(file);
    }

    showImagePreview(imageData) {
        let preview = document.getElementById('imagePreview');
        if (!preview) {
            preview = document.createElement('div');
            preview.id = 'imagePreview';
            preview.className = 'image-preview';
            const modalBody = document.querySelector('.modal-body');
            modalBody.insertBefore(preview, modalBody.querySelector('.post-actions'));
        }

        preview.innerHTML = `
            <div class="preview-container">
                <img src="${imageData}" alt="Selected image" class="preview-image">
                <div class="preview-info">
                    <span>Your profile picture for this post</span>
                    <button class="remove-image" onclick="communityWall.removeImage()">Remove</button>
                </div>
            </div>
        `;
    }

    removeImage() {
        this.selectedImage = null;
        const preview = document.getElementById('imagePreview');
        if (preview) {
            preview.remove();
        }
        document.getElementById('userImageInput').value = '';
    }

    async addImageToPost() {
        document.getElementById('userImageInput').click();
    }

    setupFeelingSelection() {
        this.feelingOptions = ['😊', '😄', '😍', '🔥', '💪', '🚀', '🎯', '🌟', '🙏', '❤️'];
    }

    async addFeeling() {
        const feelingModal = this.createFeelingModal();
        document.body.appendChild(feelingModal);
    }

    createFeelingModal() {
        const modal = document.createElement('div');
        modal.className = 'feeling-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10001;
        `;

        modal.innerHTML = `
            <div class="feeling-content" style="
                background: white;
                border-radius: 15px;
                padding: 20px;
                width: 300px;
                text-align: center;
            ">
                <h3>Select Feeling</h3>
                <div class="feelings-grid" style="
                    display: grid;
                    grid-template-columns: repeat(5, 1fr);
                    gap: 10px;
                    margin: 15px 0;
                ">
                    ${this.feelingOptions.map(feeling => `
                        <button class="feeling-option" onclick="communityWall.selectFeeling('${feeling}')" style="
                            background: none;
                            border: none;
                            font-size: 24px;
                            cursor: pointer;
                            padding: 10px;
                            border-radius: 10px;
                            transition: all 0.3s ease;
                        ">${feeling}</button>
                    `).join('')}
                </div>
                <button onclick="this.closest('.feeling-modal').remove()" style="
                    background: #667eea;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 8px;
                    cursor: pointer;
                ">Cancel</button>
            </div>
        `;

        return modal;
    }

    selectFeeling(feeling) {
        this.selectedFeeling = feeling;
        this.showFeelingPreview();
        
        const modal = document.querySelector('.feeling-modal');
        if (modal) modal.remove();
    }

    showFeelingPreview() {
        let preview = document.getElementById('feelingPreview');
        if (!preview) {
            preview = document.createElement('div');
            preview.id = 'feelingPreview';
            preview.className = 'feeling-preview';
            const modalBody = document.querySelector('.modal-body');
            const postActions = modalBody.querySelector('.post-actions');
            modalBody.insertBefore(preview, postActions.nextSibling);
        }

        preview.innerHTML = `
            <div class="feeling-display">
                <span class="feeling-emoji">${this.selectedFeeling}</span>
                <span class="feeling-text">Feeling ${this.getFeelingText(this.selectedFeeling)}</span>
                <button class="remove-feeling" onclick="communityWall.removeFeeling()">Remove</button>
            </div>
        `;
    }

    getFeelingText(emoji) {
        const feelingMap = {
            '😊': 'Happy', '😄': 'Joyful', '😍': 'Loving', '🔥': 'Motivated',
            '💪': 'Strong', '🚀': 'Excited', '🎯': 'Focused', '🌟': 'Amazing',
            '🙏': 'Thankful', '❤️': 'Loved'
        };
        return feelingMap[emoji] || 'Good';
    }

    removeFeeling() {
        this.selectedFeeling = null;
        const preview = document.getElementById('feelingPreview');
        if (preview) preview.remove();
    }

    async createPost(content) {
        if (!content || !content.trim()) {
            alert('Please enter some content for your post.');
            return;
        }

        let finalContent = content.trim();
        
        if (this.selectedFeeling) {
            finalContent = `${finalContent} ${this.selectedFeeling}`;
        }

        try {
            const formData = new FormData();
            formData.append('action', 'add_post');
            formData.append('user_name', this.username);
            formData.append('content', finalContent);

            if (this.selectedImage) {
                formData.append('user_image', this.selectedImage);
            }

            const response = await fetch(`${this.baseURL}/community-wall.php`, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.resetModal();
                await this.loadPosts();
                alert('Post published successfully! 🚀');
            } else {
                alert('Failed to publish post. Please try again.');
            }
        } catch (error) {
            console.error('Error creating post:', error);
            // Fallback without image upload
            this.createPostWithoutImage(finalContent);
        }
    }

    async createPostWithoutImage(content) {
        try {
            const response = await fetch(`${this.baseURL}/community-wall.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'add_post',
                    user_name: this.username,
                    content: content
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.resetModal();
                await this.loadPosts();
                alert('Post published successfully! 🚀');
            } else {
                throw new Error('API failed');
            }
        } catch (error) {
            // Ultimate fallback - client side only
            const newPost = {
                id: Date.now().toString(),
                user: {
                    name: this.username,
                    avatar: 'images/AI-bhai.png'
                },
                content: {
                    en: content,
                    hi: content,
                    ur: content,
                    mr: content
                },
                timestamp: new Date().toISOString(),
                likes: 0,
                comments: 0,
                shares: 0,
                isLiked: false,
                feeling: this.selectedFeeling
            };
            
            this.posts.unshift(newPost);
            this.renderPosts();
            this.resetModal();
            alert('Post published! (offline mode) 🚀');
        }
    }

    resetModal() {
        const textarea = document.getElementById('postContent');
        if (textarea) textarea.value = '';
        
        this.selectedImage = null;
        this.selectedFeeling = null;
        
        const imagePreview = document.getElementById('imagePreview');
        const feelingPreview = document.getElementById('feelingPreview');
        if (imagePreview) imagePreview.remove();
        if (feelingPreview) feelingPreview.remove();
        
        const fileInput = document.getElementById('userImageInput');
        if (fileInput) fileInput.value = '';
        
        this.closeCreatePost();
    }

    async loadPosts() {
        try {
            const response = await fetch(`${this.baseURL}/community-wall.php?t=${Date.now()}`);
            const data = await response.json();
            
            if (data.success) {
                this.posts = data.posts;
                this.renderPosts();
            } else {
                this.loadSamplePosts();
            }
        } catch (error) {
            this.loadSamplePosts();
        }
    }

    loadSamplePosts() {
        this.posts = [
            {
                id: '1',
                user: {
                    name: "Deepak Chauhan",
                    avatar: "images/AI-bhai.png"
                },
                content: {
                    en: "Welcome to our Community Wall! Share your thoughts and connect with others. 🚀",
                    hi: "हमारे Community Wall में आपका स्वागत है! अपने विचार साझा करें और दूसरों से जुड़ें। 🚀",
                    ur: "ہماری Community Wall میں خوش آمدید! اپنے خیالات شیئر کریں اور دوسروں سے جڑیں۔ 🚀",
                    mr: "आमच्या Community Wall मध्ये स्वागत आहे! तुमचे विचार शेअर करा आणि इतरांशी जोडा. 🚀"
                },
                timestamp: new Date().toISOString(),
                likes: 15,
                comments: 3,
                shares: 2,
                isLiked: false
            }
        ];
        this.renderPosts();
    }

    renderPosts() {
        const container = document.getElementById('postsContainer');
        if (!container) return;

        container.innerHTML = this.posts.map(post => `
            <div class="post-card" data-post-id="${post.id}">
                <div class="post-header">
                    <img src="${post.user.avatar}" alt="${post.user.name}" class="user-avatar" 
                         onerror="this.src='images/AI-bhai.png'">
                    <div class="user-info">
                        <h3 class="user-name">${post.user.name}</h3>
                        <div class="post-time">${this.getTimeAgo(post.timestamp)}</div>
                    </div>
                </div>
                <div class="post-content">
                    <p class="post-text">${post.content[this.currentLanguage] || post.content.en}</p>
                </div>
                <div class="post-actions">
                    <button class="action-button ${post.isLiked ? 'liked' : ''}" onclick="communityWall.likePost('${post.id}')">
                        <span class="action-icon">❤️</span>
                        <span class="action-count">${post.likes}</span>
                        Like
                    </button>
                    <button class="action-button" onclick="communityWall.commentOnPost('${post.id}')">
                        <span class="action-icon">💬</span>
                        <span class="action-count">${post.comments}</span>
                        Comment
                    </button>
                    <button class="action-button" onclick="communityWall.sharePost('${post.id}')">
                        <span class="action-icon">📤</span>
                        <span class="action-count">${post.shares}</span>
                        Share
                    </button>
                </div>
            </div>
        `).join('');
    }

    getTimeAgo(timestamp) {
        const now = new Date();
        const postTime = new Date(timestamp);
        const diffInSeconds = Math.floor((now - postTime) / 1000);
        
        if (diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) return Math.floor(diffInSeconds / 60) + 'm ago';
        if (diffInSeconds < 86400) return Math.floor(diffInSeconds / 3600) + 'h ago';
        return Math.floor(diffInSeconds / 86400) + 'd ago';
    }

    async likePost(postId) {
        try {
            const response = await fetch(`${this.baseURL}/community-wall.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'like_post',
                    post_id: postId
                })
            });
            
            const data = await response.json();
            if (data.success) {
                await this.loadPosts();
            }
        } catch (error) {
            const post = this.posts.find(p => p.id === postId);
            if (post && !post.isLiked) {
                post.likes++;
                post.isLiked = true;
                this.renderPosts();
            }
        }
    }

    commentOnPost(postId) {
        alert('Comment feature coming soon! 💬');
    }

    sharePost(postId) {
        const post = this.posts.find(p => p.id === postId);
        if (post) {
            const content = post.content[this.currentLanguage] || post.content.en;
            
            if (navigator.share) {
                navigator.share({
                    title: 'DK Community Post',
                    text: content,
                    url: window.location.href
                });
            } else {
                navigator.clipboard.writeText(content);
                alert('Post copied to clipboard! 📋');
            }
        }
    }

    bindEvents() {
        document.addEventListener('languageChanged', (e) => {
            this.currentLanguage = e.detail.language;
            this.renderPosts();
        });
    }

    openCreatePost() {
        document.getElementById('createPostModal').style.display = 'flex';
    }

    closeCreatePost() {
        document.getElementById('createPostModal').style.display = 'none';
    }
}

// Initialize community wall
const communityWall = new CommunityWall();

// Global functions for HTML
function openCreatePost() {
    communityWall.openCreatePost();
}

function closeCreatePost() {
    communityWall.closeCreatePost();
}

function publishPost() {
    const content = document.getElementById('postContent')?.value;
    if (content) {
        communityWall.createPost(content);
    }
}

function addImageToPost() {
    communityWall.addImageToPost();
}

function addFeeling() {
    communityWall.addFeeling();
}

// Emergency fix - direct event binding
setTimeout(function() {
    const publishBtn = document.querySelector('.post-btn');
    if (publishBtn) {
        publishBtn.onclick = function() {
            const content = document.getElementById('postContent')?.value;
            if (content) {
                communityWall.createPost(content);
            } else {
                alert('Please enter some content!');
            }
        };
    }
}, 1000);