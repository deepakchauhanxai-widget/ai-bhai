// Motivational Box Functionality for Home Page
class HomeMotivationalBox {
    constructor() {
        this.currentQuoteIndex = 0;
        this.quotesData = [
            {
                id: 1,
                image: "images/motivational/quote1.jpg",
                en: {
                    title: "Secret of Success",
                    shayari: "If your courage is high, you will find your destination, those who try never lose."
                },
                hi: {
                    title: "सफलता का रहस्य",
                    shayari: "हौसले बुलंद हो तो मंजिलें भी मिल जाती हैं, कोशिश करने वालों की कभी हार नहीं होती।"
                },
                ur: {
                    title: "کامیابی کا راز",
                    shayari: "ہمت بلند ہو تو منزلیں بھی مل جاتی ہیں، کوشش کرنے والوں کی کبھی ہار نہیں ہوتی۔"
                },
                mr: {
                    title: "यशाचे रहस्य",
                    shayari: "हौसले उंच असले तर मंजिल मिळते, प्रयत्न करणाऱ्यांचे कधीच पराभव होत नाहीत."
                }
            },
            {
                id: 2,
                image: "images/motivational/quote2.jpg",
                en: {
                    title: "Fruit of Hard Work",
                    shayari: "Work hard consistently, destiny will also change, the magic of waves will flow on the chest of the ocean."
                },
                hi: {
                    title: "मेहनत का फल",
                    shayari: "मेहनत करो सिलसिलेवार, किस्मत भी बदल जाएगी, समंदर के सीने पर लहरों का जादू चल जाएगा।"
                },
                ur: {
                    title: "محنت کا پھل",
                    shayari: "محنت کرو مسلسل، تقدیر بھی بدل جائے گی، سمندر کے سینے پر لہروں کا جادو چل جائے گا۔"
                },
                mr: {
                    title: "मेहनतीचे फळ",
                    shayari: "मेहनत करा सतत, दैवत देखील बदलेल, समुद्राच्या छातीवर लाटांचे जादू चालेल."
                }
            },
            {
                id: 3,
                image: "images/motivational/quote3.jpg",
                en: {
                    title: "Dreams and Reality",
                    shayari: "Dreams are not what you see while sleeping, dreams are what don't let you sleep."
                },
                hi: {
                    title: "सपने और हकीकत",
                    shayari: "सपने वो नहीं जो आप सोते वक्त देखते हैं, सपने वो हैं जो आपको सोने नहीं देते।"
                },
                ur: {
                    title: "خواب اور حقیقت",
                    shayari: "خواب وہ نہیں جو آپ سوتے وقت دیکھتے ہیں، خواب وہ ہیں جو آپ کو سونے نہیں دیتے۔"
                },
                mr: {
                    title: "स्वप्न आणि वास्तव",
                    shayari: "स्वप्ने ती नाहीत जी तुम्ही झोपताना पाहता, स्वप्ने ती आहेत जी तुम्हाला झोपू देत नाहीत."
                }
            }
        ];
        
        this.init();
    }

    init() {
        this.renderBox();
        this.setupLanguageListener();
        this.startAutoRotate();
    }

    renderBox() {
        // Box already exists in HTML, just update content
        this.updateContent();
    }

    setupLanguageListener() {
        // Listen for language changes from main language switcher
        document.addEventListener('languageChanged', (event) => {
            this.updateContent();
        });
        
        // Also update when page loads
        this.updateContent();
    }

    updateContent() {
        const currentLanguage = this.getCurrentLanguage();
        const currentQuote = this.quotesData[this.currentQuoteIndex];
        const content = currentQuote[currentLanguage] || currentQuote.en;

        // Update DOM elements
        const titleElement = document.getElementById('boxTitle');
        const shayariElement = document.getElementById('boxShayari');
        const imageElement = document.getElementById('boxImage');

        if (titleElement) titleElement.textContent = content.title;
        if (shayariElement) shayariElement.textContent = content.shayari;
        if (imageElement) imageElement.src = currentQuote.image;
    }

    getCurrentLanguage() {
        // Get current language from main language switcher
        // You can modify this based on how your main language switcher works
        const currentLangBtn = document.querySelector('.lang-option.active');
        if (currentLangBtn) {
            return currentLangBtn.getAttribute('data-lang') || 'en';
        }
        
        // Fallback to checking URL or localStorage
        return localStorage.getItem('preferredLanguage') || 'en';
    }

    nextQuote() {
        this.currentQuoteIndex = (this.currentQuoteIndex + 1) % this.quotesData.length;
        this.updateContent();
    }

    startAutoRotate() {
        // Change quote every 10 seconds
        setInterval(() => {
            this.nextQuote();
        }, 10000);
    }
}

// Instagram Trending Function
function openInstagramTrending() {
    // Show loading
    showLoadingScreen();
    
    setTimeout(() => {
        hideLoadingScreen();
        alert('📸 Instagram Trending Page\n\nभाई, ये page जल्दी ही launch हो रहा है!\n\n✅ Latest Viral Content\n✅ Instagram Trends\n✅ Popular Reels\n\n📅 Coming Soon...');
    }, 1000);
}

// Loading screen functions (reuse from main script)
function showLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.style.display = 'flex';
        loadingScreen.classList.remove('fade-out');
    }
}

function hideLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.classList.add('fade-out');
        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 500);
    }
}

// Language change event (for main language switcher integration)
function triggerLanguageChange(lang) {
    const event = new CustomEvent('languageChanged', { detail: { language: lang } });
    document.dispatchEvent(event);
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new HomeMotivationalBox();
});