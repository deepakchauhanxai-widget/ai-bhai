// Trending Stories Popup with JSON Loading
console.log('🔥 trending-stories.js loaded successfully!');

class TrendingStoriesPopup {
    constructor() {
        console.log('🔧 Constructor called - looking for elements...');
        
        this.popup = document.getElementById('trendingPopup');
        this.openBtn = document.getElementById('trendingStoriesBtn');
        this.closeBtn = document.getElementById('closeTrendingPopup');
        this.loadMoreBtn = document.getElementById('loadMoreStories');
        this.storiesGrid = document.getElementById('storiesGrid');
        this.storiesCount = document.getElementById('storiesCount');
        this.viewsCount = document.getElementById('viewsCount');
        this.likesCount = document.getElementById('likesCount');
        
        console.log('Popup found:', !!this.popup);
        console.log('Open button found:', !!this.openBtn);
        console.log('Close button found:', !!this.closeBtn);
        console.log('Stories grid found:', !!this.storiesGrid);
        
        if (!this.popup || !this.openBtn) {
            console.error('❌ Required elements not found!');
            return;
        }
        
        this.currentLanguage = this.getCurrentLanguage();
        this.stories = [];
        this.displayedStoryIds = new Set(); // Track displayed stories
        this.storiesPerPage = 3; // Har baar 3 stories
        this.allStories = [];
        
        this.init();
    }

    // Naya method: Current language detect karo
    getCurrentLanguage() {
        // Check URL parameters first
        const urlParams = new URLSearchParams(window.location.search);
        const urlLang = urlParams.get('lang');
        if (urlLang) return urlLang;

        // Check localStorage
        const storedLang = localStorage.getItem('selectedLanguage');
        if (storedLang) return storedLang;

        // Check HTML lang attribute
        const htmlLang = document.documentElement.lang;
        if (htmlLang) return htmlLang;

        // Default to English
        return 'en';
    }

    // Naya method: Language change detect karo
    setupLanguageObserver() {
        // Observe URL changes
        let lastUrl = window.location.href;
        const observer = new MutationObserver(() => {
            const currentUrl = window.location.href;
            if (currentUrl !== lastUrl) {
                lastUrl = currentUrl;
                this.handleLanguageChange();
            }
        });

        observer.observe(document, { subtree: true, childList: true });

        // Listen for storage events (localStorage changes)
        window.addEventListener('storage', (e) => {
            if (e.key === 'selectedLanguage') {
                this.handleLanguageChange();
            }
        });

        // Custom event for language change
        window.addEventListener('languageChanged', () => {
            this.handleLanguageChange();
        });
    }

    handleLanguageChange() {
        const newLanguage = this.getCurrentLanguage();
        console.log('🔄 Language changed to:', newLanguage);
        
        if (newLanguage !== this.currentLanguage) {
            this.currentLanguage = newLanguage;
            
            // Agar popup open hai to stories refresh karo
            if (this.popup.classList.contains('active')) {
                this.renderStories();
            }
        }
    }

    async init() {
        console.log('🎯 Initializing Trending Stories Popup...');
        await this.loadStoriesFromJSON();
        this.setupEventListeners();
        this.setupLanguageObserver(); // Language observer add kiya
        this.updateStats();
        console.log('✅ Trending Stories Popup Ready!');
    }

    async loadStoriesFromJSON() {
        try {
            console.log('📁 Loading stories from JSON...');
            
            const paths = [
                './assets/trending-stories.json',
                '../assets/trending-stories.json',
                'assets/trending-stories.json',
                '/assets/trending-stories.json'
            ];
            
            let response;
            let successfulPath = '';
            
            for (const path of paths) {
                try {
                    console.log(`🔍 Trying JSON path: ${path}`);
                    response = await fetch(path);
                    if (response.ok) {
                        successfulPath = path;
                        console.log(`✅ JSON found at: ${path}`);
                        break;
                    }
                } catch (e) {
                    console.log(`❌ Path failed: ${path}`, e.message);
                    continue;
                }
            }
            
            if (!response || !response.ok) {
                throw new Error('All JSON paths failed');
            }
            
            const data = await response.json();
            this.allStories = data.stories;
            console.log(`✅ Stories loaded from JSON: ${this.allStories.length} stories`);
            
        } catch (error) {
            console.error('❌ Error loading JSON:', error);
            console.log('🔄 Using fallback stories data');
            this.loadFallbackStories();
        }
    }

    loadFallbackStories() {
        console.log('📝 Loading fallback stories...');
        this.allStories = [
            {
                id: 1,
                user: {
                    name: "Rahul Sharma",
                    avatar: "images/users/user1.jpg",
                    role: "Motivational Speaker"
                },
                content: {
                    en: "Started my journey with just ₹5000. Today I run a successful business with 50+ employees. Never give up on your dreams!",
                    hi: "मैंने अपनी यात्रा सिर्फ ₹5000 से शुरू की। आज मैं 50+ कर्मचारियों के साथ एक सफल व्यवसाय चलाता हूं। अपने सपनों को कभी मत छोड़ो!",
                    ur: "میں نے اپنا سفر صرف ₹5000 سے شروع کیا۔ آج میں 50+ ملازمین کے ساتھ ایک کامیاب کاروبار چلا رہا ہوں۔ اپنے خوابوں کو کبھی مت چھوڑیں!",
                    mr: "मी फक्त ₹5000 सह माझा प्रवास सुरू केला. आज मी 50+ कर्मचाऱ्यांसह एक यशस्वी व्यवसाय चालवतो. तुमचे स्वप्न कधीही सोडू नका!"
                },
                stats: {
                    views: 12500,
                    likes: 3420,
                    shares: 890,
                    timestamp: "2024-01-15"
                },
                tags: ["success", "business", "motivation"]
            },
            {
                id: 2,
                user: {
                    name: "Priya Patel",
                    avatar: "images/users/user2.jpg",
                    role: "Fitness Coach"
                },
                content: {
                    en: "Lost 25kg in 6 months through consistent effort and healthy lifestyle. Your body can achieve what your mind believes!",
                    hi: "6 महीनों में लगातार प्रयास और स्वस्थ जीवनशैली से 25kg वजन कम किया। आपका शरीर वह हासिल कर सकता है जो आपका मन मानता है!",
                    ur: "6 ماہ میں مسلسل محنت اور صحت مند طرز زندگی سے 25kg وزن کم کیا۔ آپ کا جسم وہ حاصل کر سکتا ہے جو آپ کا دماغ مانتا ہے!",
                    mr: "सातत्य प्रयत्न आणि निरोगी जीवनशैलीद्वारे 6 महिन्यात 25kg वजन कम केले. तुमचे शरीर ते साध्य करू शकते जे तुमचे मन मानते!"
                },
                stats: {
                    views: 18900,
                    likes: 5120,
                    shares: 1200,
                    timestamp: "2024-01-12"
                },
                tags: ["fitness", "health", "transformation"]
            },
            {
                id: 3,
                user: {
                    name: "Amit Kumar",
                    avatar: "images/users/user3.jpg",
                    role: "Software Engineer"
                },
                content: {
                    en: "From failing in college to leading a team at Google. Failure is not the opposite of success, it's part of success!",
                    hi: "कॉलेज में फेल होने से लेकर Google में टीम लीडर बनने तक। असफलता सफलता का विपरीत नहीं है, यह सफलता का हिस्सा है!",
                    ur: "کالج میں ناکامی سے لے کر گوگل میں ٹیم لیڈر بننے تک۔ ناکامی کامیابی کے برعکس نہیں ہے، یہ کامیابی کا حصہ ہے!",
                    mr: "कॉलेजमध्ये नापास होण्यापासून ते Google वर टीम लीडर होण्यापर्यंत. अयशस्वी होणे हे यशाच्या विरुद्ध नाही, ते यशाचा एक भाग आहे!"
                },
                stats: {
                    views: 21500,
                    likes: 6780,
                    shares: 1560,
                    timestamp: "2024-01-10"
                },
                tags: ["career", "technology", "inspiration"]
            },
            {
                id: 4,
                user: {
                    name: "Neha Singh",
                    avatar: "images/users/user4.jpg",
                    role: "Artist & Entrepreneur"
                },
                content: {
                    en: "Sold my first painting for ₹500, now my artworks sell for ₹50,000+. Passion combined with persistence creates magic!",
                    hi: "मैंने अपनी पहली पेंटिंग ₹500 में बेची, अब मेरी कलाकृतियाँ ₹50,000+ में बिकती हैं। जुनून के साथ दृढ़ता जादू बनाती है!",
                    ur: "میں نے اپنی پہلی پینٹنگ ₹500 میں بیچی، اب میری آرٹ ورکس ₹50,000+ میں فروخت ہوتی ہیں۔ جذبہ کے ساتھ استقامت جادو پیدا کرتی ہے!",
                    mr: "मी माझी पहिली चित्रकला ₹500 ला विकली, आता माझी कला कृती ₹50,000+ ला विकली जातात. आवड आणि चिकाटी एकत्रितपणे जादू निर्माण करतात!"
                },
                stats: {
                    views: 16700,
                    likes: 4230,
                    shares: 980,
                    timestamp: "2024-01-08"
                },
                tags: ["art", "entrepreneurship", "success"]
            },
            {
                id: 5,
                user: {
                    name: "Deepak Chauhan",
                    avatar: "images/AI-bhai.png",
                    role: "Community Leader"
                },
                content: {
                    en: "Built this community from 0 to 10,000+ members in 1 year. When we lift others, we rise together!",
                    hi: "1 साल में इस कम्युनिटी को 0 से 10,000+ मेंबर तक बनाया। जब हम दूसरों को उठाते हैं, तो हम साथ में बढ़ते हैं!",
                    ur: "1 سال میں اس کمیونٹی کو 0 سے 10,000+ ممبران تک بنایا۔ جب ہم دوسروں کو اٹھاتے ہیں، تو ہم ایک ساتھ بڑھتے ہیں!",
                    mr: "1 वर्षात या समुदायाला 0 वरून 10,000+ सदस्यांपर्यंत बांधले. जेव्हा आपण इतरांना उचलतो, तेव्हा आपण एकत्र वाढतो!"
                },
                stats: {
                    views: 28900,
                    likes: 8920,
                    shares: 2340,
                    timestamp: "2024-01-05"
                },
                tags: ["community", "growth", "leadership"]
            },
            {
                id: 6,
                user: {
                    name: "Sneha Verma",
                    avatar: "images/users/user5.jpg",
                    role: "Yoga Instructor"
                },
                content: {
                    en: "Healed my chronic back pain through yoga and meditation. Your mind and body have incredible healing power!",
                    hi: "योग और ध्यान के माध्यम से अपने पुराने पीठ दर्द को ठीक किया। आपके मन और शरीर में अविश्वसनीय उपचार शक्ति है!",
                    ur: "یوگا اور مراقبہ کے ذریعے اپنے دائمی کمر کے درد کو ٹھیک کیا۔ آپ کے دماغ اور جسم میں ناقابل یقین شفا یابی کی طاقت ہے!",
                    mr: "योग आणि ध्यानाद्वारे माझे क्रॉनिक पाठदुखी बरे केले. तुमच्या मनाला आणि शरीराला अविश्वसनीय बरे करण्याची शक्ती आहे!"
                },
                stats: {
                    views: 14300,
                    likes: 3870,
                    shares: 760,
                    timestamp: "2024-01-03"
                },
                tags: ["yoga", "health", "meditation"]
            },
            {
                id: 7,
                user: {
                    name: "Vikram Joshi",
                    avatar: "images/users/user6.jpg", 
                    role: "Digital Marketer"
                },
                content: {
                    en: "Grew my online business from ₹10,000 to ₹10 lakh/month. Digital marketing changed my life completely!",
                    hi: "अपने ऑनलाइन व्यवसाय को ₹10,000 से ₹10 लाख/महीने तक बढ़ाया। डिजिटल मार्केटिंग ने मेरी जिंदगी पूरी तरह बदल दी!",
                    ur: "اپنے آن لائن کاروبار کو ₹10,000 سے ₹10 لاکھ/ماہ تک بڑھایا۔ ڈیجیٹل مارکیٹنگ نے میری زندگی مکمل طور پر بدل دی!",
                    mr: "माझा ऑनलाइन व्यवसाय ₹10,000 वरून ₹10 लाख/महिन्यापर्यंत वाढवला. डिजिटल मार्केटिंगने माझे आयुष्य पूर्णपणे बदलले!"
                },
                stats: {
                    views: 19800,
                    likes: 5670,
                    shares: 1340,
                    timestamp: "2024-01-01"
                },
                tags: ["marketing", "business", "digital"]
            },
            {
                id: 8,
                user: {
                    name: "Anjali Mehta",
                    avatar: "images/users/user7.jpg",
                    role: "Home Chef"
                },
                content: {
                    en: "Started home kitchen with 5 dishes, now I have 500+ customers weekly. Follow your passion fearlessly!",
                    hi: "5 व्यंजनों के साथ होम किचन शुरू किया, अब मेरे 500+ साप्ताहिक ग्राहक हैं। निडर होकर अपने जुनून का पालन करो!",
                    ur: "5 پکوانوں کے ساتھ ہوم کچن شروع کیا، اب میرے 500+ ہفتہ وار گاہک ہیں۔ بے خوف اپنے جذبے کی پیروی کریں!",
                    mr: "5 पदार्थांसह घरगुती स्वयंपाकघर सुरू केले, आता माझे 500+ साप्ताहिक ग्राहक आहेत. निःशंकपणे तुमच्या आवडीचा अवलंब करा!"
                },
                stats: {
                    views: 17600,
                    likes: 4980,
                    shares: 1120,
                    timestamp: "2023-12-28"
                },
                tags: ["food", "business", "passion"]
            }
        ];
        console.log('✅ Fallback stories loaded:', this.allStories.length);
    }

    // Naya method: Random stories select karo
    getRandomStories(count) {
        // Available stories (jo abhi tak show nahi hui)
        const availableStories = this.allStories.filter(story => 
            !this.displayedStoryIds.has(story.id)
        );

        // Agar available stories kam hai, to reset karo
        if (availableStories.length < count) {
            console.log('🔄 Resetting displayed stories');
            this.displayedStoryIds.clear();
            return this.allStories.slice(0, count);
        }

        // Random stories select karo
        const shuffled = [...availableStories].sort(() => 0.5 - Math.random());
        const selectedStories = shuffled.slice(0, count);

        // Selected stories ko track karo
        selectedStories.forEach(story => {
            this.displayedStoryIds.add(story.id);
        });

        return selectedStories;
    }

    setupEventListeners() {
        console.log('🔗 Setting up event listeners...');
        
        // Open popup
        if (this.openBtn) {
            this.openBtn.addEventListener('click', () => {
                console.log('🔥 Open button clicked');
                this.openPopup();
            });
        }
        
        // Close popup
        if (this.closeBtn) {
            this.closeBtn.addEventListener('click', () => {
                console.log('❌ Close button clicked');
                this.closePopup();
            });
        }
        
        // Load more stories
        if (this.loadMoreBtn) {
            this.loadMoreBtn.addEventListener('click', () => {
                console.log('🔄 Load more clicked');
                this.loadMoreStories();
            });
        }
        
        // Close on overlay click
        if (this.popup) {
            this.popup.addEventListener('click', (e) => {
                if (e.target === this.popup) {
                    console.log('🎯 Overlay clicked');
                    this.closePopup();
                }
            });
        }
        
        // Close on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.popup.classList.contains('active')) {
                console.log('⌨️ Escape key pressed');
                this.closePopup();
            }
        });
        
        console.log('✅ All event listeners setup');
    }

    openPopup() {
        console.log('🎯 Opening popup...');
        
        // Current language update karo
        this.currentLanguage = this.getCurrentLanguage();
        console.log('🌐 Current language:', this.currentLanguage);
        
        // 3 random stories select karo
        this.stories = this.getRandomStories(this.storiesPerPage);
        console.log('🎲 Selected random stories:', this.stories.map(s => s.id));
        
        this.popup.classList.add('active');
        document.body.style.overflow = 'hidden';
        this.renderStories();
        console.log('✅ Popup opened successfully');
    }

    closePopup() {
        console.log('🎯 Closing popup...');
        this.popup.classList.remove('active');
        document.body.style.overflow = '';
        console.log('✅ Popup closed successfully');
    }

    renderStories() {
        if (!this.storiesGrid) {
            console.error('❌ Stories grid not found');
            return;
        }

        console.log('🎨 Rendering stories in language:', this.currentLanguage);
        this.storiesGrid.innerHTML = '';

        this.stories.forEach((story, index) => {
            // Current language me content show karo, agar nahi hai to English
            const content = story.content[this.currentLanguage] || story.content.en;
            
            const storyHTML = `
                <div class="story-card">
                    <div class="story-header">
                        <div class="story-avatar">
                            <img src="${story.user.avatar}" alt="${story.user.name}" 
                                 onerror="this.src='images/AI-bhai.png'">
                        </div>
                        <div class="story-user-info">
                            <h4>${story.user.name}</h4>
                            <p>${story.user.role}</p>
                        </div>
                    </div>
                    
                    <div class="story-content">
                        ${content}
                    </div>
                    
                    <div class="story-tags">
                        ${story.tags.map(tag => `<span class="story-tag">#${tag}</span>`).join('')}
                    </div>
                    
                    <div class="story-stats">
                        <div class="story-stat">
                            <span>👁️</span>
                            <span>${this.formatNumber(story.stats.views)}</span>
                        </div>
                        <div class="story-stat">
                            <span>❤️</span>
                            <span>${this.formatNumber(story.stats.likes)}</span>
                        </div>
                        <div class="story-stat">
                            <span>📤</span>
                            <span>${this.formatNumber(story.stats.shares)}</span>
                        </div>
                        <div class="story-stat">
                            <span>📅</span>
                            <span>${this.formatDate(story.stats.timestamp)}</span>
                        </div>
                    </div>
                </div>
            `;
            
            this.storiesGrid.innerHTML += storyHTML;
        });

        this.updateStats();
        this.updateLoadMoreButton();
        console.log('✅ Stories rendered successfully');
    }

    loadMoreStories() {
        console.log('🔄 Loading more stories...');
        
        // 3 aur random stories add karo
        const moreStories = this.getRandomStories(this.storiesPerPage);
        this.stories = [...this.stories, ...moreStories];
        
        this.renderStories();
        this.showNotification('More stories loaded! ✨');
    }

    updateStats() {
        const totalStories = this.allStories.length;
        const totalViews = this.allStories.reduce((sum, story) => sum + story.stats.views, 0);
        const totalLikes = this.allStories.reduce((sum, story) => sum + story.stats.likes, 0);

        if (this.storiesCount) this.storiesCount.textContent = totalStories;
        if (this.viewsCount) this.viewsCount.textContent = this.formatNumber(totalViews);
        if (this.likesCount) this.likesCount.textContent = this.formatNumber(totalLikes);
    }

    updateLoadMoreButton() {
        // Agar saari stories show ho chuki hai to button hide karo
        if (this.displayedStoryIds.size >= this.allStories.length) {
            this.loadMoreBtn.style.display = 'none';
            this.showNotification('All stories loaded! 🎉');
        } else {
            this.loadMoreBtn.style.display = 'flex';
        }
    }

    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now - date);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) return 'Yesterday';
        if (diffDays < 7) return `${diffDays}d ago`;
        if (diffDays < 30) return `${Math.floor(diffDays / 7)}w ago`;
        return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    }

    showNotification(message) {
        const existingNotification = document.querySelector('.notification');
        if (existingNotification) {
            existingNotification.remove();
        }

        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 2000);
    }
}

// Global function for onclick
function openTrendingStories() {
    console.log('🌍 Global function openTrendingStories called');
    
    if (window.trendingPopup) {
        window.trendingPopup.openPopup();
    } else {
        console.log('🔄 Creating new instance');
        window.trendingPopup = new TrendingStoriesPopup();
        setTimeout(() => {
            if (window.trendingPopup) {
                window.trendingPopup.openPopup();
            }
        }, 100);
    }
}

// Language change trigger function (website ke language changer se call karo)
function triggerLanguageChange() {
    console.log('🔄 Triggering language change in stories');
    if (window.trendingPopup) {
        window.trendingPopup.handleLanguageChange();
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 DOM Content Loaded - Initializing Trending Stories');
    window.trendingPopup = new TrendingStoriesPopup();
});

// Fallback initialization
setTimeout(() => {
    if (!window.trendingPopup) {
        console.log('🔄 Fallback initialization');
        window.trendingPopup = new TrendingStoriesPopup();
    }
}, 1000);

console.log('✅ trending-stories.js execution complete');