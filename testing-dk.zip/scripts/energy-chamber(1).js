// Energy Chamber JavaScript
console.log('🔥 scripts/energy-chamber.js loaded');

class EnergyChamber {
    constructor() {
        this.init();
    }

    init() {
        console.log('🎯 Initializing Energy Chamber...');
        this.setupEventListeners();
        this.setupLanguageSupport();
        console.log('✅ Energy Chamber Ready!');
    }

    setupEventListeners() {
        // Fire buttons already have onclick handlers
        console.log('🔗 Energy Chamber event listeners setup');
    }

    setupLanguageSupport() {
        // Listen for language changes
        document.addEventListener('languageChanged', (e) => {
            this.updateContent(e.detail.translations);
        });
    }

    updateContent(translations) {
        const elements = document.querySelectorAll('[data-translate]');
        
        elements.forEach(element => {
            const key = element.getAttribute('data-translate');
            if (translations[key]) {
                if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                    element.placeholder = translations[key];
                } else {
                    element.innerHTML = translations[key];
                }
            }
        });
        
        console.log('🌐 Energy Chamber language updated');
    }
}

// Global function for fire dialogues
function openFireDialogues(part) {
    console.log(`🔥 Opening Fire Dialogues - ${part}`);
    
    // Get current page name for the button
    const pageName = window.location.pathname.split('/').pop() || 'index.html';
    
    // Show notification
    showEnergyNotification(`Opening Fire Dialogues ${part.toUpperCase()} from ${pageName}`);
    
    // Here you can add logic to open specific dialogues
    // For now, just show a notification
    setTimeout(() => {
        if (part === 'part1') {
            // Redirect or open Part 1 content
            window.open(`fire-dialogues-part1.html?from=${encodeURIComponent(pageName)}`, '_blank');
        } else if (part === 'part2') {
            // Redirect or open Part 2 content  
            window.open(`fire-dialogues-part2.html?from=${encodeURIComponent(pageName)}`, '_blank');
        }
    }, 1000);
}

// Notification function
function showEnergyNotification(message) {
    // Remove existing notification
    const existingNotification = document.querySelector('.energy-notification');
    if (existingNotification) {
        existingNotification.remove();
    }

    // Create new notification
    const notification = document.createElement('div');
    notification.className = 'energy-notification';
    notification.innerHTML = `
        <div class="notification-content">
            <span class="fire-icon">🔥</span>
            <span>${message}</span>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(45deg, #ff6b35, #ff4444);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(255, 107, 53, 0.4);
        z-index: 10000;
        animation: slideInRight 0.3s ease;
        font-weight: 600;
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Add notification styles to head
const notificationStyles = `
@keyframes slideInRight {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}

@keyframes slideOutRight {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
}

.notification-content {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.fire-icon {
    font-size: 1.2rem;
}
`;

// Inject styles
const styleSheet = document.createElement('style');
styleSheet.textContent = notificationStyles;
document.head.appendChild(styleSheet);

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.energyChamber = new EnergyChamber();
});

console.log('✅ energy-chamber.js loaded successfully');