/**
 * Community Wall Box Functionality with Language Support
 * For main website - Shows latest posts and stats
 */

class CommunityWallBox {
    constructor() {
        this.posts = [];
        this.isLoading = false;
        this.currentLanguage = 'en';
        this.translations = {};
        this.init();
    }

    async init() {
        console.log('🚀 Community Wall Box Initializing...');
        
        // Load language first
        await this.loadLanguage();
        
        // Then load posts
        this.loadPosts();
        
        // Auto refresh every 30 seconds
        setInterval(() => {
            this.loadPosts();
        }, 30000);
        
        // Listen for language changes
        this.setupLanguageListener();
        
        console.log('✅ Community Wall Box Ready!');
    }

    async loadLanguage() {
        // Get current language
        this.currentLanguage = localStorage.getItem('preferredLanguage') || 'en';
        
        // Load translations
        await this.loadTranslations();
        
        // Update box content
        this.updateBoxContent();
    }

    async loadTranslations() {
        try {
            const response = await fetch(`/languages/${this.currentLanguage}.json`);
            if (response.ok) {
                this.translations = await response.json();
            } else {
                throw new Error('Translation file not found');
            }
        } catch (error) {
            console.warn('Using fallback translations');
            this.translations = this.getFallbackTranslations();
        }
    }

    getFallbackTranslations() {
        const fallback = {
            'en': {
                'community_wall': 'DK Community Wall',
                'loading_posts': 'Loading community posts...',
                'online': 'Online',
                'new_posts': 'New Posts',
                'open_community_wall': 'Open Community Wall',
                'no_posts': 'No posts yet. Be the first to share!',
                'network_error': 'Network error'
            },
            'hi': {
                'community_wall': 'डीके कम्युनिटी वॉल',
                'loading_posts': 'कम्युनिटी पोस्ट लोड हो रही हैं...',
                'online': 'ऑनलाइन',
                'new_posts': 'नई पोस्ट',
                'open_community_wall': 'कम्युनिटी वॉल खोलें',
                'no_posts': 'अभी तक कोई पोस्ट नहीं। पहली पोस्ट शेयर करें!',
                'network_error': 'नेटवर्क एरर'
            },
            'ur': {
                'community_wall': 'ڈی کے کمیونٹی وال',
                'loading_posts': 'کمیونٹی پوسٹس لوڈ ہو رہی ہیں...',
                'online': 'آن لائن',
                'new_posts': 'نئی پوسٹس',
                'open_community_wall': 'کمیونٹی وال کھولیں',
                'no_posts': 'ابھی تک کوئی پوسٹ نہیں۔ پہلی پوسٹ شیئر کریں!',
                'network_error': 'نیٹ ورک ایرر'
            },
            'mr': {
                'community_wall': 'डीके कम्युनिटी वॉल',
                'loading_posts': 'कम्युनिटी पोस्ट लोड होत आहेत...',
                'online': 'ऑनलाइन',
                'new_posts': 'नवीन पोस्ट',
                'open_community_wall': 'कम्युनिटी वॉल उघडा',
                'no_posts': 'अद्याप कोणतेही पोस्ट नाहीत. पहिले पोस्ट शेअर करा!',
                'network_error': 'नेटवर्क त्रुटी'
            }
        };
        
        return fallback[this.currentLanguage] || fallback['en'];
    }

    updateBoxContent() {
        // Update title
        const titleElement = document.querySelector('.community-wall-box h3');
        if (titleElement && this.translations.community_wall) {
            titleElement.textContent = this.translations.community_wall;
        }

        // Update button text
        const buttonElement = document.querySelector('.open-wall-btn');
        if (buttonElement && this.translations.open_community_wall) {
            const btnIcon = buttonElement.querySelector('.btn-icon');
            buttonElement.innerHTML = `${btnIcon.outerHTML} ${this.translations.open_community_wall}`;
        }

        // Update stat labels
        this.updateStatLabels();
    }

    updateStatLabels() {
        const statItems = document.querySelectorAll('.stat-text');
        statItems.forEach((item, index) => {
            if (index === 0 && this.translations.online) {
                // Online stat
                const number = item.querySelector('.stat-number');
                if (number) {
                    item.innerHTML = `${number.outerHTML} ${this.translations.online}`;
                }
            } else if (index === 1 && this.translations.new_posts) {
                // New posts stat
                const number = item.querySelector('.stat-number');
                if (number) {
                    item.innerHTML = `${number.outerHTML} ${this.translations.new_posts}`;
                }
            }
        });
    }

    setupLanguageListener() {
        // Listen for language changes from shared manager
        document.addEventListener('dkLanguageChanged', (event) => {
            this.currentLanguage = event.detail.language;
            this.translations = event.detail.translations || {};
            this.updateBoxContent();
            console.log('🌐 Community box language updated:', this.currentLanguage);
        });

        // Also check localStorage periodically
        setInterval(() => {
            const savedLang = localStorage.getItem('preferredLanguage');
            if (savedLang && savedLang !== this.currentLanguage) {
                this.currentLanguage = savedLang;
                this.loadTranslations().then(() => {
                    this.updateBoxContent();
                });
            }
        }, 2000);
    }

    async loadPosts() {
        if (this.isLoading) return;
        
        this.isLoading = true;
        this.showLoading();
        
        try {
            const result = await this.fetchLatestPosts();
            
            if (result.success) {
                this.posts = result.posts.slice(0, 3); // Show only top 3
                this.displayPosts();
                this.updateStats(result.posts);
            } else {
                this.showError('Failed to load posts');
            }
        } catch (error) {
            console.error('Load posts error:', error);
            this.showError(this.translations.network_error || 'Network error');
        } finally {
            this.isLoading = false;
        }
    }

    async fetchLatestPosts() {
        const response = await fetch('https://deepakchauhanxai.xyz/dk-api/community-get-posts.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'get_posts',
                limit: 5, // Get 5, show 3
                offset: 0
            })
        });
        
        return await response.json();
    }

    displayPosts() {
        const postsFeed = document.getElementById('communityPostsFeed');
        if (!postsFeed) return;
        
        if (this.posts.length === 0) {
            postsFeed.innerHTML = `
                <div class="no-posts">
                    <div class="no-posts-icon">💬</div>
                    <p>${this.translations.no_posts || 'No posts yet. Be the first to share!'}</p>
                </div>
            `;
            return;
        }
        
        let postsHTML = '';
        this.posts.forEach(post => {
            postsHTML += this.createPostHTML(post);
        });
        
        postsFeed.innerHTML = postsHTML;
    }

    createPostHTML(post) {
        const isAI = post.username === 'AI Bhai' || post.is_ai_post;
        const avatarClass = isAI ? 'ai' : 'user';
        const avatarIcon = isAI ? '🤖' : '👤';
        
        // Shorten long posts
        const shortText = post.post_text.length > 80 
            ? post.post_text.substring(0, 80) + '...' 
            : post.post_text;
        
        return `
            <div class="post-item">
                <div class="post-avatar ${avatarClass}">${avatarIcon}</div>
                <div class="post-content">
                    <div class="post-author">${this.escapeHtml(post.username)}</div>
                    <div class="post-text">${this.escapeHtml(shortText)}</div>
                    <div class="post-time">${post.time_ago}</div>
                </div>
            </div>
        `;
    }

    updateStats(posts) {
        // Update online count (simulated)
        const onlineCount = Math.floor(Math.random() * 50) + 50; // 50-100 random
        const postsCount = posts.length;
        
        const onlineElement = document.getElementById('onlineCount');
        const postsElement = document.getElementById('postsCount');
        
        if (onlineElement) onlineElement.textContent = onlineCount;
        if (postsElement) postsElement.textContent = postsCount;
    }

    showLoading() {
        const postsFeed = document.getElementById('communityPostsFeed');
        if (postsFeed) {
            const loadingText = this.translations.loading_posts || 'Loading community posts...';
            postsFeed.innerHTML = `
                <div class="loading-posts">
                    <div class="loading-spinner"></div>
                    <p>${loadingText}</p>
                </div>
            `;
        }
    }

    showError(message) {
        const postsFeed = document.getElementById('communityPostsFeed');
        if (postsFeed) {
            postsFeed.innerHTML = `
                <div class="no-posts">
                    <div class="no-posts-icon">⚠️</div>
                    <p>${message}</p>
                </div>
            `;
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Open Community Wall function with language support
function openCommunityWall() {
    const currentLang = localStorage.getItem('preferredLanguage') || 'en';
    const communityWallUrl = `/testing-dk/dk-community-wall.html?lang=${currentLang}`;
    
    console.log('🚀 Opening community wall:', communityWallUrl);
    window.open(communityWallUrl, '_self');
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Wait a bit for language manager to initialize
    setTimeout(() => {
        window.communityWallBox = new CommunityWallBox();
    }, 1000);
});

// Make it globally available
window.CommunityWallBox = CommunityWallBox;