/**
 * DK Community Wall - Basic JavaScript
 * Simple functionality that definitely works
 * @author Deepak Chauhan × AI Bhai
 */

// Wait for page to load completely
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 DK Community Wall Initializing...');
    
    // Initialize all functionality
    initializeCommunityWall();
    
    console.log('✅ DK Community Wall Ready!');
});

function initializeCommunityWall() {
    // Hide loading screen after 2 seconds
    setTimeout(() => {
        const loadingScreen = document.getElementById('loadingScreen');
        const mainLayout = document.querySelector('.main-layout');
        
        if (loadingScreen) {
            loadingScreen.style.display = 'none';
        }
        if (mainLayout) {
            mainLayout.classList.remove('hidden');
        }
        
        console.log('📱 Loading screen hidden');
    }, 2000);

    // Initialize language switcher
    initializeLanguageSwitcher();
    
    // Initialize post functionality
    initializePostSystem();
    
    // Initialize like buttons
    initializeLikeSystem();
    
    // Initialize navigation
    initializeNavigation();
}

// Language Switcher Functionality
function initializeLanguageSwitcher() {
    const languageTrigger = document.getElementById('languageTrigger');
    const languageDropdown = document.getElementById('languageDropdown');
    const currentLanguage = document.getElementById('currentLanguage');
    
    if (!languageTrigger || !languageDropdown) {
        console.log('🌐 Language switcher elements not found');
        return;
    }
    
    console.log('🌐 Initializing language switcher...');
    
    // Toggle dropdown on click
    languageTrigger.addEventListener('click', function(e) {
        e.stopPropagation();
        languageDropdown.classList.toggle('show');
        console.log('🎯 Language dropdown toggled');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function() {
        languageDropdown.classList.remove('show');
    });
    
    // Handle language selection
    const languageOptions = languageDropdown.querySelectorAll('.language-option');
    languageOptions.forEach(option => {
        option.addEventListener('click', function(e) {
            e.stopPropagation();
            const lang = this.getAttribute('data-lang');
            const flag = this.querySelector('.flag').textContent;
            
            // Update current language display
            currentLanguage.textContent = flag;
            
            // Close dropdown
            languageDropdown.classList.remove('show');
            
            // Show success message
            showToast(`Language changed to ${getLanguageName(lang)}!`);
            
            console.log(`🌐 Language changed to: ${lang}`);
            
            // Store language preference
            localStorage.setItem('dk_preferred_language', lang);
        });
    });
    
    console.log('✅ Language switcher initialized');
}

function getLanguageName(lang) {
    const languages = {
        'en': 'English',
        'hi': 'Hindi', 
        'ur': 'Urdu',
        'mr': 'Marathi'
    };
    return languages[lang] || 'English';
}

// Post System Functionality
function initializePostSystem() {
    const submitPostBtn = document.getElementById('submitPost');
    const postContent = document.getElementById('postContent');
    
    if (!submitPostBtn || !postContent) {
        console.log('📝 Post system elements not found');
        return;
    }
    
    console.log('📝 Initializing post system...');
    
    submitPostBtn.addEventListener('click', function() {
        const content = postContent.value.trim();
        
        if (content.length === 0) {
            showToast('Please write something to post!', 'warning');
            return;
        }
        
        if (content.length > 500) {
            showToast('Post is too long! Maximum 500 characters.', 'warning');
            return;
        }
        
        // Create new post
        createNewPost(content);
        
        // Clear textarea
        postContent.value = '';
        
        // Show success message
        showToast('Post published successfully! 🚀', 'success');
        
        console.log('📢 New post created:', content.substring(0, 50) + '...');
    });
    
    // Allow Enter key to submit (with Shift+Enter for new line)
    postContent.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            submitPostBtn.click();
        }
    });
    
    console.log('✅ Post system initialized');
}

function createNewPost(content) {
    const postsFeed = document.getElementById('postsFeed');
    if (!postsFeed) return;
    
    // Create post element
    const postElement = document.createElement('div');
    postElement.className = 'post-card user-post';
    postElement.innerHTML = `
        <div class="post-header">
            <div class="post-author">
                <div class="author-avatar user-avatar">👤</div>
                <div class="author-details">
                    <span class="author-name">You</span>
                    <span class="post-time">Just now</span>
                </div>
            </div>
        </div>
        <div class="post-content">
            <p>${escapeHtml(content)}</p>
        </div>
        <div class="post-actions">
            <button class="post-action like-btn">
                <span class="action-icon">❤️</span>
                <span class="action-count">0</span>
            </button>
            <button class="post-action comment-btn">
                <span class="action-icon">💬</span>
                <span class="action-count">0</span>
            </button>
            <button class="post-action share-btn">
                <span class="action-icon">🔗</span>
                <span class="action-text">Share</span>
            </button>
        </div>
    `;
    
    // Add to top of feed
    postsFeed.insertBefore(postElement, postsFeed.firstChild);
    
    // Initialize like functionality for new post
    initializePostInteractions(postElement);
}

// Like System Functionality
function initializeLikeSystem() {
    console.log('❤️ Initializing like system...');
    
    const likeButtons = document.querySelectorAll('.like-btn');
    likeButtons.forEach(button => {
        initializeLikeButton(button);
    });
    
    console.log('✅ Like system initialized');
}

function initializePostInteractions(postElement) {
    const likeBtn = postElement.querySelector('.like-btn');
    if (likeBtn) {
        initializeLikeButton(likeBtn);
    }
}

function initializeLikeButton(likeButton) {
    likeButton.addEventListener('click', function() {
        const countElement = this.querySelector('.action-count');
        let count = parseInt(countElement.textContent) || 0;
        
        if (this.classList.contains('liked')) {
            // Unlike
            count--;
            this.classList.remove('liked');
            this.querySelector('.action-icon').textContent = '❤️';
        } else {
            // Like
            count++;
            this.classList.add('liked');
            this.querySelector('.action-icon').textContent = '💖';
        }
        
        countElement.textContent = count;
        
        console.log('❤️ Like count updated:', count);
    });
}

// Navigation Functionality
function initializeNavigation() {
    console.log('🧭 Initializing navigation...');
    
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            if (this.classList.contains('nav-active')) {
                e.preventDefault();
                console.log('📍 Already on this page');
                return;
            }
            
            const page = this.getAttribute('data-page');
            console.log('🧭 Navigating to:', page);
            
            // Remove active class from all items
            navItems.forEach(nav => nav.classList.remove('nav-active'));
            
            // Add active class to clicked item
            this.classList.add('nav-active');
        });
    });
    
    console.log('✅ Navigation initialized');
}

// Toast Notification System
function showToast(message, type = 'info') {
    // Remove existing toast
    const existingToast = document.querySelector('.dk-toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `dk-toast dk-toast-${type}`;
    
    // Set styles
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${getToastColor(type)};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 10000;
        animation: toastSlideIn 0.3s ease;
        font-family: inherit;
        font-size: 14px;
        font-weight: 500;
        max-width: 300px;
        word-wrap: break-word;
    `;
    
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // Add CSS animation if not exists
    if (!document.querySelector('#toast-animations')) {
        const style = document.createElement('style');
        style.id = 'toast-animations';
        style.textContent = `
            @keyframes toastSlideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes toastSlideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
            .language-dropdown.show {
                opacity: 1 !important;
                visibility: visible !important;
                transform: translateY(0) !important;
            }
        `;
        document.head.appendChild(style);
    }
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            toast.style.animation = 'toastSlideOut 0.3s ease';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }
    }, 3000);
    
    console.log('📢 Toast shown:', message);
}

function getToastColor(type) {
    const colors = {
        'success': 'linear-gradient(135deg, #10b981, #34d399)',
        'error': 'linear-gradient(135deg, #ef4444, #f87171)',
        'warning': 'linear-gradient(135deg, #f59e0b, #fbbf24)',
        'info': 'linear-gradient(135deg, #3b82f6, #60a5fa)'
    };
    return colors[type] || colors.info;
}

// Utility function to escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Load saved language preference
function loadSavedLanguage() {
    const savedLang = localStorage.getItem('dk_preferred_language');
    if (savedLang) {
        const currentLanguage = document.getElementById('currentLanguage');
        const flagMap = {
            'en': '🇺🇸',
            'hi': '🇮🇳',
            'ur': '🇵🇰',
            'mr': '🇮🇳'
        };
        
        if (currentLanguage && flagMap[savedLang]) {
            currentLanguage.textContent = flagMap[savedLang];
        }
    }
}

// Initialize when page loads
window.addEventListener('load', function() {
    loadSavedLanguage();
    console.log('💾 Saved language preference loaded');
});

// Make functions available globally
window.dkCommunity = {
    initializeCommunityWall,
    showToast,
    createNewPost
};