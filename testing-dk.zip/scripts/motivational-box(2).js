// Motivational Box Functionality for Home Page
class HomeMotivationalBox {
    constructor() {
        this.currentQuoteIndex = 0;
        this.likeCount = 0;
        this.quotesData = [
            {
                id: 1,
                image: "images/motivational/quote1.jpg",
                en: {
                    title: "Secret of Success",
                    shayari: "If your courage is high, you will find your destination, those who try never lose."
                },
                hi: {
                    title: "सफलता का रहस्य",
                    shayari: "हौसले बुलंद हो तो मंजिलें भी मिल जाती हैं, कोशिश करने वालों की कभी हार नहीं होती।"
                },
                ur: {
                    title: "کامیابی کا راز",
                    shayari: "ہمت بلند ہو تو منزلیں بھی مل جاتی ہیں، کوشش کرنے والوں کی کبھی ہار نہیں ہوتی۔"
                },
                mr: {
                    title: "यशाचे रहस्य",
                    shayari: "हौसले उंच असले तर मंजिल मिळते, प्रयत्न करणाऱ्यांचे कधीच पराभव होत नाहीत."
                }
            },
            {
                id: 2,
                image: "images/motivational/quote2.jpg",
                en: {
                    title: "Fruit of Hard Work",
                    shayari: "Work hard consistently, destiny will also change, the magic of waves will flow on the chest of the ocean."
                },
                hi: {
                    title: "मेहनत का फल",
                    shayari: "मेहनत करो सिलसिलेवार, किस्मत भी बदल जाएगी, समंदर के सीने पर लहरों का जादू चल जाएगा।"
                },
                ur: {
                    title: "محنت کا پھل",
                    shayari: "محنت کرو مسلسل، تقدیر بھی بدل جائے گی، سمندر کے سینے پر لہروں کا جادو چل جائے گا۔"
                },
                mr: {
                    title: "मेहनतीचे फळ",
                    shayari: "मेहनत करा सतत, दैवत देखील बदलेल, समुद्राच्या छातीवर लाटांचे जादू चालेल."
                }
            },
            {
                id: 3,
                image: "images/motivational/quote3.jpg",
                en: {
                    title: "Dreams and Reality",
                    shayari: "Dreams are not what you see while sleeping, dreams are what don't let you sleep."
                },
                hi: {
                    title: "सपने और हकीकत",
                    shayari: "सपने वो नहीं जो आप सोते वक्त देखते हैं, सपने वो हैं जो आपको सोने नहीं देते।"
                },
                ur: {
                    title: "خواب اور حقیقت",
                    shayari: "خواب وہ نہیں جو آپ سوتے وقت دیکھتے ہیں، خواب وہ ہیں جو آپ کو سونے نہیں دیتے۔"
                },
                mr: {
                    title: "स्वप्न आणि वास्तव",
                    shayari: "स्वप्ने ती नाहीत जी तुम्ही झोपताना पाहता, स्वप्ने ती आहेत जी तुम्हाला झोपू देत नाहीत."
                }
            }
        ];
        
        this.init();
    }

    init() {
        this.renderBox();
        this.setupLanguageListener();
        this.startAutoRotate();
        this.loadLikeCount();
    }

    renderBox() {
        // Box already exists in HTML, just update content
        this.updateContent();
    }

    setupLanguageListener() {
        // Listen for language changes from main language switcher
        document.addEventListener('languageChanged', (event) => {
            this.updateContent();
        });
        
        // Also update when page loads
        this.updateContent();
    }

    updateContent() {
        const currentLanguage = this.getCurrentLanguage();
        const currentQuote = this.quotesData[this.currentQuoteIndex];
        const content = currentQuote[currentLanguage] || currentQuote.en;

        // Update DOM elements
        const titleElement = document.getElementById('boxTitle');
        const shayariElement = document.getElementById('boxShayari');
        const imageElement = document.getElementById('boxImage');
        const likeCountElement = document.getElementById('likeCount');

        if (titleElement) titleElement.textContent = content.title;
        if (shayariElement) shayariElement.textContent = content.shayari;
        if (imageElement) imageElement.src = currentQuote.image;
        if (likeCountElement) likeCountElement.textContent = this.likeCount;
    }

    getCurrentLanguage() {
        // Get current language from main language switcher
        const currentLangBtn = document.querySelector('.lang-option.active');
        if (currentLangBtn) {
            return currentLangBtn.getAttribute('data-lang') || 'en';
        }
        
        // Fallback to checking URL or localStorage
        return localStorage.getItem('preferredLanguage') || 'en';
    }

    nextQuote() {
        this.currentQuoteIndex = (this.currentQuoteIndex + 1) % this.quotesData.length;
        this.updateContent();
    }

    startAutoRotate() {
        // Change quote every 10 seconds
        setInterval(() => {
            this.nextQuote();
        }, 10000);
    }

    like() {
        this.likeCount++;
        this.updateContent();
        this.saveLikeCount();
        
        // Add animation effect
        const likeBtn = document.querySelector('.like-btn');
        if (likeBtn) {
            likeBtn.classList.add('liked');
            setTimeout(() => {
                likeBtn.classList.remove('liked');
            }, 600);
        }
    }

    share() {
        const currentQuote = this.quotesData[this.currentQuoteIndex];
        const currentLanguage = this.getCurrentLanguage();
        const content = currentQuote[currentLanguage] || currentQuote.en;
        
        const shareText = `${content.title}\n\n"${content.shayari}"\n\n- Deepak Chauhan × AI Bhai ♥️\n\nShared via DK Community`;

        if (navigator.share) {
            navigator.share({
                title: content.title,
                text: shareText
            });
        } else {
            // Fallback: copy to clipboard
            navigator.clipboard.writeText(shareText).then(() => {
                this.showNotification('Quote copied to clipboard! 📋');
            });
        }
    }

    showNotification(message) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #ff0080, #7928ca);
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            z-index: 10000;
            animation: slideInRight 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            font-family: 'Poppins', sans-serif;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 2000);
    }

    loadLikeCount() {
        const savedLikes = localStorage.getItem('motivationalBoxLikes');
        if (savedLikes) {
            this.likeCount = parseInt(savedLikes);
        }
    }

    saveLikeCount() {
        localStorage.setItem('motivationalBoxLikes', this.likeCount.toString());
    }
}

// Instagram Trending Function
function openInstagramTrending() {
    // Show loading
    showLoadingScreen();
    
    setTimeout(() => {
        hideLoadingScreen();
        alert('📸 Instagram Trending Page\n\nBro, this feature is launching soon!\n\n✅ Latest Viral Content\n✅ Instagram Trends\n✅ Popular Reels\n\n📅 Coming Soon...');
    }, 1000);
}

// Global functions for action buttons
function likeMotivationalBox() {
    if (window.motivationalBoxInstance) {
        window.motivationalBoxInstance.like();
    }
}

function shareMotivationalBox() {
    if (window.motivationalBoxInstance) {
        window.motivationalBoxInstance.share();
    }
}

function nextMotivationalQuote() {
    if (window.motivationalBoxInstance) {
        window.motivationalBoxInstance.nextQuote();
    }
}

// Loading screen functions (reuse from main script)
function showLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.style.display = 'flex';
        loadingScreen.classList.remove('fade-out');
    }
}

function hideLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.classList.add('fade-out');
        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 500);
    }
}

// Add CSS for animations
const motivationalBoxStyles = document.createElement('style');
motivationalBoxStyles.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    .like-btn.liked {
        animation: heartBeat 0.6s ease;
    }
    @keyframes heartBeat {
        0%, 100% { transform: scale(1); }
        25% { transform: scale(1.1); }
        50% { transform: scale(0.9); }
        75% { transform: scale(1.1); }
    }
`;
document.head.appendChild(motivationalBoxStyles);

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.motivationalBoxInstance = new HomeMotivationalBox();
});