// Fixed Multi-Language AI Widget
(function() {
    console.log('🚀 Widget Script Loaded!');

    // Configuration
    const config = {
        defaultLanguage: 'en',
        scrollTrigger: 100,
        autoCloseTime: 90
    };

    // Global variables
    let userName = localStorage.getItem('aiWidgetUserName'); // Pehle se check karo
    let nameAsked = false;
    let widget = null;
    let currentLanguage = config.defaultLanguage;

    // Initialize
    initWidget();

    function initWidget() {
        console.log('🎯 Initializing Widget...');
        createWidget();
        setupScrollTrigger();
        
        // Agar pehle se name hai to directly show karo
        if (userName) {
            console.log('👤 Existing user:', userName);
            setTimeout(() => {
                showWidget();
            }, 2000);
        } else {
            console.log('🆕 New user - will ask name on scroll');
        }
    }

    function createWidget() {
        widget = document.createElement('div');
        widget.id = 'ultimateAiWidget';
        widget.style.display = 'none';
        
        widget.innerHTML = `
            <div style="position: fixed; bottom: 20px; right: 20px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; border-radius: 15px; width: 320px; z-index: 10000; box-shadow: 0 10px 30px rgba(0,0,0,0.3); font-family: Arial;">
                <div style="display: flex; align-items: center; margin-bottom: 15px;">
                    <img src="https://deepakchauhanxai.xyz/images/AI-bhai.png" alt="AI Bhai" style="width: 50px; height: 50px; border-radius: 50%; margin-right: 10px; border: 2px solid white;">
                    <div>
                        <div id="aiName" style="font-weight: bold; font-size: 18px;">AI Brother</div>
                        <div id="aiSubtitle" style="font-size: 12px; opacity: 0.8;">Talks from Heart ❤️</div>
                    </div>
                </div>
                <div id="ultimateMessages" style="height: 180px; overflow-y: auto; margin-bottom: 15px; background: rgba(255,255,255,0.1); padding: 10px; border-radius: 10px;"></div>
                <button id="ultimateCloseBtn" style="background: #ff0066; color: white; border: none; padding: 10px; border-radius: 8px; width: 100%; cursor: pointer; font-weight: bold;">Thanks (Close)</button>
            </div>
        `;
        
        document.body.appendChild(widget);

        // Close button
        document.getElementById('ultimateCloseBtn').addEventListener('click', function() {
            widget.remove();
        });
    }

    function setupScrollTrigger() {
        window.addEventListener('scroll', function() {
            if (window.scrollY > config.scrollTrigger && !nameAsked && !userName) {
                showNameInputModal();
                nameAsked = true;
            }
        });
    }

    function showNameInputModal() {
        if (userName) return; // Agar name already hai to modal mat dikhao
        
        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.5);
            z-index: 10001;
            text-align: center;
            color: white;
            font-family: Arial;
        `;
        
        modal.innerHTML = `
            <h3 style="color: #00ffcc; margin-bottom: 10px;">Welcome! 👋</h3>
            <p style="margin-bottom: 20px;">Please enter your name to continue:</p>
            <input type="text" id="nameInput" placeholder="Your beautiful name..." style="width: 100%; padding: 12px; margin: 15px 0; border: 2px solid #00ffcc; border-radius: 10px; background: rgba(255,255,255,0.1); color: white; font-size: 16px; text-align: center;">
            <button id="submitName" style="background: linear-gradient(135deg, #00ffcc, #0099ff); color: #1a1a2e; border: none; padding: 12px 25px; border-radius: 10px; cursor: pointer; font-weight: bold; font-size: 16px;">Let's Go! 🚀</button>
        `;
        
        document.body.appendChild(modal);

        // Focus on input
        setTimeout(() => {
            document.getElementById('nameInput').focus();
        }, 100);

        // Submit handler
        document.getElementById('submitName').addEventListener('click', function() {
            const input = document.getElementById('nameInput');
            if (input.value.trim()) {
                userName = input.value.trim();
                localStorage.setItem('aiWidgetUserName', userName);
                document.body.removeChild(modal);
                showWidget();
            } else {
                input.style.borderColor = '#ff0066';
            }
        });

        // Enter key support
        document.getElementById('nameInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                document.getElementById('submitName').click();
            }
        });
    }

    function showWidget() {
        console.log('🎪 Showing Widget for:', userName);
        widget.style.display = 'block';
        startConversation();
    }

    async function startConversation() {
        // Pehle language load karo
        await loadLanguageAndUpdate();
        
        // Auto close
        setTimeout(() => {
            if (widget && document.body.contains(widget)) {
                widget.remove();
            }
        }, config.autoCloseTime * 1000);
    }

    async function loadLanguageAndUpdate() {
        try {
            // Current language get karo (main site se ya default)
            const siteLang = localStorage.getItem('preferredLanguage') || config.defaultLanguage;
            currentLanguage = siteLang;
            
            console.log('🌐 Loading language:', currentLanguage);
            
            // Widget UI text update karo
            await updateWidgetText(currentLanguage);
            
            // Random content show karo
            await showRandomContent(currentLanguage);
            
        } catch (error) {
            console.error('Language load error:', error);
            // Fallback messages
            await showMessage(`Hello ${userName}! 👋`);
            await showMessage("Welcome back! 🎉");
            await showMessage("Have a great day! 🌟");
        }
    }

    async function updateWidgetText(lang) {
        try {
            const response = await fetch(`https://deepakchauhanxai.xyz/testing-dk/languages/widget-text.json`);
            const data = await response.json();
            const langData = data[lang] || data['en'];
            
            // Update UI text
            document.getElementById('aiName').textContent = langData.widget.title;
            document.getElementById('aiSubtitle').textContent = langData.widget.subtitle;
            document.getElementById('ultimateCloseBtn').textContent = langData.widget.close_btn;
            
        } catch (error) {
            console.log('Using default widget text');
        }
    }

    async function showRandomContent(lang) {
        try {
            const response = await fetch(`https://deepakchauhanxai.xyz/testing-dk/assets/widgets/${lang}.json`);
            const data = await response.json();
            
            // Random content select karo
            const randomIndex = Math.floor(Math.random() * data.shayari.length);
            const content = data.shayari[randomIndex];
            
            // Greeting show karo
            const greeting = getTimeBasedGreeting(lang);
            await showMessage(`${greeting} ${userName}!`);
            
            // Content show karo
            await showMessage(content.welcome.replace('${username}', userName));
            await showMessage(content.intro);
            await showMessage(content.shayari);
            
        } catch (error) {
            console.error('Content load error:', error);
            // Fallback English content
            await showMessage(`Hello ${userName}! 👋`);
            await showMessage("Nice to see you again! 😊");
            await showMessage("Keep shining! 🌟");
        }
    }

    function getTimeBasedGreeting(lang) {
        const hour = new Date().getHours();
        const greetings = {
            en: { morning: '🌅 Good Morning', afternoon: '☀️ Hello', evening: '🌆 Good Evening', night: '🌙 Good Night' },
            hi: { morning: '🌅 शुभ प्रभात', afternoon: '☀️ नमस्कार', evening: '🌆 शुभ संध्या', night: '🌙 शुभ रात्रि' },
            ur: { morning: '🌅 صبح بخیر', afternoon: '☀️ سلام', evening: '🌆 شام بخیر', night: '🌙 شب بخیر' },
            mr: { morning: '🌅 शुभ प्रभात', afternoon: '☀️ नमस्कार', evening: '🌆 शुभ संध्याकाळ', night: '🌙 शुभ रात्री' }
        };
        
        const langGreetings = greetings[lang] || greetings['en'];
        
        if (hour >= 5 && hour < 12) return langGreetings.morning;
        if (hour >= 12 && hour < 17) return langGreetings.afternoon;
        if (hour >= 17 && hour < 21) return langGreetings.evening;
        return langGreetings.night;
    }

    function showMessage(text) {
        return new Promise((resolve) => {
            const msgDiv = document.createElement('div');
            msgDiv.style.cssText = `
                background: rgba(0,255,204,0.2);
                padding: 10px;
                border-radius: 8px;
                margin-bottom: 10px;
                border-left: 3px solid #00ffcc;
                animation: fadeIn 0.5s ease-out;
            `;
            msgDiv.textContent = text;
            
            document.getElementById('ultimateMessages').appendChild(msgDiv);
            scrollToBottom();
            
            setTimeout(resolve, 2000);
        });
    }

    function scrollToBottom() {
        const messages = document.getElementById('ultimateMessages');
        messages.scrollTop = messages.scrollHeight;
    }

    // ✅ IMPORTANT: Main site ke language changes suno
    document.addEventListener('languageChanged', function(event) {
        console.log('🌐 Language changed to:', event.detail.language);
        if (widget && widget.style.display !== 'none') {
            // Refresh content with new language
            document.getElementById('ultimateMessages').innerHTML = '';
            loadLanguageAndUpdate();
        }
    });

    // ✅ Session tracking - har naye tab/website open pe hi show hoga
    if (!sessionStorage.getItem('widgetShown')) {
        sessionStorage.setItem('widgetShown', 'true');
    } else {
        // Agar already dikhaya hai is session mein, to mat dikhao
        console.log('ℹ️ Widget already shown this session');
    }

})();