/**
 * DK Community Wall - Final Working JavaScript
 * Complete Comment System with SQL Integration
 * @author Deepak Chauhan × AI Bhai
 */

class CommunityWall {
    constructor() {
        this.currentUser = null;
        this.currentLanguage = 'en';
        this.posts = [];
        this.isLoading = false;
        this.commentsCache = {};
        
        this.init();
    }

    async init() {
        console.log('🚀 DK Community Wall Initializing...');
        
        // Wait for language manager
        await this.waitForLanguageManager();
        
        // Load user data
        await this.loadUserData();
        
        // Initialize all systems
        this.initializeEventListeners();
        this.loadPosts();
        this.loadActivities();
        this.updateStats();
        
        // Hide loading screen
        this.hideLoadingScreen();
        
        console.log('✅ DK Community Wall Ready!');
    }

    async waitForLanguageManager() {
        let attempts = 0;
        while (!window.dkLanguageManager && attempts < 50) {
            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
        }
        
        if (window.dkLanguageManager) {
            this.currentLanguage = window.dkLanguageManager.getCurrentLanguage();
            console.log('🌐 Language manager connected:', this.currentLanguage);
        } else {
            this.currentLanguage = localStorage.getItem('preferredLanguage') || 'en';
            console.log('⚠️ Using fallback language:', this.currentLanguage);
        }
    }

    hideLoadingScreen() {
        setTimeout(() => {
            const loadingScreen = document.getElementById('loadingScreen');
            const mainLayout = document.getElementById('mainLayout');
            
            if (loadingScreen && mainLayout) {
                loadingScreen.style.opacity = '0';
                setTimeout(() => {
                    loadingScreen.classList.add('hidden');
                    mainLayout.classList.remove('hidden');
                    mainLayout.style.opacity = '1';
                }, 500);
            }
        }, 1500);
    }

    // User Management
    async loadUserData() {
        try {
            const savedUser = localStorage.getItem('progressUser') || 
                            sessionStorage.getItem('currentUser') ||
                            this.getUserFromCookies();
            
            if (savedUser) {
                this.currentUser = typeof savedUser === 'string' ? JSON.parse(savedUser) : savedUser;
                console.log('👤 User loaded:', this.currentUser.name);
            } else {
                this.currentUser = {
                    name: 'Guest User',
                    user_id: 'guest_' + Date.now(),
                    guest: true
                };
                console.log('👤 Guest mode activated');
            }
            
            this.updateUserInfo();
            await this.loadUserAvatar();
            
        } catch (e) {
            console.error('User load error:', e);
            this.showGuestMode();
        }
    }

    getUserFromCookies() {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            const [name, value] = cookie.trim().split('=');
            if (name === 'userData' && value) {
                return JSON.parse(decodeURIComponent(value));
            }
        }
        return null;
    }

    updateUserInfo() {
        const userNameElement = document.getElementById('userName');
        
        if (userNameElement && this.currentUser) {
            userNameElement.textContent = this.currentUser.name || 'Guest User';
        }
    }

    async loadUserAvatar() {
        try {
            const userAvatarImg = document.getElementById('userAvatar');
            const creatorAvatarImg = document.getElementById('creatorAvatar');
            
            if (this.currentUser && !this.currentUser.guest) {
                const avatarUrl = await this.getUserAvatar(this.currentUser.user_id);
                if (userAvatarImg) userAvatarImg.src = avatarUrl;
                if (creatorAvatarImg) creatorAvatarImg.src = avatarUrl;
            } else {
                const defaultAvatar = this.getDefaultAvatar();
                if (userAvatarImg) userAvatarImg.src = defaultAvatar;
                if (creatorAvatarImg) creatorAvatarImg.src = defaultAvatar;
            }
        } catch (error) {
            console.error('Avatar load error:', error);
            this.setDefaultAvatars();
        }
    }

    async getUserAvatar(userId) {
        try {
            const response = await fetch('https://deepakchauhanxai.xyz/dk-api/get-user-avatar.php', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    action: 'get_avatar',
                    user_id: userId
                })
            });
            
            if (response.ok) {
                const result = await response.json();
                if (result.success && result.avatar_url) {
                    return result.avatar_url;
                }
            }
        } catch (error) {
            console.error('Get avatar API error:', error);
        }
        
        return this.getDefaultAvatar();
    }

    getDefaultAvatar() {
        return 'https://deepakchauhanxai.xyz/images/default-avatar.png';
    }

    setDefaultAvatars() {
        const defaultAvatar = this.getDefaultAvatar();
        const userAvatarImg = document.getElementById('userAvatar');
        const creatorAvatarImg = document.getElementById('creatorAvatar');
        
        if (userAvatarImg) userAvatarImg.src = defaultAvatar;
        if (creatorAvatarImg) creatorAvatarImg.src = defaultAvatar;
    }

    showGuestMode() {
        this.currentUser = {
            name: 'Guest User',
            user_id: 'guest_' + Date.now(),
            guest: true
        };
        this.updateUserInfo();
        this.setDefaultAvatars();
    }

    // Avatar Change System
    async changeAvatar() {
        if (!this.currentUser || this.currentUser.guest) {
            this.showToast('Please login to change avatar!', 'warning');
            return;
        }

        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (file) {
                await this.uploadAvatar(file);
            }
        };
        
        input.click();
    }

    async uploadAvatar(file) {
        if (!file.type.startsWith('image/')) {
            this.showToast('Please select an image file!', 'error');
            return;
        }

        if (file.size > 2 * 1024 * 1024) {
            this.showToast('Image size should be less than 2MB!', 'error');
            return;
        }

        this.showToast('Uploading avatar...', 'info');

        try {
            const formData = new FormData();
            formData.append('action', 'upload_avatar');
            formData.append('user_id', this.currentUser.user_id);
            formData.append('avatar', file);

            const response = await fetch('https://deepakchauhanxai.xyz/dk-api/upload-avatar.php', {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                const result = await response.json();
                
                if (result.success) {
                    const userAvatarImg = document.getElementById('userAvatar');
                    const creatorAvatarImg = document.getElementById('creatorAvatar');
                    
                    if (userAvatarImg) userAvatarImg.src = result.avatar_url + '?t=' + Date.now();
                    if (creatorAvatarImg) creatorAvatarImg.src = result.avatar_url + '?t=' + Date.now();
                    
                    this.showToast('Avatar updated successfully! 🎉', 'success');
                } else {
                    this.showToast('Avatar upload failed: ' + result.message, 'error');
                }
            } else {
                throw new Error('Network error');
            }
        } catch (error) {
            console.error('Avatar upload error:', error);
            this.showToast('Upload failed. Please try again.', 'error');
        }
    }

    // Event Listeners
    initializeEventListeners() {
        const submitPostBtn = document.getElementById('submitPost');
        const postContent = document.getElementById('postContent');
        
        if (submitPostBtn && postContent) {
            submitPostBtn.addEventListener('click', () => this.handlePostSubmission());
            
            postContent.addEventListener('input', () => this.updateCharCount());
            
            postContent.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.handlePostSubmission();
                }
            });
        }

        this.initializeLanguageSwitcher();
        this.initializeCommentButtons();
        
        setInterval(() => {
            this.loadPosts();
        }, 30000);
        
        console.log('🎯 Event listeners initialized');
    }

    updateCharCount() {
        const postContent = document.getElementById('postContent');
        const charCount = document.getElementById('charCount');
        
        if (postContent && charCount) {
            const count = postContent.value.length;
            charCount.textContent = count;
            
            if (count > 400) {
                charCount.className = 'error';
            } else if (count > 300) {
                charCount.className = 'warning';
            } else {
                charCount.className = '';
            }
        }
    }

    // Language Switcher
    initializeLanguageSwitcher() {
        const languageTrigger = document.getElementById('languageTrigger');
        const languageDropdown = document.getElementById('languageDropdown');
        
        if (!languageTrigger || !languageDropdown) {
            console.log('⚠️ Language switcher elements not found');
            return;
        }
        
        this.updateLanguageFlag();
        
        languageTrigger.addEventListener('click', (e) => {
            e.stopPropagation();
            languageDropdown.classList.toggle('show');
        });
        
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.language-selector')) {
                languageDropdown.classList.remove('show');
            }
        });
        
        const languageOptions = languageDropdown.querySelectorAll('.language-option');
        languageOptions.forEach(option => {
            option.addEventListener('click', (e) => {
                e.stopPropagation();
                const lang = option.getAttribute('data-lang');
                this.changeLanguage(lang);
                languageDropdown.classList.remove('show');
            });
        });
        
        document.addEventListener('dkLanguageChanged', (event) => {
            this.currentLanguage = event.detail.language;
            this.updateLanguageFlag();
            console.log('🌐 Language changed via event:', this.currentLanguage);
        });
    }

    updateLanguageFlag() {
        const flagMap = { 
            'en': '🇺🇸', 
            'hi': '🇮🇳', 
            'ur': '🇵🇰', 
            'mr': '🇮🇳' 
        };
        
        const currentLanguageElement = document.getElementById('currentLanguage');
        if (currentLanguageElement) {
            currentLanguageElement.textContent = flagMap[this.currentLanguage] || '🇺🇸';
        }
    }

    changeLanguage(lang) {
        if (window.dkLanguageManager) {
            window.dkLanguageManager.changeLanguage(lang);
        } else {
            this.currentLanguage = lang;
            localStorage.setItem('preferredLanguage', lang);
            this.updateLanguageFlag();
            this.showToast(`Language changed to ${this.getLanguageName(lang)}!`, 'success');
            console.log('🌐 Language changed locally:', lang);
        }
    }

    getLanguageName(lang) {
        const languages = {
            'en': 'English',
            'hi': 'Hindi', 
            'ur': 'Urdu',
            'mr': 'Marathi'
        };
        return languages[lang] || 'English';
    }

    // Post System
    async handlePostSubmission() {
        const postContent = document.getElementById('postContent');
        const content = postContent.value.trim();
        
        if (!content) {
            this.showToast('Please write something to post!', 'warning');
            return;
        }
        
        if (content.length > 500) {
            this.showToast('Post too long! Maximum 500 characters.', 'error');
            return;
        }
        
        if (!this.currentUser) {
            this.showToast('Please login to post!', 'warning');
            return;
        }
        
        this.showToast('Publishing post...', 'info');
        
        try {
            const result = await this.createPost(content);
            
            if (result.success) {
                postContent.value = '';
                this.updateCharCount();
                
                this.showToast('Post published successfully! 🚀', 'success');
                this.loadPosts();
            } else {
                this.showToast('Failed to publish post: ' + result.message, 'error');
            }
        } catch (error) {
            this.showToast('Network error. Please try again.', 'error');
            console.error('Post submission error:', error);
        }
    }

    async createPost(content) {
        const postData = {
            action: 'create_post',
            username: this.currentUser.name,
            user_id: this.currentUser.user_id,
            post_text: content,
            language: this.currentLanguage
        };

        const response = await fetch('https://deepakchauhanxai.xyz/dk-api/community-create-post.php', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(postData)
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        return await response.json();
    }

    // Load and Display Posts
    async loadPosts() {
        if (this.isLoading) return;
        
        this.isLoading = true;
        this.showLoadingState();
        
        try {
            const result = await this.fetchPosts();
            
            if (result.success) {
                this.posts = result.posts;
                this.displayPosts();
                this.updateStats();
            } else {
                this.showToast('Failed to load posts: ' + result.message, 'error');
                this.displayEmptyState();
            }
        } catch (error) {
            console.error('Load posts error:', error);
            this.showToast('Network error loading posts', 'error');
            this.displayEmptyState();
        } finally {
            this.isLoading = false;
            this.hideLoadingState();
        }
    }

    async fetchPosts(limit = 20, offset = 0) {
        const response = await fetch('https://deepakchauhanxai.xyz/dk-api/community-get-posts.php', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                action: 'get_posts',
                limit: limit,
                offset: offset
            })
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        return await response.json();
    }

    displayPosts() {
        const postsFeed = document.getElementById('postsFeed');
        if (!postsFeed) return;
        
        this.hideLoadingState();
        
        if (this.posts.length === 0) {
            this.displayEmptyState();
            return;
        }
        
        let postsHTML = '';
        this.posts.forEach(post => {
            postsHTML += this.createPostElement(post);
        });
        
        postsFeed.innerHTML = postsHTML;
        
        this.initializeLikeButtons();
        this.initializeCommentButtons();
    }

    createPostElement(post) {
        const isAI = post.username === 'AI Bhai' || post.is_ai_post;
        const avatarClass = isAI ? 'ai-avatar' : 'user-avatar';
        const avatarUrl = isAI ? 
            'https://deepakchauhanxai.xyz/images/AI-bhai.png' : 
            (post.avatar_url || this.getDefaultAvatar());
        
        const badge = isAI ? '<span class="ai-badge">AI POWERED</span>' : '';

        return `
            <div class="post-card ${isAI ? 'ai-post' : 'user-post'}" data-post-id="${post.id}">
                <div class="post-header">
                    <div class="post-author">
                        <div class="author-avatar ${avatarClass}">
                            <img src="${avatarUrl}" alt="${post.username}" class="avatar-image">
                        </div>
                        <div class="author-details">
                            <span class="author-name">${this.escapeHtml(post.username)}</span>
                            <span class="post-time">${post.time_ago}</span>
                            ${badge}
                        </div>
                    </div>
                </div>
                <div class="post-content">
                    <p>${this.escapeHtml(post.post_text)}</p>
                </div>
                <div class="enhanced-post-actions">
                    <button class="enhanced-post-action like-btn" data-post-id="${post.id}">
                        <span class="action-icon">❤️</span>
                        <span class="action-text">Like</span>
                        <span class="action-count">${post.likes_count}</span>
                    </button>
                    <button class="enhanced-post-action comment-btn" data-post-id="${post.id}">
                        <span class="action-icon">💬</span>
                        <span class="action-text">Comment</span>
                        <span class="action-count">${post.comments_count}</span>
                    </button>
                    <button class="enhanced-post-action share-btn">
                        <span class="action-icon">🔗</span>
                        <span class="action-text">Share</span>
                    </button>
                </div>
                <div class="comment-section hidden" id="commentSection-${post.id}">
                    <!-- Comments will be loaded here when opened -->
                </div>
            </div>
        `;
    }

    displayEmptyState() {
        const postsFeed = document.getElementById('postsFeed');
        if (postsFeed) {
            postsFeed.innerHTML = `
                <div class="no-posts">
                    <div class="no-posts-icon">💬</div>
                    <p>No posts yet. Be the first to share something!</p>
                    <button class="action-btn primary" onclick="document.getElementById('postContent').focus()">
                        Write First Post
                    </button>
                </div>
            `;
        }
    }

    // Like System
    initializeLikeButtons() {
        const postsFeed = document.getElementById('postsFeed');
        if (!postsFeed) return;
        
        postsFeed.addEventListener('click', (e) => {
            const likeBtn = e.target.closest('.like-btn');
            if (likeBtn) {
                const postId = likeBtn.getAttribute('data-post-id');
                this.handleLike(postId, likeBtn);
            }
        });
    }

    async handleLike(postId, likeButton) {
        if (!this.currentUser) {
            this.showToast('Please login to like posts!', 'warning');
            return;
        }
        
        try {
            const result = await this.toggleLike(postId);
            
            if (result.success) {
                const countElement = likeButton.querySelector('.action-count');
                const iconElement = likeButton.querySelector('.action-icon');
                
                if (countElement) {
                    countElement.textContent = result.likes_count;
                }
                
                if (result.liked) {
                    likeButton.classList.add('liked');
                    if (iconElement) iconElement.textContent = '💖';
                    this.showToast('Post liked! ❤️', 'success');
                } else {
                    likeButton.classList.remove('liked');
                    if (iconElement) iconElement.textContent = '❤️';
                    this.showToast('Post unliked', 'info');
                }
            } else {
                this.showToast('Like operation failed', 'error');
            }
        } catch (error) {
            this.showToast('Network error', 'error');
            console.error('Like error:', error);
        }
    }

    async toggleLike(postId) {
        const response = await fetch('https://deepakchauhanxai.xyz/dk-api/community-like-post.php', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                action: 'like_post',
                post_id: postId,
                username: this.currentUser.name,
                user_id: this.currentUser.user_id
            })
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        return await response.json();
    }

    // Comment System - FINAL WORKING VERSION
    initializeCommentButtons() {
        const postsFeed = document.getElementById('postsFeed');
        if (!postsFeed) return;
        
        postsFeed.addEventListener('click', (e) => {
            const commentBtn = e.target.closest('.comment-btn');
            if (commentBtn) {
                const postId = commentBtn.getAttribute('data-post-id');
                this.toggleCommentSection(postId, commentBtn);
            }
            
            const commentSubmitBtn = e.target.closest('.comment-submit-btn');
            if (commentSubmitBtn) {
                const postId = commentSubmitBtn.getAttribute('data-post-id');
                this.handleCommentSubmission(postId);
            }
        });
        
        // Enter key support for comment input
        postsFeed.addEventListener('keydown', (e) => {
            if (e.target.classList.contains('comment-input') && e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                const postId = e.target.id.replace('commentInput-', '');
                this.handleCommentSubmission(postId);
            }
        });
    }

    async toggleCommentSection(postId, commentButton) {
        const commentSection = document.getElementById(`commentSection-${postId}`);
        
        if (commentSection.classList.contains('hidden')) {
            // Show loading state
            commentSection.classList.remove('hidden');
            commentButton.classList.add('comment-active');
            commentSection.innerHTML = `
                <div style="text-align: center; padding: 20px; color: #94a3b8;">
                    <div class="loading-spinner-small"></div>
                    <p>Loading comments...</p>
                </div>
            `;
            
            // Load comments
            await this.loadComments(postId);
            this.displayComments(postId);
        } else {
            commentSection.classList.add('hidden');
            commentButton.classList.remove('comment-active');
        }
    }

    async loadComments(postId) {
        try {
            console.log('🔄 Loading comments for post:', postId);
            
            const response = await fetch('https://deepakchauhanxai.xyz/dk-api/dk-get-comments.php', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    post_id: parseInt(postId)
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            console.log('📝 Comments API Response:', result);
            
            if (result.success) {
                this.commentsCache[postId] = result.comments || [];
                console.log('✅ Comments loaded in cache:', this.commentsCache[postId].length, 'comments');
            } else {
                console.error('❌ Comments API error:', result.message);
                this.commentsCache[postId] = [];
            }
        } catch (error) {
            console.error('❌ Load comments error:', error);
            this.commentsCache[postId] = [];
        }
    }

    displayComments(postId) {
        const commentSection = document.getElementById(`commentSection-${postId}`);
        const comments = this.commentsCache[postId] || [];
        
        console.log('📋 Displaying comments:', comments.length);
        
        let commentsHTML = `
            <div class="comment-input-area">
                <img src="${this.currentUser.avatar_url || this.getDefaultAvatar()}" alt="User" class="comment-avatar">
                <div class="comment-input-wrapper">
                    <textarea 
                        class="comment-input" 
                        id="commentInput-${postId}"
                        placeholder="Write a comment..."
                        rows="2"
                    ></textarea>
                    <button class="comment-submit-btn" data-post-id="${postId}">
                        Post
                    </button>
                </div>
            </div>
        `;
        
        if (comments.length > 0) {
            commentsHTML += '<div class="comments-list">';
            comments.forEach(comment => {
                commentsHTML += `
                    <div class="comment-item">
                        <img src="${comment.avatar_url || this.getDefaultAvatar()}" alt="${comment.username}" class="comment-avatar-small">
                        <div class="comment-content">
                            <div class="comment-author">${this.escapeHtml(comment.username)}</div>
                            <div class="comment-text">${this.escapeHtml(comment.comment_text)}</div>
                            <div class="comment-time">${comment.time_ago}</div>
                        </div>
                    </div>
                `;
            });
            commentsHTML += '</div>';
        } else {
            commentsHTML += `
                <div class="no-comments">
                    <p style="text-align: center; color: #94a3b8; padding: 20px;">No comments yet. Be the first to comment!</p>
                </div>
            `;
        }
        
        commentSection.innerHTML = commentsHTML;
    }

    async handleCommentSubmission(postId) {
        const commentInput = document.getElementById(`commentInput-${postId}`);
        const commentText = commentInput.value.trim();
        
        if (!commentText) {
            this.showToast('Please write a comment!', 'warning');
            return;
        }
        
        if (!this.currentUser) {
            this.showToast('Please login to comment!', 'warning');
            return;
        }
        
        if (commentText.length > 1000) {
            this.showToast('Comment too long! Maximum 1000 characters.', 'error');
            return;
        }
        
        this.showToast('Posting comment...', 'info');
        
        try {
            const result = await this.createComment(postId, commentText);
            
            if (result.success) {
                // Clear input
                commentInput.value = '';
                
                // IMPORTANT: Force reload comments and update cache
                await this.loadComments(postId);
                this.displayComments(postId);
                
                this.showToast('Comment posted successfully! 💬', 'success');
                
                // Update comment count in the button
                const commentBtn = document.querySelector(`.comment-btn[data-post-id="${postId}"]`);
                if (commentBtn) {
                    const countElement = commentBtn.querySelector('.action-count');
                    if (countElement) {
                        countElement.textContent = result.comments_count;
                    }
                }
                
            } else {
                this.showToast('Failed to post comment: ' + result.message, 'error');
            }
        } catch (error) {
            console.error('❌ Comment submission error:', error);
            this.showToast('Network error. Please try again.', 'error');
        }
    }

    async createComment(postId, commentText) {
        try {
            console.log('📤 Creating comment for post:', postId);
            
            const response = await fetch('https://deepakchauhanxai.xyz/dk-api/dk-add-comment.php', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    post_id: parseInt(postId),
                    username: this.currentUser.name,
                    user_id: this.currentUser.user_id,
                    comment_text: commentText
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            console.log('✅ Comment creation response:', result);
            
            return result;
            
        } catch (error) {
            console.error('❌ Create comment error:', error);
            throw error;
        }
    }

    // Activities System
    async loadActivities() {
        try {
            this.displayUserActivities();
        } catch (error) {
            console.error('Load activities error:', error);
        }
    }

    displayUserActivities() {
        const activitiesFeed = document.getElementById('activitiesFeed');
        if (!activitiesFeed) return;
        
        const activities = [
            { 
                username: 'John Doe',
                activity_text: 'liked your post about AI technology',
                time_ago: '2 min ago'
            },
            { 
                username: 'Sarah Smith', 
                activity_text: 'commented on your post',
                time_ago: '5 min ago'
            },
            { 
                username: 'Mike Johnson',
                activity_text: 'shared your post with community', 
                time_ago: '10 min ago'
            },
            { 
                username: 'AI Bhai',
                activity_text: 'analyzed your post and found 98% engagement',
                time_ago: '15 min ago'
            }
        ];
        
        let activitiesHTML = '';
        activities.forEach(activity => {
            activitiesHTML += `
                <div class="user-activity-item">
                    <div class="activity-icon">
                        <img src="${this.getDefaultAvatar()}" alt="User" class="user-activity-avatar">
                    </div>
                    <div class="user-activity-content">
                        <p><strong>${activity.username}:</strong> ${activity.activity_text}</p>
                        <span class="user-activity-time">${activity.time_ago}</span>
                    </div>
                </div>
            `;
        });
        
        activitiesFeed.innerHTML = activitiesHTML;
    }

    // Stats System
    updateStats() {
        const membersCount = document.getElementById('membersCount');
        const postsCount = document.getElementById('postsCount');
        const onlineCount = document.getElementById('onlineCount');
        
        if (membersCount) membersCount.textContent = '1.2K';
        if (postsCount) postsCount.textContent = this.posts.length > 0 ? this.posts.length : '456';
        if (onlineCount) onlineCount.textContent = Math.floor(Math.random() * 50) + 80;
    }

    refreshStats() {
        this.updateStats();
        this.showToast('Stats refreshed!', 'success');
    }

    // UI Helpers
    showLoadingState() {
        const loadingElement = document.getElementById('feedLoading');
        if (loadingElement) {
            loadingElement.style.display = 'flex';
        }
    }

    hideLoadingState() {
        const loadingElement = document.getElementById('feedLoading');
        const postsFeed = document.getElementById('postsFeed');
        
        if (loadingElement) {
            loadingElement.style.display = 'none';
        }
        if (postsFeed && this.posts.length === 0) {
            this.displayEmptyState();
        }
    }

    showToast(message, type = 'info') {
        const existingToast = document.querySelector('.dk-toast');
        if (existingToast) {
            existingToast.remove();
        }
        
        const toast = document.createElement('div');
        toast.className = `dk-toast dk-toast-${type}`;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentNode) {
                toast.style.animation = 'toastSlideOut 0.3s ease';
                setTimeout(() => toast.remove(), 300);
            }
        }, 3000);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Public methods for HTML buttons
    refreshPosts() {
        this.loadPosts();
        this.showToast('Community intelligence refreshed!', 'success');
    }

    showAISettings() {
        this.showToast('AI Settings panel will be available soon!', 'info');
    }
}

// Language Sync with Main Website
document.addEventListener('languageChanged', function(event) {
    console.log('🌐 Language change event received in Community Wall:', event.detail.language);
    
    if (window.communityWall) {
        window.communityWall.currentLanguage = event.detail.language;
        window.communityWall.updateLanguageFlag();
    }
    
    const currentLangElement = document.getElementById('currentLanguage');
    const flagMap = { 'en': '🇺🇸', 'hi': '🇮🇳', 'ur': '🇵🇰', 'mr': '🇮🇳' };
    if (currentLangElement) {
        currentLangElement.textContent = flagMap[event.detail.language] || '🇺🇸';
    }
});

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 Community Wall Page Loaded');
    window.communityWall = new CommunityWall();
});

// Make globally available
window.CommunityWall = CommunityWall;