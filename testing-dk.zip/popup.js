// AI BHAI MOTIVATIONAL POPUP - SCROLL TRIGGER
(function() {
    console.log('🎯 AI Bhai Beautiful Popup Loading...');

    // Configuration
    const config = {
        scrollTrigger: 400,      // 400px scroll pe show
        showAfterMinutes: 30,    // 30 minutes gap
        popupDuration: 30,       // 15 seconds auto close
        enableParticles: true
    };

    // Global Variables
    let currentLanguage = localStorage.getItem('preferredLanguage') || 'en';
    let popupData = {};
    let popup = null;
    let popupShown = false;

    // Check if should show popup
    function shouldShowPopup() {
        const lastShowTime = localStorage.getItem('aiPopupLastShow');
        if (!lastShowTime) return true;
        
        const lastShow = parseInt(lastShowTime);
        const currentTime = new Date().getTime();
        const minutesSinceLastShow = (currentTime - lastShow) / (1000 * 60);
        
        console.log(`⏰ Last popup: ${minutesSinceLastShow.toFixed(2)} minutes ago`);
        return minutesSinceLastShow >= config.showAfterMinutes;
    }

    // Mark popup as shown
    function markPopupAsShown() {
        localStorage.setItem('aiPopupLastShow', new Date().getTime().toString());
        console.log('✅ Popup shown time saved for 30 minutes');
    }

    // Initialize
    function init() {
        loadPopupData().then(() => {
            setupScrollListener();
        }).catch(error => {
            console.log('❌ Using default popup data');
            setupScrollListener();
        });
    }

    async function loadPopupData() {
        try {
            const response = await fetch('https://deepakchauhanxai.xyz/testing-dk/assets/popup/popup.json');
            const data = await response.json();
            popupData = data;
            console.log('✅ Popup data loaded');
        } catch (error) {
            // Fallback data
            popupData = {
                'en': {
                    'title': 'RISE AND SHINE, CHAMPION! 🌅',
                    'description': 'Every sunrise brings new energy, new opportunities, and new victories. Your potential is limitless - today is your day to shine brighter than ever!',
                    'signature': 'With belief, AI Bhai 💫',
                    'close_btn': 'ACCEPT THE CHALLENGE 🚀',
                    'daily_update': 'Daily Motivation',
                    'image_url': 'https://deepakchauhanxai.xyz/images/AI-bhai.png'
                }
            };
        }
    }

    function setupScrollListener() {
        window.addEventListener('scroll', function() {
            if (!popupShown && window.scrollY > config.scrollTrigger && shouldShowPopup()) {
                showBeautifulPopup();
            }
        });
    }

    function createBeautifulPopup() {
        if (document.getElementById('aiBhaiPopup')) {
            popup = document.getElementById('aiBhaiPopup');
            return;
        }

        // BEAUTIFUL POPUP STYLES
        const style = document.createElement('style');
        style.innerHTML = `
            #aiBhaiPopup {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) scale(1);
                background: linear-gradient(145deg, 
                    rgba(26, 26, 46, 0.95), 
                    rgba(22, 33, 62, 0.93), 
                    rgba(15, 52, 96, 0.9)
                );
                color: white;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                padding: 30px;
                border-radius: 25px;
                width: 90%;
                max-width: 420px;
                z-index: 10002;
                box-shadow: 
                    0 0 80px rgba(255, 105, 180, 0.6),
                    0 25px 50px rgba(0, 0, 0, 0.7),
                    inset 0 1px 0 rgba(255, 255, 255, 0.2);
                border: 2px solid rgba(255, 105, 180, 0.7);
                animation: popupEntrance 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                backdrop-filter: blur(20px);
                display: flex;
                flex-direction: column;
                overflow: hidden;
            }

            @keyframes popupEntrance {
                0% { 
                    transform: translate(-50%, -50%) scale(0.7) rotate(-5deg);
                    opacity: 0;
                }
                60% { 
                    transform: translate(-50%, -50%) scale(1.05) rotate(1deg);
                    opacity: 1;
                }
                100% { 
                    transform: translate(-50%, -50%) scale(1) rotate(0);
                    opacity: 1;
                }
            }

            @media (max-width: 480px) {
                #aiBhaiPopup {
                    width: 92%;
                    padding: 25px 20px;
                    max-width: 350px;
                }
            }

            #popupHeader {
                display: flex;
                align-items: center;
                margin-bottom: 20px;
                padding-bottom: 15px;
                border-bottom: 2px solid rgba(255, 105, 180, 0.5);
                position: relative;
            }

            #popupHeader::after {
                content: '';
                position: absolute;
                bottom: -2px;
                left: 0;
                width: 120px;
                height: 3px;
                background: linear-gradient(90deg, #ff69b4, #9370db, transparent);
                border-radius: 3px;
                animation: headerShine 3s infinite alternate;
            }

            @keyframes headerShine {
                0% { background-position: 0% 50%; }
                100% { background-position: 100% 50%; }
            }

            #popupAvatar {
                width: 70px;
                height: 70px;
                border-radius: 50%;
                object-fit: cover;
                margin-right: 20px;
                border: 3px solid #ff69b4;
                box-shadow: 
                    0 0 25px rgba(255, 105, 180, 0.7),
                    inset 0 0 15px rgba(255, 105, 180, 0.3);
                animation: avatarGlow 3s ease-in-out infinite;
            }

            @keyframes avatarGlow {
                0%, 100% { 
                    transform: scale(1);
                    box-shadow: 0 0 25px rgba(255, 105, 180, 0.7);
                }
                50% { 
                    transform: scale(1.05);
                    box-shadow: 0 0 35px rgba(255, 105, 180, 0.9);
                }
            }

            #popupTitle {
                font-weight: 900;
                font-size: 24px;
                background: linear-gradient(135deg, #ff69b4, #9370db, #00bfff);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-size: 300% 300%;
                animation: titleGradient 4s ease infinite;
                text-shadow: 0 0 30px rgba(255, 105, 180, 0.5);
                line-height: 1.2;
            }

            @keyframes titleGradient {
                0%, 100% { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
            }

            #popupSubtitle {
                font-size: 14px;
                color: #90ee90;
                margin-top: 5px;
                font-weight: 700;
                letter-spacing: 0.5px;
            }

            #popupImage {
                width: 100%;
                height: 180px;
                border-radius: 15px;
                object-fit: cover;
                margin: 15px 0;
                border: 2px solid rgba(255, 255, 255, 0.3);
                box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4);
                transition: transform 0.3s ease;
            }

            #popupImage:hover {
                transform: scale(1.02);
            }

            #popupDescription {
                background: rgba(255, 255, 255, 0.1);
                padding: 18px;
                border-radius: 15px;
                margin: 15px 0;
                border-left: 4px solid #9370db;
                font-size: 15px;
                line-height: 1.5;
                text-align: center;
                font-style: italic;
                backdrop-filter: blur(10px);
                animation: fadeInUp 0.6s ease-out;
            }

            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(15px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            #popupSignature {
                text-align: right;
                font-weight: 700;
                color: #00bfff;
                margin: 10px 0 20px 0;
                font-size: 14px;
                text-shadow: 0 0 15px rgba(0, 191, 255, 0.5);
            }

            #closePopup {
                background: linear-gradient(135deg, #ff69b4, #9370db);
                color: white;
                border: none;
                padding: 16px;
                border-radius: 14px;
                cursor: pointer;
                width: 100%;
                font-weight: 800;
                font-size: 16px;
                letter-spacing: 0.8px;
                transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                position: relative;
                overflow: hidden;
                text-transform: uppercase;
                box-shadow: 0 5px 20px rgba(255, 105, 180, 0.4);
            }

            #closePopup::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, 
                    transparent, 
                    rgba(255, 255, 255, 0.3), 
                    transparent
                );
                transition: left 0.6s;
            }

            #closePopup:hover {
                transform: translateY(-3px);
                box-shadow: 
                    0 10px 30px rgba(255, 105, 180, 0.6),
                    0 0 25px rgba(255, 105, 180, 0.4);
                letter-spacing: 1.2px;
            }

            #closePopup:hover::before {
                left: 100%;
            }

            #closePopup:active {
                transform: translateY(-1px);
            }

            .popup-badge {
                position: absolute;
                top: 15px;
                right: 15px;
                background: linear-gradient(135deg, #ff69b4, #9370db);
                color: white;
                padding: 4px 12px;
                border-radius: 20px;
                font-size: 10px;
                font-weight: 900;
                text-transform: uppercase;
                letter-spacing: 1px;
                box-shadow: 0 0 20px rgba(255, 105, 180, 0.6);
                animation: badgePulse 2s infinite;
            }

            @keyframes badgePulse {
                0%, 100% { 
                    transform: scale(1);
                    box-shadow: 0 0 20px rgba(255, 105, 180, 0.6);
                }
                50% { 
                    transform: scale(1.05);
                    box-shadow: 0 0 30px rgba(255, 105, 180, 0.8);
                }
            }

            .popup-particles {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                pointer-events: none;
                z-index: -1;
                border-radius: 25px;
                overflow: hidden;
            }

            .popup-particle {
                position: absolute;
                width: 4px;
                height: 4px;
                background: #ff69b4;
                border-radius: 50%;
                animation: popupFloat 10s infinite linear;
                opacity: 0;
                box-shadow: 0 0 10px #ff69b4;
            }

            @keyframes popupFloat {
                0% { 
                    transform: translate(0, 0) rotate(0deg) scale(0.5);
                    opacity: 0;
                }
                10% { opacity: 0.8; }
                20% { transform: translate(40px, -20px) rotate(90deg) scale(1.2); }
                40% { transform: translate(80px, 15px) rotate(180deg) scale(0.8); }
                60% { transform: translate(25px, 60px) rotate(270deg) scale(1.1); }
                80% { 
                    transform: translate(-15px, 30px) rotate(360deg) scale(0.9);
                    opacity: 0.6;
                }
                100% { 
                    transform: translate(-30px, -10px) rotate(450deg) scale(0.5);
                    opacity: 0;
                }
            }

            .popup-progress {
                position: absolute;
                bottom: 0;
                left: 0;
                width: 100%;
                height: 3px;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 0 0 25px 25px;
                overflow: hidden;
            }

            .popup-progress-fill {
                height: 100%;
                background: linear-gradient(90deg, #ff69b4, #9370db, #00bfff);
                animation: progressShrink linear forwards;
                border-radius: 0 0 25px 25px;
            }

            @keyframes progressShrink {
                from { width: 100%; }
                to { width: 0%; }
            }
        `;

        if (!document.getElementById('aiPopupStyles')) {
            style.id = 'aiPopupStyles';
            document.head.appendChild(style);
        }

        // Create Beautiful Popup
        popup = document.createElement('div');
        popup.id = 'aiBhaiPopup';
        popup.style.display = 'none';
        
        popup.innerHTML = `
            <div class="popup-particles" id="popupParticles"></div>
            <div class="popup-badge" id="popupBadge">Daily Update</div>
            <div class="popup-progress"><div class="popup-progress-fill" style="animation-duration: ${config.popupDuration}s"></div></div>
            
            <div id="popupHeader">
                <img id="popupAvatar" src="https://deepakchauhanxai.xyz/images/AI-bhai.png" alt="AI Bhai">
                <div>
                    <div id="popupTitle">Daily Motivation</div>
                    <div id="popupSubtitle">AI Bhai Special</div>
                </div>
            </div>
            
            <img id="popupImage" alt="Motivational Image">
            <div id="popupDescription"></div>
            <div id="popupSignature"></div>
            <button id="closePopup">ACCEPT CHALLENGE</button>
        `;
        
        document.body.appendChild(popup);

        // Create particles
        createPopupParticles();

        // Close button
        document.getElementById('closePopup').addEventListener('click', function() {
            markPopupAsShown();
            hideBeautifulPopup();
        });

        console.log('✅ Beautiful Popup Created');
    }

    function createPopupParticles() {
        if (!config.enableParticles) return;
        
        const container = document.getElementById('popupParticles');
        for (let i = 0; i < 12; i++) {
            const particle = document.createElement('div');
            particle.className = 'popup-particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 10 + 's';
            particle.style.animationDuration = (8 + Math.random() * 8) + 's';
            container.appendChild(particle);
        }
    }

    function updatePopupContent() {
        const langData = popupData[currentLanguage] || popupData['en'];
        if (langData) {
            document.getElementById('popupTitle').textContent = langData.title;
            document.getElementById('popupSubtitle').textContent = langData.daily_update;
            document.getElementById('popupDescription').textContent = langData.description;
            document.getElementById('popupSignature').textContent = langData.signature;
            document.getElementById('closePopup').textContent = langData.close_btn;
            document.getElementById('popupBadge').textContent = langData.daily_update;
            
            // Set image with fallback
            const popupImage = document.getElementById('popupImage');
            popupImage.src = langData.image_url || 'https://deepakchauhanxai.xyz/images/AI-bhai.png';
            popupImage.onerror = function() {
                this.src = 'https://deepakchauhanxai.xyz/images/AI-bhai.png';
            };
        }
    }

    function showBeautifulPopup() {
        console.log('🎪 Showing Beautiful Popup');
        
        if (!popup) {
            createBeautifulPopup();
        }
        
        updatePopupContent();
        popup.style.display = 'block';
        popupShown = true;
        
        // Auto close after duration
        setTimeout(() => {
            if (popup && document.body.contains(popup)) {
                markPopupAsShown();
                hideBeautifulPopup();
            }
        }, config.popupDuration * 1000);
    }

    function hideBeautifulPopup() {
        if (popup && document.body.contains(popup)) {
            popup.style.animation = 'popupEntrance 0.5s ease-in reverse';
            setTimeout(() => {
                popup.style.display = 'none';
            }, 500);
        }
    }

    // Initialize when DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        setTimeout(init, 1000);
    }

    // Language change listener
    document.addEventListener('languageChanged', function(event) {
        console.log('🌐 Popup language changed to:', event.detail.language);
        currentLanguage = event.detail.language;
        
        // Update badge
        const badge = document.getElementById('popupBadge');
        if (badge && popupData[currentLanguage]) {
            badge.textContent = popupData[currentLanguage].daily_update;
        }
    });

    console.log('✅ AI BHAI BEAUTIFUL POPUP READY!');

})();